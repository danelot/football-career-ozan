
## 1.1.0-dev.15b.5 — Long-Career Performance Profiling + 2032+ Optimization
- Added deterministic long-career profiler instrumentation and state-section diagnostics.
- Replaced State's JSON stringify/parse clone hot path with an equivalent data clone for serializable state values; no extra RNG consumption.
- Added compact completed-season player match archive and save-time historical compaction while preserving visible career totals/history.
- Added bounded/lazy Career timeline rendering in batches of 10 seasons.
- Extended performance instrumentation for State, SaveManager, TransferMarket, NotificationCenter, Calendar, Team and season summary paths.
- SAVE_VERSION remains 27; dataVersion remains unchanged.
