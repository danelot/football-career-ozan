
### ADIM 13B.5 — Long-Career Performance
Version 1.1.0-dev.15b.5 adds deterministic profiling and long-career optimizations without changing locked gameplay formulas. Completed-season player match logs are archived into a compact columnar representation, save preparation compacts historical logs, the Career timeline renders seasons lazily in batches of 10, and the serializable State clone hot path avoids repeated JSON stringify/parse work. SAVE_VERSION remains 27 and existing 13B.4B saves remain schema-compatible.
