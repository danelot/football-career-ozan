FOOTBALL CAREER V1.1

NASIL OYNANIR

1. Oyun klasörünü ZIP'ten çıkarın.
2. index.html dosyasına çift tıklayın.
3. Oyun tarayıcıda açılır.
4. Yeni kariyer oluşturun veya uyumlu mevcut kaydınıza devam edin.

GEREKSİNİMLER

- Kurulum gerekmez.
- Yerel sunucu gerekmez.
- Node.js, npm, Python veya VS Code gerekmez.
- Temel oynanış için internet bağlantısı gerekmez.
- Oyun doğrudan file:// altında çalışacak şekilde tasarlanmıştır.

KAYITLAR

- Kariyer kayıtları tarayıcının localStorage alanında yerel olarak tutulur.
- Uyumlu Football Career kayıtları mevcut kabul edilmiş kayıt uyumluluğu kapsamında desteklenir.
- Tarayıcı site/depolama verilerini silmek kariyer kaydınızı da silebilir.

KULÜP ARMALARI

- Kulüp armaları mevcut yerel ve fallback sistemiyle çalışır.
- İnternet varsa bazı armalar isteğe bağlı çevrimiçi kaynaklardan yüklenebilir.
- Çevrimiçi kaynak kullanılamadığında oyun fallback davranışıyla çalışmaya devam eder.

SÜRÜM

gameVersion: 1.1.0-dev.14b
SAVE_VERSION: 27
dataVersion: 2026.09-step11a.1.0
storageFormatVersion: 1

V1.1 ADIM 2B GELİŞTİRME NOTU
- gameVersion: 1.1.0-dev.3
- SAVE_VERSION: 26 (hafif dünya modeli için gerçek şema değişikliği)
- Detaylı kalıcı NPC/izleme evreni kaldırıldı; kulüp gücü, ödül rakipleri ve milli takım rekabeti hafif modellerle sürdürülür.
- SAVE_VERSION 25 kayıtları ilk yüklemede yeni hafif dünya modeline dönüştürülür.

V1.1 ADIM 3 — CRITICAL BUGFIX / FLOW STABILITY
- gameVersion: 1.1.0-dev.4
- SAVE_VERSION: 26
- Ülke seçici arama indeksi önceden normalize edilir; hızlı yazma sırasında tekrar eden ağır normalizasyon kaldırıldı.
- Fiziksel takvimden geride kalmış unplayed oyuncu fixture'ları tekrar oynanamaz; unavailable/world sonucu olarak exactly-once işlenir.
- Menajer satın alma ekranı gerçek OVR / kariyer geliri / bakiye koşullarını gösterir.
- ADIM 2A batching/quota-warning davranışı ve ADIM 2B lightweight-world migration korunur.

V1.1 ADIM 4 — PLAYER DEVELOPMENT 2.0
- gameVersion: 1.1.0-dev.5
- SAVE_VERSION remains 26; GP state is additive/lazy-initialized and does not require a new schema migration.
- Match/career performance awards deterministic Gelişim Puanı (GP).
- GP is manually spent on real detailed attributes; OVR remains derived by the canonical position-weighted attribute calculator.
- Legacy opaque automatic match/training attribute growth is disabled; training now provides only a small deterministic development-cost support.
- Match and achievement GP use stable exactly-once source keys with bounded recent ledger history.
- ADIM 5 Wonderkid/Breakout/Prime systems are NOT included.

V1.1 ADIM 5 — CAREER CURVE
- gameVersion: 1.1.0-dev.6
- SAVE_VERSION: 26 (degismedi; careerCurve state additive/lazy initialized)
- POT artik canonical OVR icin hard cap degildir. player.potential orijinal/base POT olarak korunur.
- development.careerCurve.effectivePotential kariyer tavanini tutar.
- Kullanici oyuncuya ozel Harika Cocuk, Cikis Sezonu, pozisyon bazli Prime ve deterministik yaslanma/decline katmani eklendi.
- GP ve manuel attribute harcama ADIM 4'teki ana gelisim mekanigi olmaya devam eder.
- NPC oyuncu evreni geri getirilmedi; ADIM 2B lightweight world korunur.

V1.1 ADIM 6 — RELATIONSHIPS + PLAYING TIME 2.0
- gameVersion: 1.1.0-dev.7
- SAVE_VERSION: 27 (club-scoped relationship/role semantics require real migration)
- Teknik Direktör Güveni, Takım Arkadaşları, Taraftarlar ve Kulüp Statüsü 0–100 club-scoped profile altında birleştirildi.
- Sözleşme rolü artık değiştirilmiyor; ayrı Teknik Direktör Rolü gerçek performans/güven ile gelişiyor veya geriliyor.
- Oynama süresi kararı fixture-stable, UI-preview RNG nötr ve navigation/save-load ile reroll edilemez.
- 21 yaş ve altı düşük rol oyuncuları için bounded sezonluk küçük profesyonel gelişim GP desteği eklendi; maç GP hâlâ ana kaynak.
- Kulüp Efsanesi sistemi position-aware; olağanüstü 4–5 sezonluk kariyer mümkün, sıradan tenure otomatik efsane yapmaz.
- ADIM 2A batching, ADIM 2B lightweight world, ADIM 3 injury chronology, ADIM 4 GP ve ADIM 5 Career Curve korunur.


ADIM 7 — TRANSFER CENTER 2.0 SYSTEM
- gameVersion: 1.1.0-dev.8
- SAVE_VERSION: 27 (additive transferMarket state; semantic migration not required)
- Persistent year-round interest, winter-window offers, contract negotiation, loan availability improvements, country dropdown explicit closed/open state.
- Final transfer visuals/animations intentionally deferred.

V1.1 ADIM 8A — COMPETITION EXPERIENCE 2.0
- gameVersion: 1.1.0-dev.10
- SAVE_VERSION: 27 (değişmedi; competition context büyük ölçüde derived/read-only, yalnız domestic-cup BYE path için kompakt additive history kullanılır)
- Yeni TURNUVALAR bölümü: GENEL / LİG / KUPALAR / AVRUPA.
- FC.CompetitionContext; aşama, durum, importance, aggregate, turnuva yolu ve sonuç consequence bilgisinin canonical read-only kaynağıdır.
- HOME ve maç önizleme/sonuç ekranları kupa/Avrupa aşaması, rövanş/toplam skor, final ve eleme context'ini gösterir.
- Unified MatchdayEngine kronolojisi korunur; paralel turnuva ilerleme motoru eklenmemiştir.
- Final görsel tema, animasyon, ses, artwork ve National Team 2.0 bu adıma dahil değildir.


ADIM 8B — NATIONAL TEAM 2.0
- MİLLİ TAKIM artık ana navigasyonda ayrı kariyer merkezi.
- Salt-okunur FC.NationalTeamContext; çağrı açıklaması, kadro rolü, eleme/turnuva bağlamı, kariyer istatistikleri ve turnuva yolu.
- Milli fixture participation planları çağrı tickinde sabitlenir; UI RNG tüketmez.
- SAVE_VERSION 27 korunmuştur; 1.1.0-dev.9 -> dev.10 additive/schema-equivalent.

==================================================
FOOTBALL CAREER V1.1 — ADIM 10 LIFESTYLE 2.0
==================================================
- YAŞAM artık GENEL / FİNANS / EKİP / TESİSLER / TOPARLANMA merkezidir.
- Tek para kaynağı player.finances.balance olarak korunur.
- Payroll 400 günlük fiziksel sezon / 52 maaş dönemi modelini kullanmaya devam eder.
- Finans defteri 80 son işlem ve 250 exactly-once transaction key ile bounded tutulur.
- Menajer mevcut transfer reach / negotiation modifiers üzerinden çalışır; transfer dengesi değiştirilmedi.
- Kişisel antrenör, fizyoterapist ve tesisler PlayerModifiers üzerinden mevcut gelişim/fizik motorlarına bağlıdır; doğrudan OVR/POT satın almaz.
- Üç bounded toparlanma aksiyonu eklendi; cooldown ve bakiye kontrolü gameplay logic içindedir. Ciddi sakatlık anında silinemez.
- SimulationSession maaş ve ekip ücretlerini SUMMARY olarak gösterebilir; rutin finans işlemleri simülasyonu durdurmaz.
- SAVE_VERSION 27 korunur. dev.11 save, dev.12 migration yolunda Lifestyle alanlarını additive olarak initialize eder.
- Final görsel polish, animasyon, ses ve artwork eklenmedi.


V1.1 ADIM 11A — DATAPACK INTEGRITY + TRANSFER CONTEXT + FUNCTIONAL BUGFIX
- gameVersion 1.1.0-dev.13a; SAVE_VERSION 27.
- dataVersion 2026.09-step11a.0.1 after active club/league membership corrections.
- 55 active leagues are machine-audited for non-empty membership, expected club count and fixture-round integrity.
- 3. Liga repaired to 20 clubs / 38 player rounds; Eerste Divisie and other active lower tiers no longer initialize empty because of inactive club records.
- Old clubLeagueAssignments merge only newly missing active club IDs, preserving promotion/relegation assignments from the save.
- Transfer Center now uses canonical current league membership plus real live/previous standings context; numeric interest score remains unchanged.
- HAFİF / NORMAL / YOĞUN training selection now reflects canonical physical.trainingLoad and persists through save/load/simulation.
- Conservative typography and crest containment hotfix only; no final visual overhaul, GP architecture change or Calendar UX 2.1 work.


ADIM 11A.1 — REALISTIC LEAGUE SIZE HOTFIX
- gameVersion 1.1.0-dev.13a.1
- dataVersion 2026.09-step11a.1.0
- 55 active professional leagues audited; short-season floor is 14 real league matches per club.
- 16 previously short active leagues expanded with real club identities; no GP multiplier or detailed NPC-player universe added.
- ADIM 11A Transfer/Training/Typography/Crest fixes remain locked.

==================================================
ADIM 11B — PLAYER DEVELOPMENT 2.1 + CALENDAR UX 2.1
==================================================
Version: 1.1.0-dev.13b.4
SAVE_VERSION: 27
dataVersion: 2026.09-step11a.1.0

- Oyuncu gelişim yatırımı artık altı ana kategori üzerinden yapılır; ayrıntılı attribute değerleri canonical kalır.
- Kategori puanları ayrıntılı attribute değerlerinden türetilir ve gelecekteki radar arayüzü için FC.PlayerDevelopment API'sinden okunabilir.
- Harcanan GP categoryProgress havuzuna gider; günlük antrenman checkpoint'i uygun olduğunda deterministic olarak ilgili ayrıntılı attribute'a dönüşür.
- Calendar Simulation aynı FC.SimulationSession motorunu kullanır; DURAKLAT / DEVAM ET / SİMÜLASYONU BİTİR desteklenir.
- Calendar mount işlemi gameplay ilerletmez; aktif sahnede DOM bölgeleri güncellenir, tam sayfa rebuild yapılmaz.
- Oyuncu oluşturmada İKİSİ DE (preferredFoot = both) desteklenir.
- appearanceId alanı gelecekteki görsel kimlik için null olarak save-safe hazırlanmıştır; bu sürümde görsel asset/portrait/radar eklenmemiştir.


ADIM 11B.1A — Development Checkpoint Fix
- Category progress >=100 converts exactly once at a legitimate PhysicalEngine day checkpoint when the seasonal safety cap allows it.
- Overflow above 100 is preserved.
- Development UI distinguishes DÖNÜŞÜM HAZIR from SEZONLUK GELİŞİM SINIRINA ULAŞILDI.
- No GP economy, CareerCurve, simulation UX, TEAM page or visual overhaul changes.


ADIM 11B.1A.1 — Development Balance Hotfix
- Hard seasonal category conversion cap removed. CareerCurve, GP cost, age/potential resistance, diminishing returns and positional relevance remain authoritative.
- Categories at >=100 progress reject new GP investment with CATEGORY_READY_FOR_CONVERSION.
- UI disables the category investment button and displays DÖNÜŞÜM HAZIR until the next legitimate checkpoint.
- Legacy categorySeasonPoints and >100 overflow remain save-compatible; overflow is preserved after one conversion.
- No Simulation Event UX, TEAM page or final visual redesign work is included.


ADIM 11B.1B — SIMULATION EVENT UX + CONTROL BAR
- Active SimulationSession now classifies narrative events by canonical majorDecision metadata.
- Non-major narrative events are processed as PASSIVE_EVENT: deterministic first defined canonical choice, effects exactly once, feed summary, no blocking modal.
- majorDecision narrative events and match-specific interactive choices remain blocking decisions.
- Manual gameplay event presentation is unchanged.
- Calendar simulation controls moved to a compact sticky in-content top HUD with speed, progress/date, pause/resume and stop.
- Critical decision modal exposes SİMÜLASYONU BİTİR without auto-resolving the pending choice.
- ADIM 11B.1A.1 development behavior remains unchanged. TEAM page and final visual overhaul not started.


ADIM 11B.1C — TEAM HUB
- Added read-only TAKIM navigation/page for the user's current club.
- Shows canonical club/league/standings/contract context, club-scoped manager/teammate/fan relationships, current-club season projection, all-time club relationship totals and the real Club Legend criteria.
- Current-season club stats are projected from existing match logs + actual club fixtures so January-transfer contributions stay club-specific.
- All-time club totals use the existing RelationshipEngine club profile and naturally aggregate multiple spells.
- No new relationship system, squad/NPC universe, Club Legend rebalance or save schema was added.


ADIM 12A — FINAL UI/UX FOUNDATION
- Global visual tokens, typography, sidebar, top bar and shared components standardized.
- Global top bar no longer exposes POT; OVR receives dedicated hierarchy.
- appearanceId uses a safe initials fallback slot only; no portrait assets added.
- Dashboard mount no longer commits presentation-only derived data back into canonical player state.
- Gameplay systems remain locked; SAVE_VERSION 27 and dataVersion unchanged.


ADIM 12A.1 — Functional Regression Hotfix
- Ready Development categories expose a zero-GP DÖNÜŞTÜR action through canonical PlayerDevelopment conversion authority.
- GP investment stays blocked at >=100 progress.
- Calendar speed changes reschedule the active presentation timer; 1x/2x/4x/ANINDA are functional pacing controls.
- SİMÜLASYONU BİTİR now terminates active/manual-paused sessions to CANCELLED and exits to Maç Merkezi.
- Pending critical decisions remain unresolved when simulation is cancelled.
- No ADIM 12B page redesign or visual asset work.


ADIM 12B — HOME + PLAYER + DEVELOPMENT redesign; country autocomplete, club-name display and TeamHub standings projection UI integrity fixes.


ADIM 12C — TEAM + MATCH CENTER + TRANSFER REDESIGN
- TAKIM, MAÇ MERKEZİ and TRANSFER received deep UI/UX redesigns using existing canonical state.
- Top-bar club/season/day identity layout was hardened for short/long clubs and free agents.
- Match Center keeps SimulationSession as the sole simulation authority.
- Transfer Center keeps TransferMarket / NegotiationEngine as the canonical state machines.
- No gameplay formulas, save schema, datapack membership or generated visual assets were changed.


ADIM 12C.1A — SIMULATION CONTROL HOTFIX
- SİMÜLASYONU BİTİR now completes the original SimulationSession target instantly instead of cancelling at the current date.
- Critical player decisions still pause instant completion and resume the same session after resolution.
- 1x/2x/4x/ANINDA pacing is deliberately human-visible while remaining presentation-only.


ADIM 12C.1B — TOP BAR POT + GP HOTFIX
- Global top bar now shows canonical OVR / POT / current Development GP.
- Added read-only UIChrome.refreshPlayerMetrics() presentation helper.
- No simulation or Development action-flow changes in this step.


ADIM 12C.1C — DEVELOPMENT NO-REFRESH HOTFIX
- Development invest/convert actions now update their card/summary/radar/top-bar presentation in place.
- Full Player route remount was removed from Development actions.
- Scroll position and persistent shell nodes are preserved.
- Simulation and 12C.1B top-bar implementation remain unchanged.


ADIM 12D — CAREER + TOURNAMENTS + NATIONAL TEAM + LIFESTYLE REDESIGN
- Deep UI redesign for KARİYER, TURNUVALAR, MİLLİ TAKIM and YAŞAM only.
- Canonical Legacy/Records/Awards history, CompetitionContext, NationalTeamContext and LifestyleEngine projections preserved.
- No gameplay balance, save schema, simulation, transfer, development or datapack membership change.


ADIM 13A — VISUAL ASSET SPECIFICATION + INTEGRATION CONTRACT
- Added classic-JS visual manifest and presentation-only resolver.
- No generated visual assets are included or enabled.
- Existing appearanceId remains the only saved portrait reference.
- Zero-asset fallback behavior is mandatory and tested.

ADIM 13B.1 — PLAYER PORTRAIT INTEGRATION
- Integrated the approved player_01 ... player_05 portraits as local 768x1024 WebP files.
- Added five-option GÖRÜNÜMÜNÜ SEÇ flow; new careers default deterministically to player_01.
- Existing saves with null/missing/unknown appearanceId keep the initials fallback and are not migrated.
- Added one reusable FC.VisualAssets portrait renderer with runtime image-error fallback.
- HOME, OYUNCU, KARİYER and the compact top bar now reuse the same appearanceId renderer.
- player_06 ... player_12 remain reserved and disabled.


ADIM 13B.2A — CONTRACT EXPIRY + FREE AGENT + RENEWAL + OFFER INTERRUPTION
- Contract expiry now transitions exactly once to a playable free-agent state.
- Free agents can advance calendar time and receive fee-free contract offers.
- Current-club renewal offers reuse NegotiationEngine.
- Actionable transfer/free-agent/renewal offers pause the existing SimulationSession before they can be skipped.


ADIM 13B.2B — TRANSFER + LOAN FLOW 3.0
- Added season-based loans with parent/loan club identity and exactly-once return.
- Negotiation counters now wait 1-3 canonical days for club response.
- TERMS_AGREED no longer transfers the player; explicit final signature is required.
- Added simultaneous negotiations, bounded transfer competition, market value/fee visibility and functional Transfer Center tabs.


ADIM 13B.3 — CALENDAR + NOTIFICATION CENTER + FIXTURE EXPERIENCE 3.0
- Rebuilt Calendar presentation as a bounded monthly football-season calendar with selected-day events.
- Removed high-frequency broad calendar repaint/fade behavior during live simulation; shell/page nodes stay mounted.
- Added bounded exactly-once Notification Center with global top-bar inbox.
- Added shared visual fixture cards and canonical continental/relegation standings markers.
- Simulation speed/decision semantics and gameplay formulas remain unchanged.


ADIM 13B.4A — PLAYER DEVELOPMENT CURVE + OVR REBALANCE 3.0
- Rebalanced early-age development efficiency, category cost scaling and potential-proximity resistance while preserving GP rewards and visible +1 conversion.
- Wonderkid/Breakout remain canonical accelerators, but ordinary 15-16 year-old growth is no longer discounted.
- OverallCalculator remains position-weighted; positional weight concentration is softened so secondary relevant attributes matter more.
- Development UI now exposes effective GP-to-progress gain.

ADIM 13B.4A.1 — SEASON FLOW + OFFER INTERRUPTION + TRANSFER MONEY + CALENDAR RESPONSIVE HOTFIX
- Ordinary transfer, loan, free-agent and renewal offers are notification-driven and no longer pause simulation merely because they exist.
- Only true negotiation decisions such as COUNTERED / TERMS_AGREED remain blocking through the existing SimulationSession path.
- Added exactly-once offer-expiry warning/expiry notifications and preserved canonical offer records.
- Added canonical YENİ SEZONA BAŞLA / decision-required season-summary flow through SeasonEngine.
- Strengthened Transfer Center market-value / actual-fee presentation and transfer-history money context.
- Fixed Calendar 3.0 right-rail clipping at 1366 desktop while preserving the 1920 two-column layout.
- ADIM 13B.4A development/OVR balance formulas are unchanged.

ADIM 13B.4B — INJURY EXPERIENCE + CLUB STATUS / ICON / LEGEND 2.0
- Added normalized MINOR/MODERATE/MAJOR/SEVERE injury tiers with rare long-term severe injuries.
- Added bounded MAJOR/SEVERE comeback state, rehabilitation decision event, recovery notifications and rare limited severe physical decline.
- Fixed the shared CareerUI event-choice resolution path so visible narrative choices resolve once, save once and close only after successful canonical resolution.
- Added deterministic club-scoped recognition tiers: TARAFTARIN GÖZDESİ, KULÜP İKONU and KULÜP EFSANESİ.
- Club Legend now supports Loyalty, Golden Era and lower-reputation Club Hero pathways while preserving club relationship history and loan restrictions.
- ADIM 13B.4A Development/OVR balance and ADIM 13B.4A.1 flow/responsive behavior remain unchanged.
