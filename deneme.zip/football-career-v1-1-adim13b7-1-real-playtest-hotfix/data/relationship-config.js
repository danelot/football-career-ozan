(function(){"use strict";window.FC_DATA=window.FC_DATA||{};window.FC_DATA.relationshipConfig={
 version:2,
 bounds:{relationshipMin:0,relationshipMax:100,fanMin:0,fanMax:100,traitMin:0,traitMax:100},
 starting:{
  managerByRole:{Academy:43,Prospect:47,Rotation:53,"First Team":60},
  teammates:50,fans:48,clubStatus:4,
  traits:{LOYALTY:50,AMBITION:50,PROFESSIONALISM:55,PASSION:50,COMPOSURE:50}
 },
 match:{
  manager:{poor2:-1.5,poor1:-0.8,good1:.4,good2:.9,good3:1.4,elite:2,goal:.28,assist:.22,motm:.6,win:.2,big:.5,cleanSheet:.3},
  teammates:{appearance:.12,poor:-.28,good:.22,assist:.24,win:.15,motm:.18},
  fans:{appearance:.10,poorBig:-.40,good:.35,goal:.35,assist:.20,motm:.70,derby:.80,final:1.0,win:.12,cleanSheet:.20}
 },
 season:{manager:.6,teammates:.8,fans:.6},
 trophy:{manager:1.2,teammates:2.2,fans:3.0,status:5},
 role:{
  order:["Academy","Prospect","Rotation","First Team"],
  labels:{Academy:"Akademi",Prospect:"Gelecek Vadeden",Rotation:"Rotasyon","First Team":"Düzenli İlk 11"},
  promote:{
   Academy:{trust:52,apps:5,rating:6.55,gap:-14},
   Prospect:{trust:60,apps:6,rating:6.75,gap:-10},
   Rotation:{trust:70,apps:7,rating:6.95,gap:-6}
  },
  demote:{trust:34,rating:6.15,apps:8,hardTrust:24,cooldownAppearances:6}
 },
 status:{
  tiers:[
   {id:"NEWCOMER",min:0,label:"Yeni Transfer"},
   {id:"SQUAD_PLAYER",min:10,label:"Kadro Oyuncusu"},
   {id:"REGULAR",min:25,label:"Düzenli İlk 11"},
   {id:"KEY_PLAYER",min:40,label:"Kilit Oyuncu"},
   {id:"STAR",min:55,label:"Yıldız"},
   {id:"FAN_FAVORITE",min:70,label:"Taraftarın Gözdesi"},
   {id:"CLUB_ICON",min:82,label:"Kulüp İkonu"},
   {id:"CLUB_LEGEND",min:92,label:"Kulüp Efsanesi"}
  ],
  legend:{minSeasons:4,minAppearances:110,minFans:82,minAverageRating:7.05,minTrophies:3,minMajorEvidence:1}
 },
 support:{baseYoung:6,rotationBonus:2,academyBonus:2,trustBonusThreshold:70,trustBonus:1,ageMax:21,cap:10},
 historyCaps:{events:220,processedFixtures:140,processedSources:220,recentChanges:20,recentAppearances:8,clubProfiles:30}
};})();