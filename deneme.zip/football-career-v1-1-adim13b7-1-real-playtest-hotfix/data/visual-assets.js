(function () {
  "use strict";

  window.FC_VISUALS = {
    version: 1,
    generatedAssetsReady: true,

    players: {
      player_01: { id:"player_01", src:"assets/players/player_01.webp", enabled:true, objectPosition:"50% 32%" },
      player_02: { id:"player_02", src:"assets/players/player_02.webp", enabled:true, objectPosition:"50% 32%" },
      player_03: { id:"player_03", src:"assets/players/player_03.webp", enabled:true, objectPosition:"50% 32%" },
      player_04: { id:"player_04", src:"assets/players/player_04.webp", enabled:true, objectPosition:"50% 32%" },
      player_05: { id:"player_05", src:"assets/players/player_05.webp", enabled:true, objectPosition:"50% 32%" },
      player_06: { id:"player_06", src:"assets/players/player_06.webp", enabled:false },
      player_07: { id:"player_07", src:"assets/players/player_07.webp", enabled:false },
      player_08: { id:"player_08", src:"assets/players/player_08.webp", enabled:false },
      player_09: { id:"player_09", src:"assets/players/player_09.webp", enabled:false },
      player_10: { id:"player_10", src:"assets/players/player_10.webp", enabled:false },
      player_11: { id:"player_11", src:"assets/players/player_11.webp", enabled:false },
      player_12: { id:"player_12", src:"assets/players/player_12.webp", enabled:false }
    },

    competitionThemes: {
      DEFAULT_LEAGUE: {
        id:"DEFAULT_LEAGUE", enabled:false, src:null, hero:null, overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"league"
      },
      DOMESTIC_CUP: {
        id:"DOMESTIC_CUP", enabled:true, src:"assets/themes/theme_domestic_cup_01.webp",
        hero:"assets/themes/theme_domestic_cup_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"domestic_cup",
        recommendedPosition:"right center", recommendedOverlay:"normal"
      },
      UCL: {
        id:"UCL", enabled:true, src:"assets/themes/theme_ucl_01.webp",
        hero:"assets/themes/theme_ucl_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"continental_elite",
        recommendedPosition:"right center", recommendedOverlay:"normal"
      },
      UEL: {
        id:"UEL", enabled:true, src:"assets/themes/theme_uel_01.webp",
        hero:"assets/themes/theme_uel_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"continental_secondary",
        recommendedPosition:"right center", recommendedOverlay:"normal"
      },
      UECL: {
        id:"UECL", enabled:true, src:"assets/themes/theme_uecl_01.webp",
        hero:"assets/themes/theme_uecl_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"continental_tertiary",
        recommendedPosition:"right center", recommendedOverlay:"normal"
      },
      NATIONAL_TEAM: {
        id:"NATIONAL_TEAM", enabled:true, src:"assets/themes/theme_national_team_01.webp",
        hero:"assets/themes/theme_national_team_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"national",
        recommendedPosition:"right center", recommendedOverlay:"normal"
      },
      MAJOR_INTERNATIONAL: {
        id:"MAJOR_INTERNATIONAL", enabled:true, src:"assets/themes/theme_major_international_01.webp",
        hero:"assets/themes/theme_major_international_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"international_major",
        recommendedPosition:"right center", recommendedOverlay:"normal"
      },
      FINAL_TROPHY_MATCH: {
        id:"FINAL_TROPHY_MATCH", enabled:true, src:"assets/themes/theme_final_trophy_match_01.webp",
        hero:"assets/themes/theme_final_trophy_match_01.webp", overlay:null,
        type:"theme-background", category:"competition-theme", accentKey:"final",
        recommendedPosition:"right center", recommendedOverlay:"final"
      }
    },

    presentation: {
      TRANSFER_OFFER: { id:"TRANSFER_OFFER", src:"assets/presentation/transfer_offer_01.webp", enabled:true, type:"presentation-background", category:"transfer" },
      NEGOTIATION: { id:"NEGOTIATION", src:"assets/presentation/negotiation_01.webp", enabled:true, type:"presentation-background", category:"transfer" },
      CONTRACT_SUCCESS: { id:"CONTRACT_SUCCESS", src:"assets/presentation/contract_success.webp", enabled:false },
      NEGOTIATION_FAILED: { id:"NEGOTIATION_FAILED", src:"assets/presentation/negotiation_failed.webp", enabled:false },
      CONTRACT_SIGNATURE: { id:"CONTRACT_SIGNATURE", src:"assets/presentation/contract_signature_01_v2.webp", enabled:true, type:"presentation-background", category:"transfer" },
      CONTRACT_TORN: { id:"CONTRACT_TORN", src:"assets/presentation/contract_torn.webp", enabled:false }
    },

    trophyMapping: {
      LEAGUE_TITLE: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      DOMESTIC_CUP: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      CONTINENTAL_CUP: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      INTERNATIONAL_TROPHY: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      PLAYER_AWARD: { resolver:"FC.TrophyAssets.getAwardAsset", fallbackType:"award" }
    },

    fallback: {
      player: { kind:"INITIALS", src:null },
      competitionTheme: { kind:"CSS_THEME", src:null, overlay:null, accentKey:"default" },
      presentation: { kind:"CSS_PANEL", src:null },
      trophy: { kind:"TROPHY_ASSETS", src:null }
    }
  };
})();
