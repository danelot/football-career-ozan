(function(){"use strict";
 function createState(player){return {seasonGrowth:0,rolePerformanceScore:0,trainingXP:0,matchXP:0,startingOverall:Number(player.overall||0),attributeChanges:{},attributePoints:0,developmentEvents:0};}
 function applyMatch(player,club,match,state){state=state||createState(player);if(Number(match&&match.minutes||0)>0)state.rolePerformanceScore+=(Number(match.minutes||0)/90)*Number(match.rating||6);state.seasonGrowth=Number(player.overall||0)-Number(state.startingOverall||player.overall||0);return state;}
 function finish(player,club,seasonRecord,state){
  state=state||createState(player);FC.OverallCalculator.recalculate(player);state.seasonGrowth=Number(player.overall||0)-Number(state.startingOverall||player.overall||0);
  player.development=player.development||{};player.development.lastSeasonGrowth=state.seasonGrowth;player.development.lastTrainingXP=0;player.development.lastMatchXP=0;player.development.legacyAutoGrowthDisabled=true;
  if(window.FC.DevelopmentPoints)FC.DevelopmentPoints.ensure(player);
  var contractRole=player.contract&&player.contract.squadRole||"Prospect",managerRole=window.FC.RelationshipEngine&&player.clubId?FC.RelationshipEngine.getManagerRole(player,player.clubId):contractRole;
  return {overallChange:state.seasonGrowth,potentialChange:0,rolePerformanceScore:Math.round(state.rolePerformanceScore*100)/100,trainingXP:0,matchXP:0,squadRoleEnd:managerRole,contractRoleEnd:contractRole,attributeChanges:state.attributeChanges||{},attributePoints:0,developmentEvents:0,manualDevelopment:true};
 }
 function developmentPace(){return 0;}
 function xpForMatch(){return 0;}
 function xpForTraining(){return 0;}
 window.FC.DevelopmentEngine={createState:createState,applyMatch:applyMatch,finish:finish,developmentPace:developmentPace,xpForMatch:xpForMatch,xpForTraining:xpForTraining,debugDevelopmentCurve:function(){return {legacyAutoGrowthDisabled:true,manualDevelopment:true};}};
})();
