(function(){"use strict";
  window.FC.Navigation={go:function(screen){var current=FC.State.peek?FC.State.peek().screen:FC.State.get().screen;if(current==="player-creation"&&window.FC.PlayerCreation&&FC.PlayerCreation.unmount)FC.PlayerCreation.unmount();FC.State.update({screen:screen});FC.Game.render();}};
})();
