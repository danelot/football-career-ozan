(function(){"use strict";
var CAP=60;
function clone(x){return FC.Utils.clone(x);}
function ensureState(state){state.career=state.career||{};var n=state.career.notificationCenter=state.career.notificationCenter||{version:1,items:[],keys:{},order:[]};n.items=n.items||[];n.keys=n.keys||{};n.order=n.order||[];return n;}
function peek(state){var n=state&&state.career&&state.career.notificationCenter;return n||{version:1,items:[],keys:{},order:[]};}
function stableKey(item){return String(item.sourceId||item.id||[item.type||"SYSTEM",item.season||"",item.day==null?"":item.day,item.title||""].join(":"));}
function add(state,item){if(!state||!state.career||!item)return {added:false};var n=ensureState(state),key=stableKey(item);if(n.keys[key])return {added:false,duplicate:true,key:key};var id=String(item.id||"notification:"+key).replace(/\s+/g,"_");var row={id:id,key:key,sourceId:item.sourceId||key,type:item.type||"SYSTEM",title:String(item.title||"Bildirim"),body:String(item.body||""),season:item.season||state.career.currentSeason||null,day:item.day==null?null:Number(item.day),createdAt:String((item.season||state.career.currentSeason||"")+":"+(item.day==null?"-":item.day)),read:false,route:item.route||null,context:item.context||null,priority:item.priority||"INFO"};n.keys[key]=1;n.order.push(key);n.items.push(row);while(n.items.length>CAP){var old=n.items.shift();if(old){delete n.keys[old.key];var ix=n.order.indexOf(old.key);if(ix>=0)n.order.splice(ix,1);}}return {added:true,item:clone(row),key:key};}
function items(state){return (peek(state||FC.State.peek()).items||[]).slice().reverse().map(clone);}
function unreadCount(state){return (peek(state||FC.State.peek()).items||[]).reduce(function(a,x){return a+(x.read?0:1);},0);}
function markRead(id){var state=FC.State.get(),n=ensureState(state),r=n.items.find(function(x){return x.id===id;});if(!r||r.read)return false;r.read=true;FC.State.set(state);if(window.FC.SaveManager)FC.SaveManager.requestSave("notification_read");return true;}
function markAllRead(){var state=FC.State.get(),n=ensureState(state),changed=false;n.items.forEach(function(x){if(!x.read){x.read=true;changed=true;}});if(!changed)return false;FC.State.set(state);if(window.FC.SaveManager)FC.SaveManager.requestSave("notifications_read_all");return true;}
function clearForTests(state){if(state&&state.career)state.career.notificationCenter={version:1,items:[],keys:{},order:[]};}
window.FC.NotificationCenter={CAP:CAP,add:add,items:items,unreadCount:unreadCount,markRead:markRead,markAllRead:markAllRead,peek:peek,clearForTests:clearForTests};
})();
