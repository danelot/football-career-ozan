(function(){"use strict";
  var enabled=false,installed=false,metrics={};
  function now(){return performance.now();}
  function add(name,ms){var m=metrics[name];if(!m){m=metrics[name]={count:0,totalMs:0,minMs:null,maxMs:0,lastMs:0};}m.count++;m.totalMs+=ms;m.lastMs=ms;m.minMs=m.minMs==null?ms:Math.min(m.minMs,ms);m.maxMs=Math.max(m.maxMs,ms);}
  function names(x){return Array.isArray(x)?x:[x];}
  function measure(name,fn){if(!enabled)return fn();var t=now();try{return fn();}finally{var d=now()-t;names(name).forEach(function(n){add(n,d);});}}
  function wrap(obj,key,name,nameFn){if(!obj||typeof obj[key]!=="function"||obj[key].__fcPerfWrapped)return false;var original=obj[key];function wrapped(){if(!enabled)return original.apply(this,arguments);var label=nameFn?nameFn(arguments):name,t=now();try{return original.apply(this,arguments);}finally{var d=now()-t;names(label).forEach(function(n){add(n,d);});}}wrapped.__fcPerfWrapped=true;wrapped.__fcPerfOriginal=original;obj[key]=wrapped;return true;}
  function install(){if(installed)return true;installed=true;
    wrap(FC.State,"get","state.get_clone");
    wrap(FC.State,"set","state.set_clone");
    wrap(FC.State,"commit","state.commit_clone");
    wrap(FC.SaveManager,"manualSave","save.manual_total");
    wrap(FC.TransferMarket,"tickState","transfer.tick_state");
    wrap(FC.NotificationCenter,"add","notification.add");
    wrap(FC.CalendarExperience,"events","calendar.project_events");
    wrap(FC.TeamHub,"mount","ui.team_hub");
    wrap(FC.SeasonSummary,"summaryMount","ui.season_summary");
    wrap(FC.PhysicalEngine,"advanceToDay","calendar.advance_to_next_match",function(args){var p=args[0]&&args[0].physical,start=Number(p&&p.lastProcessedDay||0),target=Number(args[1]||0),delta=Math.max(0,target-start);return delta===1?"calendar.advance_one_day":"calendar.advance_to_next_match";});
    wrap(FC.SeasonEngine,"advanceToNextSeason","calendar.season_boundary");
    wrap(FC.MatchdayEngine,"getNextPlayerMatch","match.get_next_match");
    wrap(FC.MatchdayEngine,"playNext","match.simulate_player_match");
    wrap(FC.MatchdayEngine,"quick","match.quick_sim",function(args){return Number(args[0]||5)===5?"match.quick_sim_5":"match.quick_sim";});
    wrap(FC.WorldPlayers,"processSeason","world.npc_processing");
    wrap(FC.NPCDevelopmentEngine,"update","world.npc_development");
    wrap(FC.YouthIntakeEngine,"processSeason","world.youth_intake");
    wrap(FC.NPCRetirementEngine,"shouldRetire","world.npc_retirement");
    wrap(FC.WorldContinuityEngine,"maintain","world.league_world_processing");
    wrap(FC.WorldSeason,"commitActiveSeason","world.league_season_commit");
    wrap(FC.CompetitionSeason,"initialize","world.competition_processing.initialize");
    wrap(FC.CompetitionSeason,"finalizeAll","world.competition_processing.finalize");
    wrap(FC.InternationalCalendar,"simulateToDate","world.competition_processing.international");
    wrap(FC.SaveManager,"save","save.total");
    wrap(FC.SaveManager,"load","load.total");
    wrap(FC.Dashboard,"mount","ui.home");
    wrap(FC.UICareer,"mount","ui.career");
    wrap(FC.LeagueUI,"mount","ui.team");
    wrap(FC.UIMatchCenter,"mount","ui.matches");
    wrap(FC.TransferCenter,"mount","ui.transfer");
    wrap(FC.UIPlayer,"mount","ui.player");
    wrap(FC.WorldPlayersUI,"mount",["ui.world","ui.world.players_scout"]);
    wrap(FC.FinancesUI,"mount","ui.lifestyle");
    return true;
  }
  function report(){var out={enabled:enabled,installed:installed,generatedAt:new Date().toISOString(),metrics:{}};Object.keys(metrics).sort().forEach(function(k){var m=metrics[k];out.metrics[k]={count:m.count,totalMs:Number(m.totalMs.toFixed(3)),avgMs:Number((m.totalMs/Math.max(1,m.count)).toFixed(3)),minMs:Number((m.minMs||0).toFixed(3)),maxMs:Number(m.maxMs.toFixed(3)),lastMs:Number(m.lastMs.toFixed(3))};});return out;}
  window.FC.Perf={enable:function(){install();enabled=true;return true;},disable:function(){enabled=false;return true;},reset:function(){metrics={};return true;},getReport:report,printReport:function(){var r=report();if(console&&console.table)console.table(r.metrics);else console.log("[FC Perf]",r);return r;},measure:measure,install:install,isEnabled:function(){return enabled;}};
  document.addEventListener("DOMContentLoaded",install);
})();
