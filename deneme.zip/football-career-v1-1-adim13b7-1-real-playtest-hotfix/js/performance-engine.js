(function(){
  "use strict";
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function roleValue(role,key){var r=FC.SeasonConfig.roleWeights[role]||FC.SeasonConfig.roleWeights.Prospect;return r[key]||0;}
  function effectiveRole(player){return window.FC.PlayingTime?FC.PlayingTime.managerRole(player):(player.loan&&player.loan.status==="active"&&player.loan.squadRole?player.loan.squadRole:(player.contract&&player.contract.squadRole));}
  function isProspectRole(player){var role=effectiveRole(player);return role==="Prospect"||role==="Academy";}
  function playingTimeScore(player,club){
    if(window.FC.PlayingTime)return FC.PlayingTime.probabilities(player,club).factors.squadScore;
    var gap=Number(player.overall||0)-Number(club.squadStrength||50),cfg=FC.SeasonConfig.playingTime||{},youthDelta=Number(club.youthPolicy||50)-50,academyDelta=Math.max(0,Number(club.academyQuality||50)-60),prospectBonus=isProspectRole(player)?Math.max(0,youthDelta)*(cfg.prospectYouthBonusWeight||0)+academyDelta*(cfg.prospectAcademyBonusWeight||0):0;
    var physical=window.FC.PhysicalEngine?FC.PhysicalEngine.selectionModifier(player):{squad:0};return clamp(48+gap*3.0+(Number(player.form||50)-50)*0.24+(Number(player.morale||70)-60)*0.12+roleValue(effectiveRole(player),"squad")+youthDelta*(cfg.youthPolicySquadWeight||0.16)+prospectBonus-(Number(player.age||17)<=16?2:0)+physical.squad,4,96);
  }
  function starterScore(player,club){
    if(window.FC.PlayingTime)return FC.PlayingTime.probabilities(player,club).factors.starterScore;
    var gap=Number(player.overall||0)-Number(club.squadStrength||50),cfg=FC.SeasonConfig.playingTime||{},youthDelta=Number(club.youthPolicy||50)-50,prospectBonus=isProspectRole(player)?Math.max(0,youthDelta)*(cfg.prospectYouthStarterBonusWeight||0):0;
    var physical=window.FC.PhysicalEngine?FC.PhysicalEngine.selectionModifier(player):{starter:0};return clamp(29+gap*3.4+(Number(player.form||50)-50)*0.30+(Number(player.morale||70)-60)*0.13+roleValue(effectiveRole(player),"starter")+youthDelta*(cfg.youthPolicyStarterWeight||0.10)+prospectBonus-(Number(player.age||17)<=16?3:0)+physical.starter,1,91);
  }
  function squadProbabilities(player,club){
    if(window.FC.PlayingTime)return FC.PlayingTime.probabilities(player,club);
    var squad=playingTimeScore(player,club),starter=starterScore(player,club),starterP=clamp(starter/100,0.01,0.88),squadP=clamp(squad/100,0.04,0.97);var subP=clamp(squadP-starterP*0.72,0.04,0.57),unusedP=clamp(0.12+(squadP<0.55?0.12:0.05),0.06,0.28),notP=clamp(1-starterP-subP-unusedP,0.03,0.80),sum=starterP+subP+unusedP+notP;return {starter:starterP/sum,substitute:subP/sum,unused_bench:unusedP/sum,not_in_squad:notP/sum,playingTimeScore:squad,starterScore:starter};
  }
  function chooseSquadStatus(player,club,fixtureId){if(window.FC.PhysicalEngine&&!FC.PhysicalEngine.isAvailable(player)){return "not_in_squad";}if(window.FC.PlayingTime&&fixtureId)return FC.PlayingTime.resolveStatus(player,club,fixtureId);var p=squadProbabilities(player,club);return FC.RNG.weighted([{value:"starter",weight:p.starter},{value:"substitute",weight:p.substitute},{value:"unused_bench",weight:p.unused_bench},{value:"not_in_squad",weight:p.not_in_squad}]);}
  function updateFormMorale(player,match){
    var form=Number(player.form||50),morale=Number(player.morale||70);if(match.rating>0){if(match.rating>=8.3){form+=FC.RNG.int(2,4);}else if(match.rating>=7.4){form+=FC.RNG.int(1,3);}else if(match.rating>=6.5){form+=FC.RNG.int(-1,1);}else if(match.rating>=6.0){form-=FC.RNG.int(0,2);}else{form-=FC.RNG.int(1,3);}morale+=match.minutes>=60?1:0;morale+=match.goals+match.assists>0?1:0;if(match.redCard){morale-=2;}}else if(match.squadStatus==="unused_bench"){form+=FC.RNG.int(-1,0);morale-=FC.RNG.random()<0.30?1:0;}else{form+=FC.RNG.int(-1,0);morale-=FC.RNG.random()<0.45?1:0;}player.form=clamp(form,0,100);player.morale=clamp(morale,0,100);
  }

  function calculateSeasonImpact(player,season){
    if(!season||!season.league){return 50;}var s=season.league,opp=Math.max(1,Number(s.matchOpportunities||34)),share=Math.max(0,Math.min(1,Number(s.minutes||0)/(opp*90))),rating=Number(s.averageRating||6.4),g=Number(s.goals||0),a=Number(s.assists||0),pos=player&&player.position||"CM",production=0;
    if(pos==="ST"){production=g*1.55+a*0.55;}else if(pos==="CAM"||pos==="RW"||pos==="LW"){production=g*0.95+a*1.05;}else if(pos==="CM"){production=g*0.55+a*0.82;}else if(pos==="RB"||pos==="LB"){production=g*0.25+a*0.70;}else if(pos==="CB"||pos==="CDM"||pos==="GK"){production=Math.max(0,(rating-6.35)*7);}
    return clamp(46+(rating-6.45)*22+share*18+Math.min(13,production)+Number(season.development&&season.development.overallChange||0)*2.2,5,98);
  }
  window.FC.PerformanceEngine={effectiveRole:effectiveRole,playingTimeScore:playingTimeScore,starterScore:starterScore,squadProbabilities:squadProbabilities,chooseSquadStatus:chooseSquadStatus,updateFormMorale:updateFormMorale,calculateSeasonImpact:calculateSeasonImpact};
})();
