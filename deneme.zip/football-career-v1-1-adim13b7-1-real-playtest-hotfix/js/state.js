(function(){"use strict";
  var initial={screen:"main-menu",player:null,career:null,world:{season:"2026-27",year:2026},settings:{autosave:true,animations:true},simulationSession:null};
  function cloneStateData(v){var t=typeof v;if(v==null||t==="string"||t==="boolean")return v;if(t==="number")return isFinite(v)?v:null;if(t==="undefined"||t==="function"||t==="symbol")return undefined;if(Array.isArray(v)){var a=new Array(v.length);for(var i=0;i<v.length;i++){var av=cloneStateData(v[i]);a[i]=av===undefined?null:av;}return a;}if(v instanceof Date)return v.toISOString();var o={},keys=Object.keys(v);for(var j=0;j<keys.length;j++){var k=keys[j],x=cloneStateData(v[k]);if(x!==undefined)o[k]=x;}return o;}
  var state=cloneStateData(initial);
  window.FC.State={
    get:function(){return cloneStateData(state);},
    // Internal read-only reference for verified hot paths. Do not mutate the returned object.
    peek:function(){return state;},
    // Internal commit path: clone once, preserving State.get()/State.set() public semantics.
    commit:function(next){state=cloneStateData(next);return true;},
    set:function(next){state=cloneStateData(next);return next;},
    update:function(patch){Object.keys(patch||{}).forEach(function(k){state[k]=cloneStateData(patch[k]);});return this.get();},
    reset:function(){state=cloneStateData(initial);if(window.FC.WorldSeason&&FC.WorldSeason.resetRuntime){FC.WorldSeason.resetRuntime();}return this.get();}
  };
})();
