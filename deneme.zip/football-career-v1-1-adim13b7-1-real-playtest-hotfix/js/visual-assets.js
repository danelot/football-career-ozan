(function () {
  "use strict";

  window.FC = window.FC || {};

  function visuals(){
    return window.FC_VISUALS || {
      players:{}, competitionThemes:{}, presentation:{},
      fallback:{
        player:{kind:"INITIALS",src:null},
        competitionTheme:{kind:"CSS_THEME",src:null,overlay:null,accentKey:"default"},
        presentation:{kind:"CSS_PANEL",src:null},
        trophy:{kind:"TROPHY_ASSETS",src:null}
      }
    };
  }

  function clone(obj){
    if(!obj || typeof obj!=="object") return obj;
    var out={},k;
    for(k in obj) if(Object.prototype.hasOwnProperty.call(obj,k)) out[k]=obj[k];
    return out;
  }

  function playerFallback(id){
    var f=clone(visuals().fallback&&visuals().fallback.player)||{kind:"INITIALS",src:null};
    f.id=id||null;
    f.available=false;
    f.fallback=true;
    return f;
  }

  function getPlayerAppearance(input){
    var id=typeof input==="string"?input:(input&&input.appearanceId)||null;
    var row=id&&visuals().players&&visuals().players[id];
    if(!row || row.enabled!==true) return playerFallback(id);
    var out=clone(row);
    out.available=true;
    out.fallback=false;
    return out;
  }

  function competitionFallback(id){
    var f=clone(visuals().fallback&&visuals().fallback.competitionTheme)||{kind:"CSS_THEME",src:null,overlay:null,accentKey:"default"};
    f.id=id||"DEFAULT_LEAGUE";
    f.available=false;
    f.fallback=true;
    return f;
  }

  function getCompetitionTheme(id){
    id=String(id||"DEFAULT_LEAGUE").toUpperCase();
    var row=visuals().competitionThemes&&visuals().competitionThemes[id];
    if(!row || row.enabled!==true) return competitionFallback(id);
    var out=clone(row);
    out.available=true;
    out.fallback=false;
    return out;
  }

  function presentationFallback(id){
    var f=clone(visuals().fallback&&visuals().fallback.presentation)||{kind:"CSS_PANEL",src:null};
    f.id=id||null;
    f.available=false;
    f.fallback=true;
    return f;
  }

  function getPresentationAsset(id){
    id=String(id||"").toUpperCase();
    var row=visuals().presentation&&visuals().presentation[id];
    if(!row || row.enabled!==true) return presentationFallback(id);
    var out=clone(row);
    out.available=true;
    out.fallback=false;
    return out;
  }

  function getTrophyPresentation(type,id){
    if(window.FC.TrophyAssets){
      if(type==="award" && FC.TrophyAssets.getAwardAsset){
        var award=FC.TrophyAssets.getAwardAsset(id);
        return {id:id||null,type:"award",available:!!award,asset:award,fallback:!award||award.dedicated===false};
      }
      if(FC.TrophyAssets.getCompetitionAsset){
        var comp=FC.TrophyAssets.getCompetitionAsset(id);
        return {id:id||null,type:"competition",available:!!comp,asset:comp,fallback:!comp||comp.dedicated===false};
      }
    }
    return {id:id||null,type:type==="award"?"award":"competition",available:false,asset:null,fallback:true};
  }


  function esc(v){
    if(window.FC&&FC.Utils&&FC.Utils.escapeHtml)return FC.Utils.escapeHtml(String(v==null?"":v));
    return String(v==null?"":v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});
  }
  function initials(input){
    if(typeof input==="string")return input.slice(0,2).toUpperCase()||"OY";
    input=input||{};
    return (((input.firstName||"").charAt(0)+(input.lastName||"").charAt(0)).toUpperCase()||"OY");
  }
  function getSelectablePlayerAppearances(){
    var rows=visuals().players||{},out=[];
    Object.keys(rows).sort().forEach(function(id){var row=rows[id];if(row&&row.enabled===true){var x=clone(row);x.available=true;x.fallback=false;out.push(x);}});
    return out;
  }
  function portraitHtml(input,options){
    options=options||{};
    var id=typeof input==="string"?input:(input&&input.appearanceId)||null,
        a=getPlayerAppearance(id),
        nameInput=options.player||((input&&typeof input==="object")?input:null),
        ini=options.initials||initials(nameInput||options.name||"OY"),
        cls="fc-player-portrait "+(options.className||""),
        size=options.size||"md",
        label=options.alt||"Oyuncu portresi";
    if(!a.available||!a.src)return "<span class='"+esc(cls)+" fc-portrait-"+esc(size)+" is-fallback' data-appearance-id='"+esc(id||"")+"'><span class='fc-portrait-fallback'>"+esc(ini)+"</span></span>";
    return "<span class='"+esc(cls)+" fc-portrait-"+esc(size)+"' data-appearance-id='"+esc(id||"")+"'><img src='"+esc(a.src)+"' alt='"+esc(label)+"' loading='"+(options.eager?"eager":"lazy")+"' decoding='async' style='object-position:"+esc(a.objectPosition||"50% 32%")+"' onerror='FC.VisualAssets.handlePortraitError(this)'><span class='fc-portrait-fallback' hidden>"+esc(ini)+"</span></span>";
  }
  function handlePortraitError(img){
    if(!img)return;
    img.onerror=null;img.hidden=true;img.removeAttribute("src");
    var fb=img.nextElementSibling;if(fb)fb.hidden=false;
    var wrap=img.parentNode;if(wrap&&wrap.classList)wrap.classList.add("is-fallback");
  }

  function manifest(){
    return visuals();
  }

  window.FC.VisualAssets = {
    getPlayerAppearance:getPlayerAppearance,
    getSelectablePlayerAppearances:getSelectablePlayerAppearances,
    portraitHtml:portraitHtml,
    handlePortraitError:handlePortraitError,
    getCompetitionTheme:getCompetitionTheme,
    getPresentationAsset:getPresentationAsset,
    getTrophyPresentation:getTrophyPresentation,
    getManifest:manifest
  };
})();
