FINAL QA PASS 2 UI HOTFIX 3 (0.14.4.3)
- Club crest rendering normalized through shared bounded crest containers and child-image object-fit:contain rules.
- Central semantic crest sizes: xs 28px, small 40px, medium 60px, large 80px, hero 104px; screen-specific hero/prematch caps remain bounded.
- FC.ClubAssets mappings/URLs are unchanged; this is presentation-only.
- SAVE_VERSION remains 25; storageFormatVersion remains 1; dataVersion remains 2026.09-step13.0.2.



PHASE 2.0.2 — MATCH CENTER + PRESENTATION INTEGRITY HOTFIX
- Match Center international ownership now requires a saved selected call-up for upcoming fixtures; historical international fixtures require actual player match history. Generic national-team schedules are no longer treated as the player schedule.
- Match presentation now reveals player status chronologically. Final minutes/goals/assists/rating are withheld until full time; red-card/injury/substitute/exit states appear only when their stored minute has been reached.
- Real extra-time and penalty flags add presentation-only UZATMALAR / PENALTILAR phases without invented scores or kick timelines.
- SAVE_VERSION remains 25; football dataVersion remains 2026.09-step13.0.2.
- file:// architecture remains unchanged. A Chromium file:// smoke attempt was made in the delivery environment, but the browser process timed out with DBus/environment errors and produced no DOM; this is NOT counted as a real browser PASS.

FOOTBALL CAREER - FINAL QA PASS 2 UI HOTFIX 2
===============================

SÜRÜM
- gameVersion: 0.14.4.1
- SAVE_VERSION: 25
- dataVersion: 2026.09-step13.0.2

FINAL STABILIZATION / QA — PASS 1 (0.14.3)
- Targeted runtime fix: first-club signing and season transition now persist Matchday active-season initialization at gameplay boundaries so UI next-match reads no longer initialize schedules on throwaway clones or consume RNG.
- Compatibility load path initializes a missing active season only during explicit career load when the saved player has an active club/current season.
- SaveManager current-version loads are now idempotent: exact current SAVE_VERSION + gameVersion saves bypass migration.
- Modern 0.12+ saves missing youthMigrationVersion no longer receive a false current-year processed-youth marker; pre-0.12 legacy saves retain the conservative migration marker.
- SAVE_VERSION remains 25 and dataVersion remains 2026.09-step13.0.2.
- QA warning: serialized state growth remains a release blocker for PASS 1 lock. Measured state was ~6.3 MB with an initialized first active season and approached ~10 MB after five simulated seasons. No risky save-format/schema compaction was introduced silently.
- Chromium file:// smoke could not complete in the delivery container (DBus/zygote timeout); no interactive browser PASS is claimed.


FINAL UI/UX PHASE 1.0.1 — FUNCTIONAL UI INTEGRITY HOTFIX
- gameVersion 0.14.2; SAVE_VERSION remains 25; dataVersion remains 2026.09-step13.0.2.
- Fixed Career hub to call the locked LegacyEngine public API buildCareerEndSummary().
- Sidebar navigation honesty: TEAM -> LİGLER; MAÇLAR -> MAÇ MERKEZİ.
- Career subnavigation now exposes one honest ÖDÜLLER & REKORLAR destination instead of three labels pointing to the same screen.
- WORLD still exposes OYUNCULAR & SCOUT, MİLLİ TAKIM and DÜNYA ÖDÜLLERİ.
- No gameplay engine, save schema, scouting secrecy rule or football datapack content changed.
- Datapack sezonu: 2026/27

AMAÇ
ADIM 13 yeni büyük gameplay sistemi eklemez. ADIM 11 ve ADIM 12 motorları kilitli kalırken futbol dünyasının veri kapsamını büyütür; lig/piramit verisini genişletir ve merkezi, offline-safe kulüp arma altyapısı ekler.

DATAPACK ÖZETİ
- 96 ülke / milliyet kaydı
- 36 ülkede simulated league coverage
- 55 lig kaydı
- 46 yeni kariyerde simulated Tier A/B lig
- 9 Tier C / data-only alt lig
- 615 kulüp kaydı
- 569 yeni kariyerde kullanılabilir aktif kulüp
- Tier A persistent NPC/academy dünyası: performans ve localStorage güvenliği için 2026/27 ana piramitler
- Tier B: lig/fixture/club-strength simülasyonu; ağır persistent NPC/academy evreni oluşturmaz
- Tier C: datapack/search/history uyumluluğu için veri olarak tutulur, yeni kariyerde instantiate edilmez

TIER A TAM SİMÜLASYON
- Türkiye: Süper Lig, 1. Lig, 2. Lig (2. Lig motor limitleri nedeniyle birleşik/simplified)
- İngiltere: Premier League, Championship, League One, League Two
- İspanya: LaLiga, LaLiga Hypermotion
- Almanya: Bundesliga, 2. Bundesliga
- İtalya: Serie A
- Fransa: Ligue 1

TIER B HAFİF SİMÜLASYON
Ana lig/fixture/standings ve static club-strength simülasyonu vardır, fakat her kulüp için ayrı ağır NPC/academy world state üretilmez. Almanya 3. Liga, Serie B, Ligue 2 ve Portekiz/Hollanda/Belçika/İskoçya/Avusturya/İsviçre/Yunanistan/Hırvatistan/Sırbistan/Danimarka/Norveç/İsveç/Polonya/Çekya/Romanya/Ukrayna ile Brezilya/Arjantin/Uruguay/Kolombiya/Şili/Meksika/ABD/Japonya/Güney Kore/Suudi Arabistan/Avustralya/Fas/Mısır/Güney Afrika dahil geniş dünya kapsamı bu katmanda yer alır.

TIER C
Bazı ikincil alt lig kayıtları veri olarak korunur fakat yeni kariyerde ağır world assignment oluşturmaz. Bu tercih localStorage ve uzun-kariyer performansını korumak içindir. Eski ADIM 12 save'i bu kulüpleri zaten instantiate etmişse assignment korunur; datapack yeni kulüpleri olgun kariyere otomatik enjekte etmez.

BAŞLANGIÇ YERLEŞİMİ
Datapack 2026/27 sezonunu esas alır. Core audited Tier-A ligler 2026/27 başlangıç katılımcılarıyla güncellenmiştir. Engine başladıktan sonra promotion/relegation doğal olarak datapack başlangıcından ayrılabilir.

KULÜP VERİSİ
Her club stable id ile tanımlanır. Display name kimlik olarak kullanılmaz. Mevcut ADIM12 kulüp ID'lerinin reputation/financialPower/squadStrength/training/academy/youth değerleri korunmuştur; bu, locked transfer/offer/NPC dengesinin gereksiz rebalance edilmesini önler. Yeni kulüpler lig ve ülke seviyesine göre relative değer alır.

LİG PİRAMİTLERİ
- İngiltere: 4 katman, 20/24/24/24
- Türkiye: 3 simulated katman, 18/20/18 (2. Lig birleşik/simplified)
- İspanya: 2 katman, 20/22
- Almanya: 18/18 + 12-club simplified Tier-B 3. Liga
- İtalya: Serie A 20 + simplified Tier-B Serie B 16
- Fransa: Ligue 1 18 + simplified Tier-B Ligue 2 16
Bazı küçük ülke alt ligleri Tier-C olduğu için aktif top flight'ta simulated relegation kapalıdır; karmaşık gerçek playoff formatları uydurulmamıştır.

AVRUPA KATILIMI
Mevcut UCL/UEL/UECL architecture korunur. Önceki country slots korunmuş, yeni simulated Avrupa ligleri için İsveç/Çekya/Romanya/Ukrayna lightweight slot mapping'i eklenmiştir. Slot sistemi gerçek UEFA access-list'in tam kopyası değildir; mevcut engine'in sadeleştirilmiş modelidir.

CLUB CREST / ASSET FOUNDATION
Merkezi veri: data/club-assets.js
Merkezi helper: js/club-assets.js
API:
- FC.ClubAssets.getCrest(clubId)
- getLocalCrest(clubId)
- getRemoteCrest(clubId)
- getFallback(clubId)
- getColors(clubId)
- badgeHtml(clubId, className)
- applyImage(img, clubId)
- handleError(img)

Resolution order:
1. localCrest tanımlıysa yerel paket asset'i
2. optional direct remote image URL
3. deterministic initials/color fallback badge

Core gameplay logoya bağlı değildir. Remote image hata verirse img gizlenir, onerror temizlenir ve fallback badge gösterilir; sonsuz onerror döngüsü yoktur. Logo verileri savegame/localStorage içine yazılmaz. Görseller loading='lazy' ile yalnız UI tarafından gerektiğinde yüklenir.

CREST COVERAGE - ADIM 13.0.2
- Toplam kulüp: 615
- Asset mapping: 291
- Local packaged crest: 0
- Optional remote crest: 291
- Fallback-only: 324
- Overall real-crest coverage: 47.32%
- Tier-A coverage: 197 / 269 = 73.23%
- Active top-flight coverage: 208 / 375 = 55.47%
- Reputation >= 88 coverage: 56 / 56 = 100%
- Eski orphan Bayern key `ger_bayern_munich` kaldırıldı; gerçek club ID `ger_bayern_munchen` kullanılır.

ASSET VALIDATION
- DatapackValidator asset map'i iki yönde denetler: asset ID mevcut club'a bağlı olmalı; asset kaydı local/remote source taşımalı.
- Orphan asset artık `orphanClubAsset:<clubId>` error üretir.
- Yeni GitHub remote crest'leri repository directory manifestlerinde exact filename üzerinden doğrulanmıştır; fuzzy/guess mapping final pakete alınmamıştır.
- GitHub raw URL branch seçimi repository-aware'dır: luukhopman/football-logos -> master; JoseArroyave/football-logos -> main.
- Wikimedia girdileri exact Commons file page / mevcut baseline mapping üzerinden tutulur.
- Remote görseller optional'dır. Ağ yoksa veya URL hata verirse deterministic initials/color fallback devreye girer; oyun akışı etkilenmez.
- Crest URL'leri savegame'e yazılmaz; yalnız datapack/UI verisidir.

MAJOR CLUB AUDIT
Türkiye, İngiltere, İspanya, Almanya, İtalya, Fransa, Portekiz, Hollanda, İskoçya, Brezilya, Arjantin, Suudi Arabistan, ABD ve Japonya için istenen major-club listesi kontrol edildi. São Paulo ve Racing Club dahil audit listesinin tamamında mapping vardır. Reputation >=88 grubunda coverage 100%'dür.

KNOWN CREST LIMITATIONS
- 324 kulüp hâlâ fallback-only durumundadır. Bunlar ağırlıklı olarak Tier-B/C, küçük lig ve alt-lig kulüpleridir.
- Remote kaynak erişimi ağ/host politikasına bağlıdır; bu nedenle fallback zorunlu ve kalıcı güvenlik katmanıdır.
- Bu patch gameplay, lig üyeliği veya transfer/NPC dengesini değiştirmez.
CREST / LİSANS NOTU
Kulüp armaları telif ve/veya marka korumasına tabi olabilir. Remote mapping yalnız optional presentation enhancement olarak düşünülmüştür. Bir dağıtımcı yerel logo paketliyorsa ilgili kullanım/lisans hakkını kendisi doğrulamalıdır. Oyun generic fallback badge'lerle tamamen çalışabilir.

OFFLINE / FILE://
Core çalışma modeli değişmedi:
- index.html çift tık
- file://
- backend yok
- local server yok
- fetch() yok
- XMLHttpRequest yok
- ES module yok
- runtime npm/Node/Python yok
- remote JS/CSS/CDN gerekmiyor
Remote crest yalnız normal <img> görsel isteğidir ve başarısız olması gameplay'i etkilemez.

SAVE UYUMLULUĞU
SAVE_VERSION 25 tutuldu; persistent schema değişmedi.
Yeni kariyerler Step13 expanded assignments kullanır.
Mevcut ADIM12 olgun kariyerleri kendi `world.clubLeagueAssignments` snapshot'ını korur. Yeni Step13 kulüpleri eski save'e sessizce enjekte edilmez. Testte 267-club / 3639-NPC eski world load sonrası 267 club / 3639 NPC olarak kaldı; yeni-club NPC injection 0 ve validator error 0.

PERFORMANCE-AWARE WORLD SCALING
İlk naive 609-club full-NPC denemesi fresh world'ü 8159 senior NPC / ~5.81 MB world JSON'a çıkardı ve reddedildi. Final Tier-A/B/C modelinde fresh persistent world ~3562 senior / ~2.55 MB'dır. Tier-B ligler yine standings/fixture simülasyonunda bulunur fakat full NPC/academy state üretmez.

LONG WORLD STRESS (representative deterministic harness)
Year 0:   senior 3562, academy 0,    FA 0,   world JSON 2,547,014 bytes
Year 10:  senior 3555, academy 1015, FA 598, world JSON 4,551,331 bytes
Year 20:  senior 3591, academy 1008, FA 760, world JSON 4,941,628 bytes
Year 30:  senior 3601, academy 1003, FA 701, world JSON 4,915,613 bytes
Year 50:  senior 3577, academy 1023, FA 730, world JSON 4,938,098 bytes
Year 75:  senior 3586, academy 1021, FA 768, world JSON 4,983,148 bytes
Year 100: senior 3596, academy 1017, FA 792, world JSON 5,016,266 bytes
100y duplicate NPC IDs: 0
100y world validator errors: 0

ELITE QUALITY REGRESSION
Year 30: OVR80+ 351 / OVR85+ 43 / OVR90+ 9
Year 50: OVR80+ 407 / OVR85+ 48 / OVR90+ 14
Year 100: OVR80+ 329 / OVR85+ 43 / OVR90+ 14
ADIM11.2.1 upper-tail calibration değiştirilmedi.

ROSTER REGRESSION
100-year representative run boyunca sampled checkpoints:
- below hardMin: 0
- above max: 0
- zero GK: 0
- zero ATT: 0
- academy cap violations / WorldPlayers validator errors: 0
- preferred target band year100: 223 / 264 full-NPC clubs

TRANSFER / YOUTH SCALE
100y representative totals:
- Youth generated: 29,098
- Academy promoted: 11,194
- Academy released: 15,788
- NPC material moves: 48,811 (~488/year average)
- Year100 moves: 522 = ~145 / 1000 senior
- Target replacements: 1,353 / 100 years
- Wonderkids: 299
- Generational: 5
Global youth intake cap and rarity calibration therefore remain bounded despite larger league datapack.

LİG STRESS
30 season expanded league harness:
- invalid assignments: 0
- missing assignments: 0
- table math errors: 0
- season validation errors: 0
- league history rows: 1,380

CUP / CONTINENTAL REGRESSION
- Türkiye Kupası 1000 simulations: invalid bracket/winner/penalty/champion/stuck = 0
- Continental groups 1000: table/duplicate/missing fixture errors = 0
- limited fields 2/3/5/7/16/17/31/32: structural errors = 0
- previous core qualification debug: expected slot counts preserved for TUR/ENG/ESP/ITA/GER/FRA.

STARTING OFFER REGRESSION
5000 low-OVR (age16, OVR50, POT74) runs:
- total offers: 20,654
- reputation >=80: 0
- reputation >=90: 0
- ineligible offers: 0
- average offered club reputation ~49.8
- max observed reputation 73
Expanded club pool therefore does not hand elite giants to a normal starting teenager.

MATCHDAY / LOCKED ENGINE STATUS
ADIM11.1.0.1 performance files remain byte-identical to ADIM12.0.1 for:
- js/state.js
- js/matchday-engine.js
- js/club-season-engine.js
- js/save-manager.js
Awards/records/NPC development/NPC retirement core files are also unchanged.
State.peek(), State.commit(), world passing and SaveManager clone reduction remain intact.

VALIDATOR
js/datapack-validator.js checks:
- duplicate country/league/club IDs
- invalid club country/league refs
- suspicious duplicate normalized club names
- expected active league sizes
- pyramid target integrity for simulated tiers
- crest coverage
Final datapack validator: errors 0, warnings 0.

KNOWN LIMITATIONS
- Step13 is not a licensed commercial football database. Core Tier-A starting placements were audited for 2026/27; many Tier-B leagues are explicitly simplified representative rosters rather than exhaustive official squad databases.
- Türkiye 2. Lig, Germany 3. Liga, Serie B and Ligue 2 may use simplified counts because the existing engine does not model every real group/playoff format.
- Tier-B clubs use static club strength rather than full persistent NPC/academy populations unless they enter a Tier-A persistent context through the existing world.
- Continental slot mapping remains a simplified engine model, not the full UEFA coefficient/access-list system.
- Crest coverage is intentionally partial. Generic fallback is the guaranteed offline path.
- Actual automated browser `file://` launch is environment-policy dependent; static dependency checks and engine-level offline tests were used here. No runtime server dependency was introduced.

ADIM 13 SONRASI
Büyük feature geliştirmesi bu adımla durur. Sonraki çalışma alanı stabilization, UI/UX, balance, performance, bug fixing ve polish olmalıdır.

==================================================
FINAL UI/UX OVERHAUL PHASE 1 — v0.14.0.1
==================================================
Navigation inventory (old -> new):
Dashboard/Kariyer -> ANA SAYFA
Season history / career summary -> KARİYER > GENEL / ZAMAN ÇİZELGESİ
Trophies -> KARİYER > KUPALAR
Awards / Records / Legacy / Hall of Fame -> KARİYER > ÖDÜLLER / REKORLAR / LEGACY
Relationships / rivalries -> KARİYER > İLİŞKİLER
League tables / league membership -> TAKIM > PUAN DURUMU
Next match / matchday / quick sim -> MAÇLAR
Transfer center / contracts / loans / offers -> TRANSFER
Attributes / development / fitness / training load / injury state -> OYUNCU
World players / youth / scouting -> DÜNYA > OYUNCULAR & SCOUT
National team -> DÜNYA > MİLLİ TAKIM
Money / agent / personal staff / facilities / transactions -> YAŞAM
Settings / save / delete -> sidebar bottom AYARLAR / KAYIT

Feature preservation audit:
player overview=reachable; match play=reachable; quick sim=reachable; fixtures/competition-aware next match=reachable;
standings=reachable; competitions=preserved; transfers/contracts/loans=reachable; training/attributes/fitness/injuries=reachable;
money/agent/trainer/facilities=reachable; relationships/events=reachable; national team=reachable;
world players/scouting=reachable; awards/records/legacy/Hall of Fame/trophies=reachable; save/load/delete=preserved.

HOME information architecture:
Before: one oversized profile area plus attributes, physical/training controls, contract/economy strip, career stats,
season history, transfer history, season timeline, next match and navigation controls (roughly 9 major visual blocks).
After: 4 major blocks — Player Hero, Next Match, Performance Snapshot, Quick Destinations.
Secondary systems moved to their dedicated navigation destinations.

Technical notes:
- New presentation files: js/ui-shell.js, js/ui-pages.js.
- No save schema change. SAVE_VERSION 25.
- dataVersion unchanged because football datapack content did not change.
- UI navigation does not consume FC.RNG or advance game state.
- FC.ClubAssets remains the single crest source/fallback system.
- Unknown scouting visibility continues to be produced by ScoutingEngine.getVisibleReport; world-players-ui.js was not changed.


FINAL UI/UX PHASE 2 (0.14.1)
- Phase 1 bilgi mimarisi korunarak futbol-game feel katmanı güçlendirildi.
- HOME: kulüp watermark/pitch geometrisi, daha güçlü oyuncu ve sonraki maç kompozisyonu.
- Pre-match/matchday/full-time: büyük crest, scoreboard ve sonuç sunumu; simülasyon motoru değişmedi.
- Career/awards/records: prestige/timeline/trophy presentation polish.
- Transfer/leagues/world/lifestyle: mevcut ekranlar ortak football visual language ile polish edildi.
- Match/career event modalı shared modal primitive üzerinden cinematic match-event varyantı kullanır.
- file://, classic scripts, optional remote crest fallback ve SAVE_VERSION 25 korunur.
- Gerçek file:// browser otomasyonu bu geliştirme ortamında garanti edilmemektedir; bağımsız browser smoke test önerilir.


FINAL UI/UX PHASE 2.0.1 — GAME FEEL COMPLETION
- gameVersion 0.14.1.1; SAVE_VERSION 25; dataVersion unchanged at 2026.09-step13.0.2.
- MAÇ MERKEZİ now reads the existing active-season player schedule only: up to 10 recent results and 10 upcoming fixtures, with TÜMÜ/LİG/KUPA/AVRUPA/MİLLİ filters. It does not create a second fixture engine.
- MAÇA ÇIK still routes to the existing Matchday UI. Quick-sim controls remain available from match preparation.
- Matchday presentation now wraps the already-generated MatchdayEngine result with a short HUD/event-feed sequence and a SONUCA GİT control. It never rerolls or changes the result and does not consume UI RNG.
- Timeline events shown during match presentation are limited to exact data actually stored by the existing game: substitute entry minute, resolved interactive career-event minute/outcome, red-card minute and injury minute. Ordinary goal/assist/yellow-card minutes are not stored on the returned match object and are therefore not invented; goal/assist totals and rating are revealed at full time. Halftime is presentation-only and does not fabricate a halftime score.
- Post-match interactive career events retain the existing CareerEventEngine resolution path; the UI resumes the already-generated result presentation after resolution without simulating the fixture again. Pre-result interruptions still stop before match generation.
- Career timeline now adds league context, existing club crests, recorded season trophies and club-switch callouts inferred only from consecutive recorded season clubIds. No transfer fee is invented.
- WORLD / scouting presentation was upgraded with DÜNYA FUTBOLU contextual navigation and public-information prospect cards. UNKNOWN rows continue to render only OVR ? / POT ?; no truePotential/trueProspectClass/hidden ranking value is placed in text, title, aria-label, data attributes or quality-coded CSS classes.
- Lifestyle user-facing labels were normalized to Turkish (MENAJER, TRANSFER ERİŞİMİ, PAZARLIK, ÜCRET, AĞ, / hafta, ANTRENMAN XP, TOPARLANMA, SAKATLIK RİSKİ, GÜN, etc.).
- Locked gameplay engines remain unchanged. No save schema or football datapack change.
- file:// classic-script architecture remains required. Real Windows Explorer double-click testing is environment-dependent; static/runtime harness results must not be described as a real browser test.


FINAL UI/UX PHASE 2.5 — TROPHY + AWARD VISUAL IDENTITY
- gameVersion 0.14.2; SAVE_VERSION 25; dataVersion remains 2026.09-step13.0.2.
- Added centralized FC.TrophyAssets with stable competitionId / awardId mappings and robust local fallbacks.
- Added original/custom local SVG artwork under assets/trophies and assets/awards; artwork is not official FIFA/UEFA/league/award imagery.
- Dedicated competition artwork: World Cup, UCL, UEL, UECL, EURO, Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Süper Lig, and the six existing domestic cups.
- Dedicated award artwork: all five award IDs actually emitted by AwardsEngine (World Player, Young Player, Goalkeeper, Turnuvanın Oyuncusu, Gol Kralı). Ballon d'Or was NOT added because it does not exist in the current AwardsEngine.
- Trophy Cabinet now groups repeated competition wins, preserving real seasons and counts. Career Timeline uses small matching artwork.
- Awards history uses distinct individual-award artwork. Existing league-champion season-end and international-trophy presentations reuse TrophyAssets.
- All artwork is local/offline/file:// safe; no fetch, CDN or runtime server. Missing/broken artwork degrades to deterministic generic trophy/award artwork, then a CSS glyph if even the local fallback fails.
- No competition/award logic, save schema, RNG, qualification, records, legacy or NPC simulation changes.


FINAL QA PASS 1.1 — SAVE STORAGE HOTFIX
- SAVE_VERSION remains 25; dataVersion remains 2026.09-step13.0.2.
- Save payload storageFormatVersion 1 compacts deterministic active league fixtures while runtime state remains fully expanded.
- Played league results and all non-derivable fixture fields are stored as per-fixture patches and restored on load.
- NPC players use a lossless columnar save-only representation; runtime npcPlayers objects are restored before gameplay.
- Existing expanded 0.14.3 and 0.14.2 saves remain loadable and are rewritten compactly on next save/load.
- No fetch/XHR/module/server/CDN dependency added; file:// architecture remains unchanged.
- Real browser quota/file:// smoke test could not be completed in the current container environment; size measurements were performed on actual JSON payloads.

FINAL QA PASS 2 (0.14.4)
- Save/load now persists the FC.RNG stream state so a browser reload cannot reroll future gameplay.
- Compact current-format saves are validated before expansion; unknown/corrupted storage payloads fail safely.
- SAVE_VERSION remains 25 and storageFormatVersion remains 1.
- FINAL MANUAL WINDOWS FILE:// SMOKE TEST REQUIRED: container Chromium could not complete a genuine file:// launch because of DBus/zygote environment errors.

UI HOTFIX 0.14.4.1
Transfer Center offer cards use a compact, responsive, transfer-scoped layout. Gameplay logic and SAVE_VERSION 25 are unchanged.