window.FC_DATA=window.FC_DATA||{};
window.FC_DATA.economyConfig={
 currency:"EUR",transactionHistoryLimit:300,
 payroll:{periodsPerSeason:52,physicalSeasonBlock:400,payrollDaysPerSeason:364},
 modifierCaps:{trainingXpMax:1.25,recoveryMax:1.25,injuryRiskMin:0.75,injuryDurationMin:0.78,reinjuryRiskMin:0.78,transferReachMax:1.18,negotiationMax:1.14},
 matchBonusRates:{appearance:0.035,goal:0.045,assist:0.03,gkCleanSheet:0.035},
 facilities:{
  homeGym:[{level:0,name:"None",cost:0,trainingXp:1,recovery:1},{level:1,name:"Basic Home Gym",cost:60000,trainingXp:1.02,recovery:1.01},{level:2,name:"Advanced Home Gym",cost:320000,trainingXp:1.04,recovery:1.015},{level:3,name:"Elite Home Gym",cost:1100000,trainingXp:1.06,recovery:1.02}],
  recoverySetup:[{level:0,name:"None",cost:0,recovery:1,fatigueRecovery:1},{level:1,name:"Basic Recovery Setup",cost:75000,recovery:1.03,fatigueRecovery:1.03},{level:2,name:"Advanced Recovery Suite",cost:380000,recovery:1.07,fatigueRecovery:1.07},{level:3,name:"Elite Recovery Setup",cost:1250000,recovery:1.11,fatigueRecovery:1.11}],
  performanceLab:[{level:0,name:"None",cost:0,trainingXp:1,sharpness:1,injuryRisk:1},{level:1,name:"Basic Performance Lab",cost:90000,trainingXp:1.015,sharpness:1.02,injuryRisk:.99},{level:2,name:"Advanced Performance Lab",cost:450000,trainingXp:1.03,sharpness:1.04,injuryRisk:.97},{level:3,name:"Elite Performance Lab",cost:1500000,trainingXp:1.045,sharpness:1.06,injuryRisk:.95}]
 }
};