window.FC_DATA=window.FC_DATA||{};
window.FC_DATA.personalTrainers=[
 {id:"trainer_basic",name:"Basic Personal Trainer",tier:"BASIC",cost:18000,weeklyCost:900,trainingXpModifier:1.04,fatigueModifier:.99,sharpnessModifier:1.01},
 {id:"trainer_pro",name:"Professional Trainer",tier:"PROFESSIONAL",cost:95000,weeklyCost:3500,trainingXpModifier:1.075,fatigueModifier:.985,sharpnessModifier:1.025},
 {id:"trainer_elite",name:"Elite Performance Trainer",tier:"ELITE",cost:380000,weeklyCost:9500,trainingXpModifier:1.11,fatigueModifier:.97,sharpnessModifier:1.04}
];
window.FC_DATA.privatePhysios=[
 {id:"physio_basic",name:"Basic Private Physio",tier:"BASIC",cost:25000,weeklyCost:1200,recoveryModifier:1.04,reinjuryRiskModifier:.96,injuryDurationModifier:.96},
 {id:"physio_pro",name:"Professional Private Physio",tier:"PROFESSIONAL",cost:125000,weeklyCost:4200,recoveryModifier:1.08,reinjuryRiskModifier:.91,injuryDurationModifier:.91},
 {id:"physio_elite",name:"Elite Private Physio",tier:"ELITE",cost:450000,weeklyCost:11000,recoveryModifier:1.12,reinjuryRiskModifier:.86,injuryDurationModifier:.84}
];