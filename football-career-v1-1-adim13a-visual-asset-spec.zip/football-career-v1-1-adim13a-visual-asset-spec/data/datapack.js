(function () {
  "use strict";
  window.FC_DATA = window.FC_DATA || {};
  window.FC_DATA.datapack = {
    gameVersion:"1.1.0-dev.15a",
    dataVersion:"2026.09-step11a.1.0",
    season:"2026-27",
    name:"Expanded World Datapack - ADIM 11A Integrity",
    type:"expanded",
    isComplete:true
  };
})();
