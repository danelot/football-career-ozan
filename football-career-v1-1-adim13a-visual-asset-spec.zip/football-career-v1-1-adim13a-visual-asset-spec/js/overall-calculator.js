(function(){
  "use strict";
  function calculate(position,attrs){var weights=FC.AttributeConfig.positionWeights[position]||FC.AttributeConfig.positionWeights.CM,sum=0,total=0;attrs=FC.Attributes.sanitize(attrs);Object.keys(weights).forEach(function(k){sum+=attrs[k]*weights[k];total+=weights[k];});return Math.max(1,Math.min(99,Math.round(sum/Math.max(1,total))));}
  function recalculate(player){if(!player||!player.attributes){return Number(player&&player.overall||1);}player.attributes=FC.Attributes.sanitize(player.attributes);var ovr=calculate(player.position,player.attributes);player.overall=ovr;player.attributeCategories=FC.Attributes.categories(player.attributes);player.gkAttributeCategories=FC.Attributes.gkCategories(player.attributes);return ovr;}
  function validate(player){var errors=[],calc=calculate(player.position,player.attributes||{});FC.AttributeConfig.allAttributes.forEach(function(k){var v=player.attributes&&player.attributes[k];if(typeof v!=="number"||isNaN(v)||v<1||v>99){errors.push("attribute:"+k);}});if(Number(player.overall)!==calc){errors.push("overall-sync");}return {ok:errors.length===0,errors:errors,calculatedOverall:calc,displayedOverall:calc};}
  window.FC.OverallCalculator={calculate:calculate,recalculate:recalculate,validate:validate};
})();
