(function () {
  "use strict";

  window.FC = window.FC || {};

  function visuals(){
    return window.FC_VISUALS || {
      players:{}, competitionThemes:{}, presentation:{},
      fallback:{
        player:{kind:"INITIALS",src:null},
        competitionTheme:{kind:"CSS_THEME",src:null,overlay:null,accentKey:"default"},
        presentation:{kind:"CSS_PANEL",src:null},
        trophy:{kind:"TROPHY_ASSETS",src:null}
      }
    };
  }

  function clone(obj){
    if(!obj || typeof obj!=="object") return obj;
    var out={},k;
    for(k in obj) if(Object.prototype.hasOwnProperty.call(obj,k)) out[k]=obj[k];
    return out;
  }

  function playerFallback(id){
    var f=clone(visuals().fallback&&visuals().fallback.player)||{kind:"INITIALS",src:null};
    f.id=id||null;
    f.available=false;
    f.fallback=true;
    return f;
  }

  function getPlayerAppearance(input){
    var id=typeof input==="string"?input:(input&&input.appearanceId)||null;
    var row=id&&visuals().players&&visuals().players[id];
    if(!row || row.enabled!==true) return playerFallback(id);
    var out=clone(row);
    out.available=true;
    out.fallback=false;
    return out;
  }

  function competitionFallback(id){
    var f=clone(visuals().fallback&&visuals().fallback.competitionTheme)||{kind:"CSS_THEME",src:null,overlay:null,accentKey:"default"};
    f.id=id||"DEFAULT_LEAGUE";
    f.available=false;
    f.fallback=true;
    return f;
  }

  function getCompetitionTheme(id){
    id=String(id||"DEFAULT_LEAGUE").toUpperCase();
    var row=visuals().competitionThemes&&visuals().competitionThemes[id];
    if(!row || row.enabled!==true) return competitionFallback(id);
    var out=clone(row);
    out.available=true;
    out.fallback=false;
    return out;
  }

  function presentationFallback(id){
    var f=clone(visuals().fallback&&visuals().fallback.presentation)||{kind:"CSS_PANEL",src:null};
    f.id=id||null;
    f.available=false;
    f.fallback=true;
    return f;
  }

  function getPresentationAsset(id){
    id=String(id||"").toUpperCase();
    var row=visuals().presentation&&visuals().presentation[id];
    if(!row || row.enabled!==true) return presentationFallback(id);
    var out=clone(row);
    out.available=true;
    out.fallback=false;
    return out;
  }

  function getTrophyPresentation(type,id){
    if(window.FC.TrophyAssets){
      if(type==="award" && FC.TrophyAssets.getAwardAsset){
        var award=FC.TrophyAssets.getAwardAsset(id);
        return {id:id||null,type:"award",available:!!award,asset:award,fallback:!award||award.dedicated===false};
      }
      if(FC.TrophyAssets.getCompetitionAsset){
        var comp=FC.TrophyAssets.getCompetitionAsset(id);
        return {id:id||null,type:"competition",available:!!comp,asset:comp,fallback:!comp||comp.dedicated===false};
      }
    }
    return {id:id||null,type:type==="award"?"award":"competition",available:false,asset:null,fallback:true};
  }

  function manifest(){
    return visuals();
  }

  window.FC.VisualAssets = {
    getPlayerAppearance:getPlayerAppearance,
    getCompetitionTheme:getCompetitionTheme,
    getPresentationAsset:getPresentationAsset,
    getTrophyPresentation:getTrophyPresentation,
    getManifest:manifest
  };
})();
