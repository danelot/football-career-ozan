(function(){"use strict";
var VERSION=1;
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function club(id){return (FC_DATA.clubs||[]).find(function(c){return c.id===id;})||null;}
function hash01(s){var h=2166136261,i;for(i=0;i<String(s).length;i++){h^=String(s).charCodeAt(i);h=Math.imul(h,16777619);}return ((h>>>0)%10000)/10000;}
function baseStrength(c){return clamp(Number(c&&c.squadStrength||50)*.78+Number(c&&c.reputation||50)*.16+Number(c&&c.trainingQuality||50)*.03+Number(c&&c.financialPower||50)*.03,32,94);}
function deriveStrength(c){var jitter=(hash01(c.id+"|lw1")-.5)*1.2;return Math.round(clamp(baseStrength(c)+jitter,32,94)*10)/10;}
function cleanupLegacy(w){
  ["npcPlayers","npcPlayersStorage","npcRetiredArchive","npcSeasonPerformance","npcSeasonMarkers","npcMaintenanceMarkers","npcTargetReplenishmentMarkers","npcTransferHistory","npcEvents","npcTransferKeys","npcRenewalKeys","npcNextId","npcIdHighWatermark","npcWorldVersion","npcGeneratedYear","npcRosterRepairVersion","npcRosterConfigVersion","npcTargetReplenishmentVersion","npcContractContinuityVersion","npcRetirementSummary","youthIntakeState","youthMigrationVersion","scouting"].forEach(function(k){delete w[k];});
}
function ensure(w,career){
  w=w||{};
  var lw=w.lightweightWorld=w.lightweightWorld||{version:VERSION,clubStrengths:{},seasonMarkers:{},evolutionHistory:[]};
  lw.version=VERSION;lw.clubStrengths=lw.clubStrengths||{};lw.seasonMarkers=lw.seasonMarkers||{};lw.evolutionHistory=lw.evolutionHistory||[];
  (FC_DATA.clubs||[]).forEach(function(c){if(lw.clubStrengths[c.id]==null)lw.clubStrengths[c.id]=deriveStrength(c);});
  cleanupLegacy(w);
  w.lightweightWorldVersion=VERSION;
  w.hallOfFame=w.hallOfFame||[];
  return w;
}
function finishInfo(world,clubId){
  var a=world&&world.activeSeason,leagues=a&&a.leagues||{},out={rank:null,teams:null,champion:false};
  Object.keys(leagues).some(function(lid){var ls=leagues[lid],table=ls&&ls.table||[];var idx=table.findIndex(function(r){return r.clubId===clubId;});if(idx>=0){out.rank=idx+1;out.teams=table.length;out.champion=idx===0;return true;}return false;});
  return out;
}
function successModifier(info){
  if(!info.rank||!info.teams)return 0;
  var pct=(info.rank-1)/Math.max(1,info.teams-1);
  if(info.champion)return .65;
  if(pct<=.2)return .35;
  if(pct>=.85)return -.28;
  return 0;
}
function evolveClub(c,current,world){
  var base=baseStrength(c),info=finishInfo(world,c.id),success=successModifier(info);
  var noise=(FC.RNG.random()+FC.RNG.random()-1)*.65;
  var meanRevert=(base-current)*.10;
  var next=clamp(current+meanRevert+success+noise,Math.max(30,base-7),Math.min(95,base+7));
  return Math.round(next*10)/10;
}
function processSeason(w,career,user){
  ensure(w,career);
  var year=Number(career&&career.currentYear||w.year||2026),key=String(year),lw=w.lightweightWorld;
  if(lw.seasonMarkers[key])return {processed:false,year:year,count:0};
  if(window.FC.AwardsEngine)FC.AwardsEngine.processCompletedSeason(w,career,user);
  var before=lw.clubStrengths,next={};
  (FC_DATA.clubs||[]).forEach(function(c){next[c.id]=evolveClub(c,Number(before[c.id]!=null?before[c.id]:deriveStrength(c)),w);});
  lw.clubStrengths=next;lw.seasonMarkers[key]=1;
  lw.evolutionHistory.push({year:year,min:minStrength(next),max:maxStrength(next),avg:avgStrength(next)});
  if(lw.evolutionHistory.length>20)lw.evolutionHistory=lw.evolutionHistory.slice(-20);
  Object.keys(lw.seasonMarkers).forEach(function(y){if(Number(y)<year-2)delete lw.seasonMarkers[y];});
  return {processed:true,year:year,count:0,aggregateClubs:Object.keys(next).length};
}
function vals(m){return Object.keys(m||{}).map(function(k){return Number(m[k]);}).filter(isFinite);}
function minStrength(m){var a=vals(m);return a.length?Math.min.apply(null,a):0;}
function maxStrength(m){var a=vals(m);return a.length?Math.max.apply(null,a):0;}
function avgStrength(m){var a=vals(m);return a.length?Math.round(a.reduce(function(x,y){return x+y;},0)/a.length*100)/100:0;}
function strength(id,w,user){
  ensure(w);
  var c=club(id),s=Number(w.lightweightWorld.clubStrengths[id]);
  if(!isFinite(s))s=deriveStrength(c||{id:id});
  if(user&&user.clubId===id)s=(s*11+Number(user.overall||s))/12;
  return Math.round(s*10)/10;
}
function emptyIndexes(){return {byClub:{},byAcademy:{},byNationality:{},byPosition:{}};}
function validate(w){ensure(w);var e=[],m=w.lightweightWorld.clubStrengths;Object.keys(m).forEach(function(id){var s=Number(m[id]);if(!isFinite(s)||s<25||s>100)e.push("invalidStrength:"+id);});return {ok:!e.length,errors:e};}
window.FC.WorldPlayers={
  ensure:ensure,processSeason:processSeason,getSquadStrength:strength,validate:validate,
  rebuildIndexes:function(){return emptyIndexes();},getIndexes:function(){return emptyIndexes();},
  getClubPlayers:function(){return [];},getTopPlayers:function(){return [];},getTopYoungPlayers:function(){return [];},
  getTopPlayersByPosition:function(){return [];},getTopProspectsInternal:function(){return [];},getTopProspects:function(){return [];},
  getProspectsByCountryInternal:function(){return [];},getProspectsByCountry:function(){return [];},
  getProspectsByClubInternal:function(){return [];},getProspectsByClub:function(){return [];},
  getProspectsByPositionInternal:function(){return [];},getProspectsByPosition:function(){return [];},
  getRosterProfile:function(id,w){return {clubId:id,total:0,min:0,hardMin:0,target:0,max:0,counts:{GK:0,DEF:0,MID:0,ATT:0},minimums:{GK:0,DEF:0,MID:0,ATT:0},targetCounts:{GK:0,DEF:0,MID:0,ATT:0},deficits:{GK:0,DEF:0,MID:0,ATT:0},surpluses:{GK:0,DEF:0,MID:0,ATT:0},capacity:0,overCapacity:0};},
  getPositionGroup:function(pos){return pos==="GK"?"GK":(["RB","CB","LB"].indexOf(pos)>=0?"DEF":(["RW","LW","ST"].indexOf(pos)>=0?"ATT":"MID"));},
  getPositionNeedScore:function(){return 0;},repairWorld:function(){return {added:0,signed:0,released:0};},
  repairClub:function(){return {added:0,signed:0,released:0};},replenishClub:function(){return {processed:false,signed:0,generated:0};},
  findSuitableFreeAgent:function(){return null;},preferredTargetForClub:function(){return null;},
  getStrengthDistribution:function(w){ensure(w);var m=w.lightweightWorld.clubStrengths;return {count:Object.keys(m).length,min:minStrength(m),max:maxStrength(m),avg:avgStrength(m)};}
};
})();