(function () {
  "use strict";

  window.FC_VISUALS = {
    version: 1,
    generatedAssetsReady: true,

    players: {
      player_01: { id:"player_01", src:"assets/players/player_01.webp", enabled:true, objectPosition:"50% 32%" },
      player_02: { id:"player_02", src:"assets/players/player_02.webp", enabled:true, objectPosition:"50% 32%" },
      player_03: { id:"player_03", src:"assets/players/player_03.webp", enabled:true, objectPosition:"50% 32%" },
      player_04: { id:"player_04", src:"assets/players/player_04.webp", enabled:true, objectPosition:"50% 32%" },
      player_05: { id:"player_05", src:"assets/players/player_05.webp", enabled:true, objectPosition:"50% 32%" },
      player_06: { id:"player_06", src:"assets/players/player_06.webp", enabled:false },
      player_07: { id:"player_07", src:"assets/players/player_07.webp", enabled:false },
      player_08: { id:"player_08", src:"assets/players/player_08.webp", enabled:false },
      player_09: { id:"player_09", src:"assets/players/player_09.webp", enabled:false },
      player_10: { id:"player_10", src:"assets/players/player_10.webp", enabled:false },
      player_11: { id:"player_11", src:"assets/players/player_11.webp", enabled:false },
      player_12: { id:"player_12", src:"assets/players/player_12.webp", enabled:false }
    },

    competitionThemes: {
      DEFAULT_LEAGUE: {
        id:"DEFAULT_LEAGUE",
        enabled:false,
        hero:"assets/competition/default_league_hero.webp",
        overlay:"assets/competition/default_league_overlay.webp",
        accentKey:"league"
      },
      DOMESTIC_CUP: {
        id:"DOMESTIC_CUP",
        enabled:false,
        hero:"assets/competition/domestic_cup_hero.webp",
        overlay:"assets/competition/domestic_cup_overlay.webp",
        accentKey:"domestic_cup"
      },
      UCL: {
        id:"UCL",
        enabled:false,
        hero:"assets/competition/ucl_hero.webp",
        overlay:"assets/competition/ucl_overlay.webp",
        accentKey:"continental_elite"
      },
      UEL: {
        id:"UEL",
        enabled:false,
        hero:"assets/competition/uel_hero.webp",
        overlay:"assets/competition/uel_overlay.webp",
        accentKey:"continental_secondary"
      },
      UECL: {
        id:"UECL",
        enabled:false,
        hero:"assets/competition/uecl_hero.webp",
        overlay:"assets/competition/uecl_overlay.webp",
        accentKey:"continental_tertiary"
      },
      NATIONAL_TEAM: {
        id:"NATIONAL_TEAM",
        enabled:false,
        hero:"assets/competition/national_team_hero.webp",
        overlay:"assets/competition/national_team_overlay.webp",
        accentKey:"national"
      },
      MAJOR_INTERNATIONAL: {
        id:"MAJOR_INTERNATIONAL",
        enabled:false,
        hero:"assets/competition/major_international_hero.webp",
        overlay:"assets/competition/major_international_overlay.webp",
        accentKey:"international_major"
      },
      FINAL_TROPHY_MATCH: {
        id:"FINAL_TROPHY_MATCH",
        enabled:false,
        hero:"assets/competition/final_trophy_match_hero.webp",
        overlay:"assets/competition/final_trophy_match_overlay.webp",
        accentKey:"final"
      }
    },

    presentation: {
      TRANSFER_OFFER: { id:"TRANSFER_OFFER", src:"assets/presentation/transfer_offer.webp", enabled:false },
      NEGOTIATION: { id:"NEGOTIATION", src:"assets/presentation/negotiation.webp", enabled:false },
      CONTRACT_SUCCESS: { id:"CONTRACT_SUCCESS", src:"assets/presentation/contract_success.webp", enabled:false },
      NEGOTIATION_FAILED: { id:"NEGOTIATION_FAILED", src:"assets/presentation/negotiation_failed.webp", enabled:false },
      CONTRACT_SIGNATURE: { id:"CONTRACT_SIGNATURE", src:"assets/presentation/contract_signature.webp", enabled:false },
      CONTRACT_TORN: { id:"CONTRACT_TORN", src:"assets/presentation/contract_torn.webp", enabled:false }
    },

    trophyMapping: {
      LEAGUE_TITLE: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      DOMESTIC_CUP: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      CONTINENTAL_CUP: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      INTERNATIONAL_TROPHY: { resolver:"FC.TrophyAssets.getCompetitionAsset", fallbackType:"competition" },
      PLAYER_AWARD: { resolver:"FC.TrophyAssets.getAwardAsset", fallbackType:"award" }
    },

    fallback: {
      player: { kind:"INITIALS", src:null },
      competitionTheme: { kind:"CSS_THEME", src:null, overlay:null, accentKey:"default" },
      presentation: { kind:"CSS_PANEL", src:null },
      trophy: { kind:"TROPHY_ASSETS", src:null }
    }
  };
})();
