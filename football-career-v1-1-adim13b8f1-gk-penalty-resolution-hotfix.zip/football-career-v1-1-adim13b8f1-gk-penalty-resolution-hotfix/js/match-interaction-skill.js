(function(){"use strict";
 var APPEARANCE=[1,1.08,1.17,1.28,1.40,1.52];
 var EXECUTION=[0,1.2,2.5,4.0,5.7,7.5];
 var SPECIAL_MAP={FINESSE:"FINESSE_SHOT",CHIP:"CHIP_SHOT",VOLLEY:"VOLLEY",BICYCLE:"BICYCLE_KICK",TRIVELA:"TRIVELA",RABONA:"RABONA",OUTSIDE_FOOT_PASS:"OUTSIDE_FOOT_PASS",BACKHEEL:"BACKHEEL_PASS"};
 var PAIR_MAP={
  "ONE_ON_ONE:place":"FINESSE_SHOT",
  "ONE_ON_ONE:power":"POWER_SHOT",
  "EDGE_OF_BOX_SHOT:placed":"FINESSE_SHOT",
  "EDGE_OF_BOX_SHOT:power":"POWER_SHOT",
  "KEEPER_OFF_LINE:power":"POWER_SHOT",
  "THROUGH_BALL:risky":"THROUGH_BALL",
  "EDGE_OF_BOX_SHOT:slip":"THROUGH_BALL",
  "UNDERLAP_DECISION:thread":"THROUGH_BALL",
  "COUNTER_ATTACK_DECISION:pass":"THROUGH_BALL",
  "FINAL_THIRD_PASS:killer":"THROUGH_BALL",
  "CHAIN_CUT_INSIDE:slip":"THROUGH_BALL",
  "CHAIN_COUNTER_CONTINUE:early":"THROUGH_BALL",
  "CHAIN_PRESS_BROKEN:through":"THROUGH_BALL",
  "CHAIN_DEF_TRANSITION:vertical":"THROUGH_BALL"
 };
 function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
 function level(player,skillId){return window.FC&&FC.SkillMastery&&skillId?FC.SkillMastery.getLevel(skillId,player):0;}
 function skillId(eventType,choice){if(!choice)return null;if(choice.masterySkillId)return choice.masterySkillId;if(choice.special&&SPECIAL_MAP[choice.special])return SPECIAL_MAP[choice.special];return PAIR_MAP[String(eventType||"")+":"+String(choice.id||"")]||null;}
 function appearanceMultiplier(player,skill){var l=level(player,skill);return APPEARANCE[l]||1;}
 function appearanceChance(player,skill,base){base=Number(base);if(!isFinite(base))return 1;if(base>=1)return 1;return clamp(base*appearanceMultiplier(player,skill),0,Math.min(.92,base+Math.max(.08,base*.75)));}
 function executionScoreBonus(player,skill){var l=level(player,skill);return EXECUTION[l]||0;}
 function stars(l){l=clamp(Math.floor(Number(l)||0),0,5);return "★★★★★".slice(0,l)+"☆☆☆☆☆".slice(0,5-l);}
 function metadata(player,eventType,choice){var sid=skillId(eventType,choice);if(!sid)return null;var l=level(player,sid);return {skillId:sid,level:l,stars:stars(l),signature:l===5,appearanceMultiplier:appearanceMultiplier(player,sid),executionScoreBonus:executionScoreBonus(player,sid)};}
 function audit(){return {appearanceCurve:APPEARANCE.slice(),executionScoreCurve:EXECUTION.slice(),specialMap:Object.assign({},SPECIAL_MAP),pairMap:Object.assign({},PAIR_MAP)};}
 window.FC.MatchInteractionSkill={getSkillId:skillId,getLevel:level,getAppearanceMultiplier:appearanceMultiplier,getAppearanceChance:appearanceChance,getExecutionScoreBonus:executionScoreBonus,getMetadata:metadata,getStars:stars,debugAudit:audit};
})();
