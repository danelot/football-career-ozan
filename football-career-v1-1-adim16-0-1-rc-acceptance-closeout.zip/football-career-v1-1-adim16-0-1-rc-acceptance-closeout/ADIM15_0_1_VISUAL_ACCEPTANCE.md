# ADIM 15.0.1 — VISUAL ACCEPTANCE MANIFEST

This file is a reviewer checklist, not proof of real-browser acceptance.

## HOME
- `fc-home-hero` is the dominant surface, visibly larger/darker than secondary cards.
- OVR is a large isolated numeric block; identity/club/role are compact.
- Calendar/next-action controls read as a timeline/action surface, not a paragraph panel.
- Secondary season/form data is visually subordinate.

## MATCH CENTER / LIVE MATCH
- `fc-match-scoreboard` visibly anchors the top with both clubs/crests, score and clock.
- `fc-player-hud` is a compact persistent strip for player identity, rating, fitness, G/A.
- `fc-match-interaction` owns visual focus during choices.
- `fc-match-result` is a centered result state with a graphic result mark, dominant outcome title, compact rating delta and one primary DEVAM ET action.
- Timeline uses compact minute + event rows.
- NOT_IN_SQUAD watch must never show `OYUNA GİRİYORSUN`; BENCH may show it only at canonical entry minute.

## TRANSFER
- `fc-transfer-action-zone` dominates when an actionable transfer decision exists.
- Formal offers/negotiations are visually stronger than scouting.
- `fc-transfer-passive-list` renders passive interest as compact rows; descriptions are not the primary presentation.
- Market value, contract role, manager role and playing-time state remain distinct canonical values.

## CALENDAR
- `fc-calendar-timeline` visually marks the career calendar/action rail.
- Current day / next known important boundary is scannable before secondary explanatory text.
- Primary advance action is obvious; +1/+3/+7 remain secondary.
- No unrealized random future injury/career/relationship event is shown.

## PLAYER
- `fc-player-hero` reads as a football player profile: portrait, identity, club and large OVR.
- BECERİLER remains directly visible in the primary player tab row.
- Detailed development/fitness/training information is secondary to the hero and tabs.

## VIEWPORTS TO CHECK
- 1920×1080: balanced content width; no stretched paragraph walls.
- 1366×768: scoreboard/hero and primary CTA visible without horizontal breakage.
- 1280×720: primary controls remain reachable.
- Narrow/mobile-like: heroes stack, player HUD compresses, no page-wide horizontal overflow.
