# ADIM15.0.2 REAL BROWSER REGRESSION

This checklist is for independent `file://` acceptance. Automated/static tests are not a substitute for these checks.

## CASE 1 — NOT_IN_SQUAD → MAÇI İZLE
START STATE: Canonical pre-match selection says `KADRODA YOKSUN`.
ACTION: Open the match and press `MAÇI İZLE`; let it run to full time.
EXPECTED RESULT: Status never becomes bench/substitute; no `OYUNA GİRİYORSUN`, player interaction, minutes, appearance, match GP or physical match load. Club score/clock/timeline may continue normally.
FAIL SIGN: Any substitution prompt or player participation.

## CASE 2 — MULTIPLE INTERACTIONS THROUGH 90'
START STATE: Starter or real substitute with an interactive match containing several player events.
ACTION: Resolve successes/failures/chains/special actions, including an event after 80', pressing `DEVAM ET` after each outcome.
EXPECTED RESULT: Every resolved outcome returns to playback; clock advances; final whistle is reached; final score/G/A/rating commit once.
FAIL SIGN: `ETKİLEŞİM OTURUMU TAMAMLANAMADI`, frozen result surface, orphan interaction, duplicate result.

## CASE 3 — HOME CALENDAR + SUMMER ROUTE
START STATE: HOME.
ACTION: Use `+1 GÜN`, `+3 GÜN`, `+7 GÜN`, `SONRAKİ ÖNEMLİ`; resolve any career-choice interruption. At completed-season summer, use `YENİ SEZONA İLERLE` and resolve interruptions.
EXPECTED RESULT: Normal progression returns to HOME. A canonical match/transfer decision may temporarily route to its own surface. New season starts on HOME for a contracted player.
FAIL SIGN: OYUNCU page opens without the user choosing it.

## CASE 4 — HOME HERO GEOMETRY
START STATE: Contracted player with portrait/crest, then repeat with a long player name and long club name.
ACTION: Open HOME at 1920×1080 and 1366×768.
EXPECTED RESULT: portrait, identity, club mark, OVR and vitals occupy distinct regions; text wraps/truncates safely; no overlap.
FAIL SIGN: OVR/crest/name layers cover one another.

## CASE 5 — PLAYER GP 10×
START STATE: PLAYER → GELİŞİM with enough GP for repeated investment.
ACTION: Press the same `1 GP YATIR` control 10 consecutive times.
EXPECTED RESULT: same development subsection remains active; button stays approximately at the same viewport position; `OLUMLU ETKENLER` and `SINIRLAYICI ETKENLER` each have one summary owner and do not accumulate.
FAIL SIGN: cumulative downward scroll, duplicated factor text, multiplied click behavior.
