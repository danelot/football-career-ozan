# ADIM16.0.1 — Kısa Gerçek `file://` Kullanıcı Testi

Bu paket henüz **1.1.0-rc.1 olarak onaylanmadı**. Otomatik production Matchday QA iki gerçek hata bulup düzeltti; aşağıdaki 10–15 dakikalık kontrol gerçek tarayıcı tarafındaki son kritik sinyalleri verir.

1. **HOME:** `index.html` dosyasını çift tıkla. Portrait, oyuncu bilgisi, kulüp, OVR ve FORM/MORAL/KONDİSYON birbirine girmemeli. Pencereyi biraz daralt; yatay taşma/çakışma olmamalı.
2. **Takvim:** HOME'dan `+1`, `+3`, `+7` ve `SONRAKİ ÖNEMLİ` kullan. Gerçek bir karar/maç/transfer kesintisi yoksa rastgele OYUNCU sayfasına düşmemeli.
3. **Yeni sezon:** Uygun kayıtta `YENİ SEZONA İLERLE`. Yaz akışı tamamlanmalı; açıklamasız OYUNCU rotası veya kilitlenme olmamalı.
4. **Kadroda yoksun:** `KADRODA YOKSUN` olduğun maçta `MAÇI İZLE`. Sonradan yedek olarak oyuna girmemeli ve oyuncu etkileşimi almamalısın.
5. **Gerçek yedek:** Gerçekten yedek olduğun bir maçta çağrılırsan gösterilen dakikada oyuna girmeli ve bundan sonra etkileşim başlayabilmeli.
6. **İnteraktif maç:** Bir maçı birkaç pozisyonla 90 dakikaya kadar tamamla. Her `DEVAM ET` maçı sürdürmeli. `Etkileşim oturumu tamamlanamadı` veya donmuş sonuç ekranı olmamalı.
7. **Gol/asist:** Olursa canlı skor, maç sonu skor ve oyuncu G/A değerlerini karşılaştır; aynı olmalı.
8. **GP:** OYUNCU > GELİŞİM'de yaklaşık 10 kez GP yatır. Buton sürekli aşağı kaçmamalı; `OLUMLU ETKENLER / SINIRLAYICI ETKENLER` çoğalmamalı.
9. **Transfer:** Yoğun bir Transfer Center aç. Resmî teklifler/kararlar baskın, pasif ilgi kompakt olmalı. Teklif aç/kapat veya karşı teklif yap; mümkünse çıkıp geri gel ve durumun korunduğunu kontrol et.
10. **Kaydet/yükle:** Normal kariyer durumunda kaydet ve tekrar yükle. Kulüp, sözleşme, sakatlık/fitness, GP, teklifler ve bekleyen kararlar değişmemeli.

## Sonuç

Bana yalnızca şunlardan birini gönder:

**PASS**

veya

**FAIL + ekran görüntüsü + hatadan hemen önce neye tıkladığın**
