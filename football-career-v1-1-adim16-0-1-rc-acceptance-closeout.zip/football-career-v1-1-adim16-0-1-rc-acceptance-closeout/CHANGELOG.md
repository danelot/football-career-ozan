
## 1.1.0-dev.15b.5 — Long-Career Performance Profiling + 2032+ Optimization
- Added deterministic long-career profiler instrumentation and state-section diagnostics.
- Replaced State's JSON stringify/parse clone hot path with an equivalent data clone for serializable state values; no extra RNG consumption.
- Added compact completed-season player match archive and save-time historical compaction while preserving visible career totals/history.
- Added bounded/lazy Career timeline rendering in batches of 10 seasons.
- Extended performance instrumentation for State, SaveManager, TransferMarket, NotificationCenter, Calendar, Team and season summary paths.
- SAVE_VERSION remains 27; dataVersion remains unchanged.

## 1.1.0-dev.16.10 — ADIM 10 Injury + Fitness + Recovery 3.0
- Formalized PhysicalEngine as canonical fitness/fatigue/readiness/workload owner and InjuryEngine as canonical injury-risk/occurrence owner.
- Added bounded readiness/load/risk read APIs with zero-RNG read behavior.
- Added persistent recent workload and exactly-once fixture load guard.
- Recovery completion no longer consumes gameplay RNG; post-injury readiness is severity-bounded and deterministic.
- Injury occurrence/return notifications are deduplicated by stable injury identity.
- Expanded Player > FİZİK / DURUM with match condition, physical load, readiness, current risk band and estimated return.
- Added reproducible ADIM10 physical/balance headless harness; SAVE_VERSION remains 27.
