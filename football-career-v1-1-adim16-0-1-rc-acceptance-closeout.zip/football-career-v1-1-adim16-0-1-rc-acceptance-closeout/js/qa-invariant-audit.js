(function(){"use strict";
function push(a,code,detail){a.push({code:code,detail:detail||null});}
function dup(rows,keyFn,out,code){var seen={};(rows||[]).forEach(function(x){var k=keyFn(x);if(!k)return;if(seen[k])push(out,code,k);seen[k]=1;});}
function run(state){state=state||FC.State.peek();var critical=[],warnings=[],info=[],p=state&&state.player||{},c=state&&state.career||{},m=c.transferMarket||{},loan=p.loan,ph=p.physical||{},dev=p.development||{},sm=p.skillMastery||{};
 if(loan&&loan.status==="active"&&!loan.parentClubId)push(critical,"ACTIVE_LOAN_MISSING_PARENT");
 var loans=[];if(Array.isArray(p.loanHistory))loans=loans.concat(p.loanHistory.filter(function(x){return x&&x.status==="active";}));if(loan&&loan.status==="active")loans.push(loan);if(loans.length>1)push(critical,"MULTIPLE_ACTIVE_LOANS",loans.length);
 if(loan&&loan.status==="active"&&(m.offers||[]).some(function(o){return o&&o.type==="loan"&&o.status==="pending";}))push(critical,"ACTIVE_LOAN_ACTIONABLE_LOAN_OFFER");
 if(!p.clubId&&p.contract&&p.contract.status==="active"&&p.contract.clubId)push(critical,"FA_ACTIVE_CLUB_CONTRACT",p.contract.clubId);
 (m.offers||[]).forEach(function(o){if(o&&o.status==="completed"&&(o.actionable||o.decisionRequired))push(critical,"COMPLETED_TRANSFER_ACTIONABLE",o.id);});
 if(p.contract&&p.contract.status==="active"&&Number(p.contract.yearsRemaining)<0)push(critical,"EXPIRED_CONTRACT_ACTIVE",p.contract.id);
 var logs=state&&state.world&&state.world.activeSeason&&state.world.activeSeason.player&&state.world.activeSeason.player.matchLogs||[];dup(logs,function(x){return x&&x.fixtureId;},critical,"FIXTURE_COMPLETED_TWICE");
 logs.forEach(function(x){if(!x)return;var st=String(x.squadStatus||"");if(st==="not_in_squad"&&Number(x.minutes||0)>0)push(critical,"NOT_IN_SQUAD_POSITIVE_MINUTES",x.fixtureId);if(st==="not_in_squad"&&(x.appearance===true||Number(x.appearances||0)>0))push(critical,"NOT_IN_SQUAD_APPEARANCE",x.fixtureId);if(x.unavailable&&Number(x.minutes||0)>0)push(critical,"UNAVAILABLE_PARTICIPATION",x.fixtureId);});
 if(Number(dev.gp||0)<0)push(critical,"NEGATIVE_GP",dev.gp);if(Number(sm.availableStars||0)<0)push(critical,"NEGATIVE_AVAILABLE_STARS",sm.availableStars);
 var levels=sm.levels||sm.skills||{};Object.keys(levels).forEach(function(k){var v=Number(typeof levels[k]==="object"?levels[k].level:levels[k]);if(v<0||v>5)push(critical,"SKILL_LEVEL_RANGE",k+":"+v);});
 dup((m.offers||[]).filter(function(o){return o&&["pending","seller_accepted"].indexOf(o.status)>=0;}),function(o){return o.id;},critical,"DUPLICATE_ACTIVE_OFFER_ID");
 dup((m.negotiations||[]).filter(function(n){return n&&["OPEN","COUNTERED","AWAITING_CLUB","TERMS_AGREED"].indexOf(n.status)>=0;}),function(n){return n.id;},critical,"DUPLICATE_ACTIVE_NEGOTIATION_ID");
 var ci=p.careerIdentity||{}, evs=[].concat(ci.eventHistory||[],ci.events||[]);if(ci.pendingEvent)evs.push(ci.pendingEvent);dup(evs,function(e){return e&&e.id;},critical,"DUPLICATE_EVENT_ID");if(ci.pendingEvent&&ci.pendingEvent.status==="resolved")push(critical,"RESOLVED_EVENT_ACTIONABLE",ci.pendingEvent.id);
 if(ph.injury&&ph.injury.hiddenFuture===true&&ph.injury.public===true)push(critical,"FUTURE_HIDDEN_INJURY_PUBLIC");
 var cs=c.currentSeasonState||{};if(cs.season&&c.currentSeason&&cs.season!==c.currentSeason&&cs.status!=="completed")push(critical,"INVALID_ROLLOVER_MARKER",cs.season+"/"+c.currentSeason);
 return {critical:critical,warnings:warnings,info:info};}
window.FC.QAInvariantAudit={run:run};
})();
