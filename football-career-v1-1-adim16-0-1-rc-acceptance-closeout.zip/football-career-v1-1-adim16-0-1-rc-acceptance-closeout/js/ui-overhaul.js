(function(){"use strict";
var FC=window.FC=window.FC||{};
/* MutationObserver legacy note: ADIM15.0.1 no longer uses it as a primary renderer. */
function text(el){return String(el&&el.textContent||"").trim();}
function pageKind(root){var m=root&&root.querySelector("main");if(!m)return "unknown";var c=m.className||"";if(/home-command/.test(c))return "home";if(/transfer/.test(c))return "transfer";if(/team-hub/.test(c))return "team";if(/match-center/.test(c))return "matches";if(/player/.test(c))return "player";if(/career/.test(c))return "career";if(/league|world|international/.test(c))return "world";if(/finance|lifestyle/.test(c))return "lifestyle";if(/calendar/.test(c))return "calendar";if(/matchday/.test(c))return "matchday";return "other";}
function enhance(root){if(!root)return;var main=root.querySelector("main");if(!main)return;var kind=pageKind(root);main.dataset.uiV3=kind;main.classList.add("fc15-screen");
 root.querySelectorAll(".ui-page-title").forEach(function(h){h.classList.add("fc15-page-header");});
 root.querySelectorAll(".panel").forEach(function(p){p.classList.add("fc15-panel");});
 root.querySelectorAll(".btn-primary").forEach(function(b){b.classList.add("fc15-primary-action");});
 root.querySelectorAll(".badge,.pill,.status-chip").forEach(function(b){b.classList.add("fc15-chip");});
 root.querySelectorAll("p").forEach(function(p){if(text(p).length>150)p.classList.add("fc15-long-copy");});
 if(kind==="transfer"){root.querySelectorAll(".transfer-interest-card").forEach(function(c){c.classList.add("fc15-passive-card");});root.querySelectorAll(".transfer-offer-clean,.negotiation-card,.ready-deal-card").forEach(function(c){c.classList.add("fc15-decision-card");});}
 if(kind==="matchday")main.classList.add("fc15-focus-mode");
}
function observe(){var app=document.getElementById("app");if(app)enhance(app);}
FC.UIOverhaul={enhance:enhance,pageKind:pageKind,version:"3.0"};
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",observe);else observe();
})();
