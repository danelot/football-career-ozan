const T=require('./adim13-test-common');console.log(JSON.stringify({PASS:true,persistence:T.persistence(),reads:T.readPurity()},null,2));
