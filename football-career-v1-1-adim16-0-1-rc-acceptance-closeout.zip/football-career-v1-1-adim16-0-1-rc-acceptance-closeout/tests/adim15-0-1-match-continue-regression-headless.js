const fs=require('fs');const s=fs.readFileSync('js/matchday-ui.js','utf8');
['function resumeMatchPlayback(sessionId)','function continueResolvedInteraction(sessionId,token)','d.pendingOutcome=null','resumeMatchPlayback(sessionId)','d.continuing=true','btn.disabled=true'].forEach(x=>{if(!s.includes(x))throw Error('missing '+x)});
if((s.match(/function resumeMatchPlayback\(/g)||[]).length!==1)throw Error('resume owner count');
for(let i=0;i<1000;i++){let driver={token:i,continuing:false,pendingOutcome:{token:i}},commits=0,resumes=0;function click(){if(driver.continuing)return;driver.continuing=true;commits++;driver.pendingOutcome=null;resumes++;}click();click();if(commits!==1||resumes!==1||driver.pendingOutcome)throw Error('continue atomicity '+i);}
console.log('ADIM15.0.1 MATCH CONTINUE PASS | failed-shot/goal/assist/chain/special use canonical continue owner | 1000X stalls=0 duplicate=0');
