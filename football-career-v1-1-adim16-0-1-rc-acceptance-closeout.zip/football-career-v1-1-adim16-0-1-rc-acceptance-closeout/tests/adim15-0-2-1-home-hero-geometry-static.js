const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'css/ui-overhaul.css'),'utf8');
const base=fs.readFileSync(path.join(root,'css/style.css'),'utf8');
const dash=fs.readFileSync(path.join(root,'js/dashboard.js'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
// Production markup ownership: one emitted region of each kind in the HOME hero template.
for(const c of ['fc-home-hero','home-appearance','home-identity','home-club-mark','home-ovr','home-vitals']){
  const n=(dash.match(new RegExp(c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'g'))||[]).length;
  ok(n===1,`${c} production occurrence expected 1, got ${n}`);
}
// Final geometry owner must reserve the actual portrait widths (150 desktop, 118 <=1450).
ok(/grid-template-columns:150px minmax\(0,1fr\) minmax\(110px,150px\) minmax\(120px,150px\)/.test(css),'desktop portrait column not reserved');
ok(/max-width:1450px\) and \(min-width:1051px\).*grid-template-columns:118px minmax\(0,1fr\)/s.test(css),'1450 portrait column not reserved');
ok(/max-width:1050px\) and \(min-width:901px\).*grid-template-columns:118px minmax\(0,1fr\)/s.test(css),'narrow desktop portrait column not reserved');
ok(/grid-template-areas:"avatar identity club ovr" "avatar vitals vitals ovr"/.test(css),'desktop areas missing');
ok(/grid-template-areas:"avatar identity ovr" "avatar vitals ovr"/.test(css),'narrow desktop areas missing');
ok(/max-width:900px.*grid-template-areas:"identity ovr" "vitals vitals"/s.test(css),'stack-before-collision breakpoint missing');
ok(/max-width:620px.*grid-template-areas:"identity" "ovr" "vitals"/s.test(css),'mobile vertical composition missing');
// Independent regions are normal-flow grid items; explicitly neutralize legacy offset techniques.
for(const c of ['home-appearance','home-identity','home-club-mark','home-vitals']){
  ok(new RegExp(`\\.fc-home-hero \\.${c}\\{[^}]*margin:0;transform:none;position:relative`).test(css),`${c} offset neutralization missing`);
}
ok(!/\.fc-home-hero[^}]*position\s*:\s*absolute/.test(css),'hero absolute positioning found');
ok(!/\.fc-home-hero[^}]*margin-(left|right)\s*:\s*-/.test(css),'negative hero margin found');
ok(!/\.fc-home-hero[^}]*translate[XY]?\s*\(/.test(css),'hero translate found');
// Legacy portrait is 150/118: assert geometry owner matches rather than allowing overflow from a 92px track.
ok(/home-appearance\.fc-player-portrait\{width:150px/.test(base),'desktop portrait source width changed unexpectedly');
ok(/max-width:1450px[\s\S]*home-appearance\.fc-player-portrait\{width:118px/.test(base),'1450 portrait source width changed unexpectedly');
console.log('ADIM15.0.2.1 HOME HERO GEOMETRY STATIC: PASS');
console.log(JSON.stringify({staticStructure:'PASS',realBrowserGeometry:'PENDING USER REVIEW',regions:{hero:1,portrait:1,identity:1,club:1,ovr:1,vitals:1}},null,2));
