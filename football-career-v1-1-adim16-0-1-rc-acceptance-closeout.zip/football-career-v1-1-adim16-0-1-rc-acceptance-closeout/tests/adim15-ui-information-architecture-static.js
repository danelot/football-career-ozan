const fs=require('fs'),path=require('path'),R=path.resolve(__dirname,'..');
function read(p){return fs.readFileSync(path.join(R,p),'utf8')}
const css=read('css/ui-overhaul.css'),idx=read('index.html'),dash=read('js/dashboard.js'),transfer=read('js/transfer-center.js');
const checks={overlayLoaded:idx.includes('./css/ui-overhaul.css')&&idx.includes('./js/ui-overhaul.js'),homeNextAction:/SONRAKİ MAÇ|SONRAKİ ÖNEMLİ/.test(dash),transferHierarchy:/AKTİF|RESMİ|GÖRÜŞME|KULÜP İLGİSİ/.test(transfer),designTokens:css.includes('--fc15-gap')&&css.includes('--fc15-r'),responsive:css.includes('@media(max-width:1366px)')&&css.includes('@media(max-width:620px)'),reducedMotion:css.includes('prefers-reduced-motion')};
console.log(JSON.stringify(checks,null,2));if(Object.values(checks).some(x=>!x))process.exit(1);console.log('ADIM15 UI INFORMATION ARCHITECTURE STATIC = PASS');
