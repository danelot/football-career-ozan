(function(){
  "use strict";
  var RENEWAL_CONFIG={
    oneYear:{base:31,min:8,max:91},
    twoYears:{base:2,min:0,max:30},
    threePlusChance:0
  };
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function roleOrder(){return ["Academy","Prospect","Rotation","First Team"];}
  function seasonStartYear(season){var m=/^(\d{4})-(\d{2})$/.exec(String(season||""));return m?Number(m[1]):null;}
  function seasonDistance(fromSeason,toSeason){
    var a=seasonStartYear(fromSeason),b=seasonStartYear(toSeason);
    if(a==null||b==null)return null;
    return b-a;
  }
  function canonicalRemaining(contract,careerOrSeason){
    if(!contract)return 0;
    var season=typeof careerOrSeason==="string"?careerOrSeason:careerOrSeason&&careerOrSeason.currentSeason;
    if(contract.endSeason&&season){
      var d=seasonDistance(season,contract.endSeason);
      if(d!=null)return Math.max(0,d);
    }
    if(contract.endYear!=null&&careerOrSeason&&typeof careerOrSeason!=="string"&&careerOrSeason.currentYear!=null){
      return Math.max(0,Number(contract.endYear)-Number(careerOrSeason.currentYear));
    }
    if(contract.yearsRemaining!=null)return Math.max(0,Number(contract.yearsRemaining));
    return Math.max(0,Number(contract.yearsTotal||contract.years||3));
  }
  function statusForRemaining(remaining){return remaining<=0?"expired":remaining===1?"expiring":"active";}
  function startSeasonForDay(career,d){
    var season=career&&career.currentSeason||FC_DATA.datapack.season,day=Number(d||0);
    /* Day >=330 is the end-of-season summer window. A contract signed there
       belongs to the upcoming football season and must not lose a year at the
       immediately following rollover. */
    return day>=330?FC.Utils.nextSeason(season):season;
  }
  function normalize(contract,career){
    if(!contract){return null;}
    var c=FC.Utils.clone(contract),years=Number(c.yearsTotal||c.years||3),start=c.startSeason||(career&&career.startSeason)||FC_DATA.datapack.season;
    c.yearsTotal=years;
    c.years=years;
    c.startSeason=start;
    c.endSeason=c.endSeason||FC.Utils.addSeasons(start,years);
    c.endYear=c.endYear!=null?Number(c.endYear):Number(start.slice(0,4))+years;
    c.yearsRemaining=canonicalRemaining(c,career);
    c.status=statusForRemaining(c.yearsRemaining);
    c.contractId=c.contractId||c.id||("legacy_contract_"+String(c.clubId||"club")+"_"+String(c.startSeason||"season"));
    if(c.signingBonusSettled==null)c.signingBonusSettled=true;
    c.bonuses=c.bonuses||{
      appearanceBonus:Math.round(Number(c.weeklyWage||0)*.035),
      goalBonus:Math.round(Number(c.weeklyWage||0)*.045),
      assistBonus:Math.round(Number(c.weeklyWage||0)*.03),
      cleanSheetBonus:Math.round(Number(c.weeklyWage||0)*.035)
    };
    c.signedAt=c.signedAt||null;
    c.lastSeasonDecremented=c.lastSeasonDecremented||null;
    return c;
  }
  function build(clubId,offer,career,startSeason){
    var years=Number(offer.contractYears||offer.years||3),start=startSeason||career.currentSeason;
    var wage=Number(offer.weeklyWage||offer.wage||0),rates=FC_DATA.economyConfig&&FC_DATA.economyConfig.matchBonusRates||{appearance:.035,goal:.045,assist:.03,gkCleanSheet:.035};
    return {
      contractId:"contract_"+String(offer.id||FC.Utils.uid("offer"))+"_"+String(start),
      clubId:clubId,
      startYear:Number(start.slice(0,4)),
      startSeason:start,
      endSeason:FC.Utils.addSeasons(start,years),
      yearsTotal:years,
      years:years,
      yearsRemaining:years,
      endYear:Number(start.slice(0,4))+years,
      weeklyWage:wage,
      signingBonus:Number(offer.signingBonus||0),
      signingBonusSettled:false,
      bonuses:{
        appearanceBonus:Math.round(wage*rates.appearance),
        goalBonus:Math.round(wage*rates.goal),
        assistBonus:Math.round(wage*rates.assist),
        cleanSheetBonus:Math.round(wage*rates.gkCleanSheet)
      },
      squadRole:offer.squadRole||"Prospect",
      developmentChance:offer.developmentChance==null?null:offer.developmentChance,
      playingTimeChance:offer.playingTimeChance==null?null:offer.playingTimeChance,
      status:"active",
      signedAt:new Date().toISOString(),
      lastSeasonDecremented:null
    };
  }
  function decrementForCompletedSeason(player,career,completedSeason,nextSeason){
    var c=player.contract;
    if(!c){return {changed:false,expired:true};}
    /* Check the exactly-once marker before any season-relative normalization.
       A repeated rollover call must be a literal no-op, not rewrite the already
       derived next-season yearsRemaining using the old season context. */
    if(c.lastSeasonDecremented===completedSeason){return {changed:false,expired:c.status==="expired"};}
    c=normalize(c,career);
    /* Canonical chronology derives remaining seasons from endSeason. We retain
       the legacy function name because SeasonEngine owns the rollover call, but
       there is no blind decrement anymore. */
    c.yearsRemaining=canonicalRemaining(c,nextSeason);
    c.lastSeasonDecremented=completedSeason;
    c.status=statusForRemaining(c.yearsRemaining);
    player.contract=c;
    return {changed:true,expired:c.status==="expired"};
  }
  function isExpiredAt(contract,career,d){
    if(!contract||!career)return false;
    var c=normalize(contract,career),day=Number(d||0),season=career.currentSeason;
    if(c.endSeason){
      var dist=seasonDistance(season,c.endSeason);
      if(dist!=null){
        if(dist<0||dist===0)return true;
        if(dist===1&&day>=399)return true;
        return false;
      }
    }
    return Number(c.yearsRemaining||0)<=0||c.status==="expired";
  }
  function renewalChance(player,club,season){
    if(!player.contract||!club){return 0;}
    var remaining=Math.max(0,Number(player.contract.yearsRemaining||0));
    if(remaining<=0||remaining>=3){return RENEWAL_CONFIG.threePlusChance;}
    var s=season&&season.league||{},rating=Number(s.averageRating||6.4),apps=Number(s.appearances||0),opp=Math.max(1,Number(s.matchOpportunities||34)),share=clamp(apps/opp,0,1),gap=Number(player.overall)-Number(club.squadStrength),potGap=Math.max(0,Number(player.potential)-Number(player.overall)),growth=Number(season&&season.development&&season.development.overallChange||0),age=Number(player.age||22);
    var performance=(rating-6.45)*25+share*18+clamp(gap,-10,10)*0.75+growth*3,rel=window.FC.RelationshipEngine&&player.clubId?FC.RelationshipEngine.getClub(player,player.clubId):null;
    if(rel){performance+=(Number(rel.managerTrust||50)-50)*.18+(Number(rel.fans||50)-50)*.06+(Number(rel.teammates||50)-50)*.05;var ro=rel.managerRole||player.contract.squadRole;if(ro==="First Team")performance+=5;else if(ro==="Rotation")performance+=2;}
    if(player.physical&&player.physical.injuryStatus&&player.physical.injuryStatus!=="healthy")performance-=3;
    if(remaining===1){var one=RENEWAL_CONFIG.oneYear.base+performance+(age<=21?5:0)+Math.min(9,potGap*0.32);return Math.round(clamp(one,RENEWAL_CONFIG.oneYear.min,RENEWAL_CONFIG.oneYear.max));}
    var exceptional=(age<=21?5:0)+Math.min(8,potGap*0.30)+Math.max(0,(rating-7.0)*14)+Math.max(0,growth-1)*3+Math.max(0,share-0.65)*14+Math.max(0,gap)*0.55;
    var two=RENEWAL_CONFIG.twoYears.base+exceptional;
    return Math.round(clamp(two,RENEWAL_CONFIG.twoYears.min,RENEWAL_CONFIG.twoYears.max));
  }
  function buildRenewalOffer(player,club,career,season){if(!player||!player.contract||!club)return null;var chance=renewalChance(player,club,season),current=Number(player.contract.weeklyWage||500),neg=window.FC.PlayerModifiers?FC.PlayerModifiers.get(player).negotiation:1,wage=Math.max(current,Math.round((current*(1.08+Math.max(0,player.overall-club.squadStrength)*0.025+FC.RNG.random()*0.22)*neg)/100)*100),years=FC.RNG.weighted([{value:2,weight:25},{value:3,weight:48},{value:4,weight:27}]),role=FC.TransferInterest.roleForClub(player,club);return {id:FC.Utils.uid("renewal"),type:"renewal",negotiationType:"RENEWAL",clubId:club.id,fromClubId:club.id,toClubId:club.id,transferFee:0,weeklyWage:wage,wage:wage,signingBonus:Math.round(wage*(4+years+FC.RNG.int(0,5))/500)*500,contractYears:years,squadRole:role,playingTimeChance:FC.TransferInterest.playingTimeChance(player,club),developmentChance:FC.TransferInterest.developmentChance(club),interestScore:chance,status:"pending"};}
  function renewalOffer(player,club,career,season){var chance=renewalChance(player,club,season);if(chance<=0||FC.RNG.random()>chance/100){return null;}return buildRenewalOffer(player,club,career,season);}
  function applyRenewal(player,career,offer,terms){
    if(!offer||offer.type!=="renewal"||["pending","negotiating"].indexOf(offer.status)<0||!player.clubId||offer.clubId!==player.clubId){return false;}
    terms=terms||offer;
    var clubId=player.clubId,key="CONTRACT_RENEWAL:"+String(offer.id),exists=(player.careerHistory||[]).some(function(x){return x&&x.key===key;});
    if(exists){offer.status="accepted";return true;}
    var merged=Object.assign({},offer,{contractYears:terms.contractYears,weeklyWage:terms.weeklyWage,wage:terms.weeklyWage,squadRole:terms.squadRole}),now=Number(career.currentSeasonState&&career.currentSeasonState.dateIndex||0),start=startSeasonForDay(career,now);
    player.contract=build(clubId,merged,career,start);
    player.careerHistory=player.careerHistory||[];
    player.careerHistory.push({type:"contract_renewed",key:key,season:career.currentSeason,dateIndex:now,age:player.age,clubId:clubId,years:merged.contractYears,weeklyWage:merged.weeklyWage,contractStartSeason:start,contractEndSeason:player.contract.endSeason});
    career.timeline=career.timeline||[];
    career.timeline.push({type:"contract_renewed",key:key,season:career.currentSeason,dateIndex:now,clubId:clubId,title:"Sözleşme Uzatıldı",description:merged.contractYears+" yıllık yeni sözleşme imzalandı."});
    offer.status="accepted";
    if(window.FC.FinanceEngine)FC.FinanceEngine.onContractSigned(player,career,player.contract);
    return true;
  }
  function debugExpiryTest(){var career={currentSeason:"2026-27",currentYear:2026},p={clubId:"x",loan:null,contract:build("x",{id:"debug",contractYears:3,weeklyWage:1000,squadRole:"Prospect"},career,"2026-27")},rows=[];["2026-27","2027-28","2028-29"].forEach(function(season){career.currentSeason=season;career.currentYear=Number(season.slice(0,4));var next=FC.Utils.nextSeason(season);decrementForCompletedSeason(p,career,season,next);var once=p.contract.yearsRemaining;decrementForCompletedSeason(p,career,season,next);rows.push({season:season,remaining:once,afterDuplicate:p.contract.yearsRemaining,status:p.contract.status,endSeason:p.contract.endSeason});});return rows;}
  function debugRenewalTest(iterations){var n=Math.max(1,Number(iterations||10000)),club={id:"debug",squadStrength:64},season={league:{averageRating:7.3,appearances:30,matchOpportunities:34},development:{overallChange:2}},out={};[1,2,3,4].forEach(function(years){var offers=0,chanceTotal=0;for(var i=0;i<n;i++){var p={age:19,overall:65,potential:82,contract:{yearsRemaining:years,weeklyWage:12000}},chance=renewalChance(p,club,season);chanceTotal+=chance;if(FC.RNG.random()<=chance/100){offers++;}}out[years+" year"]={iterations:n,averageCalculatedChance:Math.round(chanceTotal/n*100)/100,renewalOfferPercent:Math.round(offers/n*10000)/100};});console.table(out);return out;}
  window.FC.ContractEngine={RENEWAL_CONFIG:RENEWAL_CONFIG,normalize:normalize,build:build,decrementForCompletedSeason:decrementForCompletedSeason,renewalChance:renewalChance,renewalOffer:renewalOffer,buildRenewalOffer:buildRenewalOffer,applyRenewal:applyRenewal,roleOrder:roleOrder,canonicalRemaining:canonicalRemaining,seasonDistance:seasonDistance,startSeasonForDay:startSeasonForDay,isExpiredAt:isExpiredAt,debugExpiryTest:debugExpiryTest,debugRenewalTest:debugRenewalTest};
})();
