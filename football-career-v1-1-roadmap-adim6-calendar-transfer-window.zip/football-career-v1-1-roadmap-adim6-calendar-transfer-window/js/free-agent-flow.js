(function(){
"use strict";
function status(){var s=FC.State.peek(),p=s&&s.player,c=s&&s.career,day=Number(c&&c.currentSeasonState&&c.currentSeasonState.dateIndex||0),m=c&&c.transferMarket||{},pending=(m.offers||[]).filter(function(o){return ["pending","negotiating"].indexOf(o.status)>=0;});return {freeAgent:!!(p&&!p.clubId),day:day,season:c&&c.currentSeason||null,pendingOffers:pending.length,marketValue:Number(p&&p.marketValue||0)};}
function advance(days){var s=FC.State.peek();if(!s.player||s.player.clubId)return {ok:false,reason:"NOT_FREE_AGENT"};if(window.FC.CareerCalendar&&FC.CareerCalendar.advanceDays){var r=FC.CareerCalendar.advanceDays(days||7);}else{if(!window.FC.MatchdayEngine||!FC.MatchdayEngine.advanceFreeAgentDays)return {ok:false,reason:"ADVANCE_UNAVAILABLE"};var r=FC.MatchdayEngine.advanceFreeAgentDays(days||7);}if(window.FC.UIChrome&&FC.UIChrome.refreshNotifications)FC.UIChrome.refreshNotifications();return r;}
window.FC.FreeAgentFlow={status:status,advanceDays:advance,advanceWeek:function(){return advance(7);}};
})();
