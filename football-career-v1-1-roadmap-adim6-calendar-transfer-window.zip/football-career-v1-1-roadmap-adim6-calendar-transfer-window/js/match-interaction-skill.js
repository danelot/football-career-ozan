(function(){"use strict";
 var APPEARANCE=[.55,.72,.92,1.18,1.48,1.82];
 var EXECUTION=[0,1.4,3.0,5.0,7.2,9.6];
 var CONVERSION=[0,.018,.038,.062,.088,.116];
 var SPECIAL_MAP={POWER_SHOT:"POWER_SHOT",FINESSE:"FINESSE_SHOT",CHIP:"CHIP_SHOT",VOLLEY:"VOLLEY",BICYCLE:"BICYCLE_KICK",TRIVELA:"TRIVELA",RABONA:"RABONA",OUTSIDE_FOOT_PASS:"OUTSIDE_FOOT_PASS",BACKHEEL:"BACKHEEL_PASS"};
 var SPECIAL_BASE_RARITY={FINESSE_SHOT:.18,POWER_SHOT:.10,CHIP_SHOT:.13,VOLLEY:.28,BICYCLE_KICK:.07,TRIVELA:.08,RABONA:.055,THROUGH_BALL:.16,OUTSIDE_FOOT_PASS:.085,BACKHEEL_PASS:.0675};
 var PAIR_MAP={
  "ONE_ON_ONE:place":"FINESSE_SHOT",
  "ONE_ON_ONE:power":"POWER_SHOT",
  "EDGE_OF_BOX_SHOT:placed":"FINESSE_SHOT",
  "EDGE_OF_BOX_SHOT:power":"POWER_SHOT",
  "KEEPER_OFF_LINE:power":"POWER_SHOT",
  "THROUGH_BALL:risky":"THROUGH_BALL",
  "EDGE_OF_BOX_SHOT:slip":"THROUGH_BALL",
  "UNDERLAP_DECISION:thread":"THROUGH_BALL",
  "COUNTER_ATTACK_DECISION:pass":"THROUGH_BALL",
  "FINAL_THIRD_PASS:killer":"THROUGH_BALL",
  "CHAIN_CUT_INSIDE:slip":"THROUGH_BALL",
  "CHAIN_COUNTER_CONTINUE:early":"THROUGH_BALL",
  "CHAIN_PRESS_BROKEN:through":"THROUGH_BALL",
  "CHAIN_DEF_TRANSITION:vertical":"THROUGH_BALL"
 };
 function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
 function level(player,skillId){return window.FC&&FC.SkillMastery&&skillId?FC.SkillMastery.getLevel(skillId,player):0;}
 function skillId(eventType,choice){if(!choice)return null;if(choice.masterySkillId)return choice.masterySkillId;if(choice.special&&SPECIAL_MAP[choice.special])return SPECIAL_MAP[choice.special];return PAIR_MAP[String(eventType||"")+":"+String(choice.id||"")]||null;}
 function appearanceMultiplier(player,skill){var l=level(player,skill);return APPEARANCE[l]||1;}
 function baseAppearanceChance(eventType,choice){var sid=skillId(eventType,choice),explicit=Number(choice&&choice.specialChance);if(isFinite(explicit))return clamp(explicit,.005,.92);return sid&&SPECIAL_BASE_RARITY[sid]!=null?SPECIAL_BASE_RARITY[sid]:.08;}
 function appearanceChance(player,skill,base){base=Number(base);if(!isFinite(base))base=SPECIAL_BASE_RARITY[skill]!=null?SPECIAL_BASE_RARITY[skill]:.08;base=clamp(base,.001,.92);var mult=appearanceMultiplier(player,skill);return clamp(1-Math.pow(1-base,mult),.001,.995);}
 function executionScoreBonus(player,skill){var l=level(player,skill);return EXECUTION[l]||0;} function conversionBonus(player,skill){var l=level(player,skill);return CONVERSION[l]||0;}
 function stars(l){l=clamp(Math.floor(Number(l)||0),0,5);return "★★★★★".slice(0,l)+"☆☆☆☆☆".slice(0,5-l);}
 function metadata(player,eventType,choice){var sid=skillId(eventType,choice);if(!sid)return null;var l=level(player,sid);return {skillId:sid,level:l,stars:stars(l),signature:l===5,appearanceMultiplier:appearanceMultiplier(player,sid),executionScoreBonus:executionScoreBonus(player,sid)};}
 function audit(){return {appearanceCurve:APPEARANCE.slice(),executionScoreCurve:EXECUTION.slice(),conversionCurve:CONVERSION.slice(),specialMap:Object.assign({},SPECIAL_MAP),pairMap:Object.assign({},PAIR_MAP),specialBaseRarity:Object.assign({},SPECIAL_BASE_RARITY)};}
 window.FC.MatchInteractionSkill={getSkillId:skillId,getLevel:level,getAppearanceMultiplier:appearanceMultiplier,getBaseAppearanceChance:baseAppearanceChance,getAppearanceChance:appearanceChance,getExecutionScoreBonus:executionScoreBonus,getConversionBonus:conversionBonus,getMetadata:metadata,getStars:stars,debugAudit:audit};
})();
