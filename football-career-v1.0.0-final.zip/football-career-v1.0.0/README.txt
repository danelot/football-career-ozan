FOOTBALL CAREER V1.0.0

NASIL OYNANIR

1. Oyun klasörünü ZIP'ten çıkarın.
2. index.html dosyasına çift tıklayın.
3. Oyun tarayıcıda açılır.
4. Yeni kariyer oluşturun veya uyumlu mevcut kaydınıza devam edin.

GEREKSİNİMLER

- Kurulum gerekmez.
- Yerel sunucu gerekmez.
- Node.js, npm, Python veya VS Code gerekmez.
- Temel oynanış için internet bağlantısı gerekmez.
- Oyun doğrudan file:// altında çalışacak şekilde tasarlanmıştır.

KAYITLAR

- Kariyer kayıtları tarayıcının localStorage alanında yerel olarak tutulur.
- Uyumlu Football Career kayıtları mevcut kabul edilmiş kayıt uyumluluğu kapsamında desteklenir.
- Tarayıcı site/depolama verilerini silmek kariyer kaydınızı da silebilir.

KULÜP ARMALARI

- Kulüp armaları mevcut yerel ve fallback sistemiyle çalışır.
- İnternet varsa bazı armalar isteğe bağlı çevrimiçi kaynaklardan yüklenebilir.
- Çevrimiçi kaynak kullanılamadığında oyun fallback davranışıyla çalışmaya devam eder.

SÜRÜM

gameVersion: 1.0.0
SAVE_VERSION: 25
dataVersion: 2026.09-step13.0.2
storageFormatVersion: 1
