Reserved for future assets.
