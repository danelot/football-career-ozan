TROPHY + AWARD ARTWORK — PHASE 2.5

All SVG artwork in assets/trophies/ and assets/awards/ was created specifically for this project as original/custom, generic football presentation artwork.

It is NOT official FIFA/UEFA/league/cup/award artwork and is NOT a traced replica of an official trophy, logo, badge or photograph. Competition and award names are used only to map the game's existing stable internal IDs to distinct presentation motifs.

No Google Images, stock-photo download, third-party logo pack, watermark, CDN or remote runtime dependency is used by this asset set.

Fallbacks:
- assets/trophies/fallback-trophy.svg
- assets/awards/fallback-award.svg

The fallback assets are original/custom artwork from the same set.
