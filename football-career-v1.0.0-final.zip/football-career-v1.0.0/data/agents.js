window.FC_DATA=window.FC_DATA||{};
window.FC_DATA.agents=[
 {id:"agent_basic_umut",name:"Umut Demir",tier:"BASIC",reputation:45,negotiation:48,network:46,careerManagement:52,feeRate:.03,signingFee:5000,minOverall:45,minCareerEarnings:0,minBalance:5000,transferReach:1.035,negotiationModifier:1.025},
 {id:"agent_pro_murat",name:"Murat Kaya",tier:"PROFESSIONAL",reputation:72,negotiation:69,network:72,careerManagement:70,feeRate:.05,signingFee:85000,minOverall:62,minCareerEarnings:180000,minBalance:85000,transferReach:1.08,negotiationModifier:1.065},
 {id:"agent_elite_selim",name:"Selim Arslan",tier:"ELITE",reputation:91,negotiation:90,network:92,careerManagement:88,feeRate:.07,signingFee:350000,minOverall:74,minCareerEarnings:900000,minBalance:350000,transferReach:1.145,negotiationModifier:1.11}
];