(function(){"use strict";
window.FC_DATA.awardRules={
  version:1,
  history:{majorKeep:300,competitionKeep:400,newsKeep:160,hallOfFameKeep:250,recentSeasonPerformanceKeep:2},
  global:{
    player_of_year:{id:"world_player_of_year",name:"Dünya Yılın Oyuncusu",minAppearances:18,minMinutes:900,topN:3},
    young_player:{id:"world_young_player_of_year",name:"Dünya Yılın Genç Oyuncusu",maxAge:21,minAppearances:12,minMinutes:600,topN:3},
    goalkeeper:{id:"world_goalkeeper_of_year",name:"Dünya Yılın Kalecisi",positions:["GK"],minAppearances:18,minMinutes:1200,topN:3}
  },
  scoring:{
    ratingBase:6.0,ratingWeight:24,appearanceWeight:5,minutesWeight:4,trophyLeague:5,trophyDomesticCup:4,trophyContinental:10,trophyInternational:12,championContext:2,
    position:{GK:{goal:.4,assist:1.1,cleanSheet:4.20},DEF:{goal:2.5,assist:1.6,cleanSheet:2.10},MID:{goal:1.65,assist:2.0,cleanSheet:.25},ATT:{goal:1.30,assist:1.45,cleanSheet:0}}
  },
  milestones:{appearances:[1,50,100,250,500],goals:[1,50,100,250,500],assists:[50,100,250],internationalCaps:[50,100]},
  legacy:{longevity:12,appearances:18,scoring:20,trophies:18,awards:18,records:8,national:6}
};
})();
