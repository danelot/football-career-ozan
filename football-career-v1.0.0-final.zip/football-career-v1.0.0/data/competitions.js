(function(){"use strict";window.FC_DATA=window.FC_DATA||{};window.FC_DATA.competitions=[
{id:"turkiye_kupasi",name:"Türkiye Kupası",shortName:"TR CUP",type:"DOMESTIC_CUP",countryId:"tur",continent:"Europe",reputation:72,active:true,format:{stageType:"knockout",legs:1}},
{id:"fa_cup",name:"FA Cup",shortName:"FA CUP",type:"DOMESTIC_CUP",countryId:"eng",continent:"Europe",reputation:88,active:true,format:{stageType:"knockout",legs:1}},
{id:"copa_del_rey",name:"Copa del Rey",shortName:"CDR",type:"DOMESTIC_CUP",countryId:"esp",continent:"Europe",reputation:86,active:true,format:{stageType:"knockout",legs:1}},
{id:"coppa_italia",name:"Coppa Italia",shortName:"COPPA",type:"DOMESTIC_CUP",countryId:"ita",continent:"Europe",reputation:84,active:true,format:{stageType:"knockout",legs:1}},
{id:"dfb_pokal",name:"DFB-Pokal",shortName:"POKAL",type:"DOMESTIC_CUP",countryId:"ger",continent:"Europe",reputation:86,active:true,format:{stageType:"knockout",legs:1}},
{id:"coupe_de_france",name:"Coupe de France",shortName:"CDF",type:"DOMESTIC_CUP",countryId:"fra",continent:"Europe",reputation:82,active:true,format:{stageType:"knockout",legs:1}},
{id:"uefa_champions_league",name:"UEFA Champions League",shortName:"UCL",type:"CONTINENTAL",continent:"Europe",reputation:100,active:true,format:{stageType:"group_then_knockout",groupCount:4,clubsPerGroup:4,advanceCount:2,groupRoundRobin:"double",knockoutLegs:2,finalLegs:1},qualificationRules:{tier:1}},
{id:"uefa_europa_league",name:"UEFA Europa League",shortName:"UEL",type:"CONTINENTAL",continent:"Europe",reputation:91,active:true,format:{stageType:"group_then_knockout",groupCount:4,clubsPerGroup:4,advanceCount:2,groupRoundRobin:"double",knockoutLegs:2,finalLegs:1},qualificationRules:{tier:2}},
{id:"uefa_conference_league",name:"UEFA Conference League",shortName:"UECL",type:"CONTINENTAL",continent:"Europe",reputation:82,active:true,format:{stageType:"group_then_knockout",groupCount:4,clubsPerGroup:4,advanceCount:2,groupRoundRobin:"double",knockoutLegs:2,finalLegs:1},qualificationRules:{tier:3}}
];})();
