(function () {
  "use strict";
  window.FC_DATA = window.FC_DATA || {};
  window.FC_DATA.datapack = {
    gameVersion:"1.0.0",
    dataVersion:"2026.09-step13.0.2",
    season:"2026-27",
    name:"Expanded World Datapack - Step 13",
    type:"expanded",
    isComplete:true
  };
})();
