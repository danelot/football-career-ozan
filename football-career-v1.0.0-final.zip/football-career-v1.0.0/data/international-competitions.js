(function(){"use strict";
 window.FC_DATA=window.FC_DATA||{};
 FC_DATA.internationalCompetitions=[
  {id:"uefa_european_championship",name:"UEFA Avrupa Şampiyonası",shortName:"EURO",type:"CONTINENTAL_CHAMPIONSHIP",confederation:"UEFA",frequency:4,baseYear:2028,groupSize:4,hosts:{"2028":"ger","2032":"ita"}},
  {id:"copa_america",name:"Copa América",shortName:"COPA",type:"CONTINENTAL_CHAMPIONSHIP",confederation:"CONMEBOL",frequency:4,baseYear:2028,groupSize:4,hosts:{"2028":"arg","2032":"bra"}},
  {id:"afcon",name:"Afrika Uluslar Kupası",shortName:"AFCON",type:"CONTINENTAL_CHAMPIONSHIP",confederation:"CAF",frequency:4,baseYear:2028,groupSize:4,hosts:{"2028":"mar","2032":"rsa"}},
  {id:"afc_asian_cup",name:"AFC Asya Kupası",shortName:"ASIAN CUP",type:"CONTINENTAL_CHAMPIONSHIP",confederation:"AFC",frequency:4,baseYear:2028,groupSize:4,hosts:{"2028":"qat","2032":"jpn"}},
  {id:"concacaf_gold_cup",name:"CONCACAF Gold Cup",shortName:"GOLD CUP",type:"CONTINENTAL_CHAMPIONSHIP",confederation:"CONCACAF",frequency:4,baseYear:2028,groupSize:4,hosts:{"2028":"usa","2032":"mex"}},
  {id:"fifa_world_cup",name:"FIFA Dünya Kupası",shortName:"WORLD CUP",type:"WORLD_CUP",confederation:"WORLD",frequency:4,baseYear:2030,groupSize:4,hosts:{"2030":"usa","2034":"esp"}}
 ];
})();
