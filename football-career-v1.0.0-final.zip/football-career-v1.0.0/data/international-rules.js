(function(){"use strict";
 window.FC_DATA=window.FC_DATA||{};
 FC_DATA.internationalRules={
  calendar:{seasonDays:400,windows:[41,69,104,139,174],windowGap:3,tournamentSelectionDay:328,tournamentStartDay:335},
  selection:{strongNationRep:85,strongBaseOvr:76,mediumBaseOvr:69,smallBaseOvr:60,injuryBlockSeverities:["MODERATE","MAJOR"],friendlyLocksNationality:false,competitiveLocksNationality:true,tournamentStrictness:3},
  roles:{STARTER:{min:62,max:90},ROTATION:{min:28,max:70},BENCH:{min:1,max:30},RESERVE:{min:0,max:0}},
  worldCup:{frequency:4,baseYear:2030,totalTeams:32,slots:{UEFA:13,CONMEBOL:4,CONCACAF:4,AFC:5,CAF:6,OFC:0}},
  continental:{frequency:4,baseYear:2028,teams:{UEFA:16,CONMEBOL:4,CONCACAF:3,AFC:6,CAF:8,OFC:0}},
  qualifiers:{groupSize:5,tiebreak:["points","goalDifference","goalsFor","teamId"]},
  impact:{maxTeamStrengthBonus:3.2,formWeight:.035,minutesWeight:.045},
  historyCaps:{callUps:80,events:160,tournaments:40,matches:250,milestones:120}
 };
})();
