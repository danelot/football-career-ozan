(function(){"use strict";
 window.FC_DATA=window.FC_DATA||{};
 var strength={tur:78,eng:90,esp:91,ger:89,ita:87,fra:92,por:88,ned:86,bel:84,sco:76,aut:78,sui:80,gre:74,cro:82,srb:78,den:80,nor:79,swe:77,pol:78,cze:76,rou:72,ukr:79,bra:93,arg:94,uru:86,col:85,chi:78,mex:82,usa:82,can:78,jpn:82,kor:81,aus:78,ksa:73,qat:69,mar:84,alg:80,egy:79,nga:82,gha:77,sen:83,cmr:79,rsa:71,irl:73,isl:70,fin:71,hun:75,svn:74,svk:74,bih:73,geo:72};
 function conf(c){if(c.id==="aus")return "AFC";if(c.continent==="Europe")return "UEFA";if(c.continent==="South America")return "CONMEBOL";if(c.continent==="North America")return "CONCACAF";if(c.continent==="Africa")return "CAF";if(c.continent==="Asia")return "AFC";return "OFC";}
 FC_DATA.nationalTeams=(FC_DATA.countries||[]).map(function(c){var s=Number(strength[c.id]||68);return {id:"nt_"+c.id,countryId:c.id,name:c.name,shortName:(c.englishName||c.name).slice(0,3).toUpperCase(),confederation:conf(c),reputation:s,strength:s,qualificationStrength:s,active:true};});
})();
