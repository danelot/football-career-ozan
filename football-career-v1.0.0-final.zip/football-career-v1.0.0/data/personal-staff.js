window.FC_DATA=window.FC_DATA||{};
window.FC_DATA.personalTrainers=[
 {id:"trainer_basic",name:"Temel Kişisel Antrenör",tier:"BASIC",cost:18000,weeklyCost:900,trainingXpModifier:1.04,fatigueModifier:.99,sharpnessModifier:1.01},
 {id:"trainer_pro",name:"Profesyonel Antrenör",tier:"PROFESSIONAL",cost:95000,weeklyCost:3500,trainingXpModifier:1.075,fatigueModifier:.985,sharpnessModifier:1.025},
 {id:"trainer_elite",name:"Elit Performans Antrenörü",tier:"ELITE",cost:380000,weeklyCost:9500,trainingXpModifier:1.11,fatigueModifier:.97,sharpnessModifier:1.04}
];
window.FC_DATA.privatePhysios=[
 {id:"physio_basic",name:"Temel Özel Fizyoterapist",tier:"BASIC",cost:25000,weeklyCost:1200,recoveryModifier:1.04,reinjuryRiskModifier:.96,injuryDurationModifier:.96},
 {id:"physio_pro",name:"Profesyonel Özel Fizyoterapist",tier:"PROFESSIONAL",cost:125000,weeklyCost:4200,recoveryModifier:1.08,reinjuryRiskModifier:.91,injuryDurationModifier:.91},
 {id:"physio_elite",name:"Elit Özel Fizyoterapist",tier:"ELITE",cost:450000,weeklyCost:11000,recoveryModifier:1.12,reinjuryRiskModifier:.86,injuryDurationModifier:.84}
];