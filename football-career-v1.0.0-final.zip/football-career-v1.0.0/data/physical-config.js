window.FC_DATA=window.FC_DATA||{};
window.FC_DATA.physicalConfig={
 trainingLoads:{
  LIGHT:{label:"Hafif",developmentXp:0.78,recovery:1.18,dailyFatigue:0.05,injuryRisk:0.72,sharpness:0.72,matchLoad:0.94},
  NORMAL:{label:"Normal",developmentXp:1.00,recovery:1.00,dailyFatigue:0.22,injuryRisk:1.00,sharpness:1.00,matchLoad:1.00},
  INTENSE:{label:"Yoğun",developmentXp:1.18,recovery:0.82,dailyFatigue:0.58,injuryRisk:1.38,sharpness:1.22,matchLoad:1.08}
 },
 positions:{GK:0.72,CB:0.94,LB:1.02,RB:1.02,CDM:1.04,CM:1.09,CAM:1.04,LW:1.08,RW:1.08,ST:1.00},
 recovery:{fitnessPerDay:3.15,fatiguePerDay:4.15,sharpnessIdleDecay:0.16,injurySharpnessDecay:0.34},
 match:{fitnessCost90:13.5,fatigueGain90:17.0,extraTimeMultiplier:1.18},
 injury:{matchBaseRisk:0.0113,trainingDailyBaseRisk:0.00060,maxMatchRisk:0.16,maxTrainingDailyRisk:0.018},
 reinjury:{minorDays:8,moderateDays:16,majorDays:28}
};
window.FC_DATA.injuries=[
 {id:"knock",name:"Darbe",severity:"MINOR",minDays:1,maxDays:3,weight:28},
 {id:"bruise",name:"Ezilme",severity:"MINOR",minDays:2,maxDays:5,weight:23},
 {id:"ankle_sprain_minor",name:"Hafif Ayak Bileği Burkulması",severity:"MINOR",minDays:4,maxDays:7,weight:16},
 {id:"hamstring_strain",name:"Arka Adale Zorlanması",severity:"MODERATE",minDays:10,maxDays:28,weight:15},
 {id:"groin_strain",name:"Kasık Zorlanması",severity:"MODERATE",minDays:8,maxDays:24,weight:11},
 {id:"calf_strain",name:"Baldır Zorlanması",severity:"MODERATE",minDays:9,maxDays:26,weight:9},
 {id:"knee_sprain",name:"Diz Burkulması",severity:"MODERATE",minDays:14,maxDays:35,weight:6},
 {id:"shoulder_injury",name:"Omuz Sakatlığı",severity:"MODERATE",minDays:10,maxDays:30,weight:3},
 {id:"back_strain",name:"Bel Zorlanması",severity:"MODERATE",minDays:8,maxDays:25,weight:5},
 {id:"muscle_tear",name:"Kas Yırtığı",severity:"MAJOR",minDays:36,maxDays:75,weight:4},
 {id:"ankle_ligament",name:"Ayak Bileği Bağ Sakatlığı",severity:"MAJOR",minDays:45,maxDays:105,weight:2.4},
 {id:"knee_ligament",name:"Diz Bağı Sakatlığı",severity:"MAJOR",minDays:75,maxDays:190,weight:1.1}
];
