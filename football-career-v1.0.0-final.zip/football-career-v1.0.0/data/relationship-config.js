(function(){"use strict";window.FC_DATA=window.FC_DATA||{};window.FC_DATA.relationshipConfig={
 bounds:{relationshipMin:-100,relationshipMax:100,fanMin:-100,fanMax:100,traitMin:0,traitMax:100},
 starting:{club:5,fans:3,traits:{LOYALTY:50,AMBITION:50,PROFESSIONALISM:55,PASSION:50,COMPOSURE:50}},
 legacy:{appearance:.11,start:.025,goal:.55,assist:.32,ratingAbove7:.18,motm:1.1,cleanSheetDef:.28,cleanSheetGK:.38,derbyAppearance:.35,derbyGoal:1.6,finalAppearance:.65,importantGoal:1.35,trophy:7.5,season:3.0,loyaltySeason:.5},
 relationship:{appearance:.025,goodRating:.18,badRating:-.04,goal:.15,assist:.08,motm:.35,derbyGood:.35,cleanSheetDef:.05,trophy:4.5,season:1.5},
 fans:{appearance:.035,goodRating:.20,badRating:-.06,goal:.18,assist:.10,motm:.45,derbyGood:.65,cleanSheetDef:.07,trophy:4.2,season:1.0},
 tags:{fanFavourite:{relationship:65,legacy:25,appearances:50},icon:{relationship:75,legacy:60,appearances:140,seasons:4},legend:{relationship:85,legacy:115,appearances:260,seasons:8},oneClub:{seasons:5,appearances:140}},
 milestones:{appearances:[50,100,200,300,500],goals:[25,50,100,200],seasons:[5,10,15],trophies:[1,5,10]},
 rivalTransfer:{base:8,intensityScale:.18,legendExtra:18,iconExtra:10,favouriteExtra:5,clubScale:.55},
 choices:{doNotCelebrateFormerFan:3,normalCelebrateFormerFan:-2,passionateFormerFan:-7,kissBadgeCurrentFan:8,kissBadgeFormerFan:-12,intentionalMissFormerFan:2},
 historyCaps:{events:300,decisions:150,processedFixtures:900,milestones:300}
};})();
