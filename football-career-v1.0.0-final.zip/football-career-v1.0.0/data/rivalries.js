(function(){"use strict";window.FC_DATA=window.FC_DATA||{};window.FC_DATA.rivalries=[
{id:"tur_intercontinental",clubAId:"tur_fenerbahce",clubBId:"tur_galatasaray",intensity:100,type:"NATIONAL",name:"Kıtalararası Derbi"},
{id:"tur_fbgjk",clubAId:"tur_fenerbahce",clubBId:"tur_besiktas",intensity:91,type:"NATIONAL",name:"İstanbul Derbisi"},
{id:"tur_gsjk",clubAId:"tur_galatasaray",clubBId:"tur_besiktas",intensity:92,type:"NATIONAL",name:"İstanbul Derbisi"},
{id:"esp_clasico",clubAId:"esp_real_madrid",clubBId:"esp_barcelona",intensity:100,type:"HISTORIC",name:"El Clásico"},
{id:"esp_madrid",clubAId:"esp_real_madrid",clubBId:"esp_atletico_madrid",intensity:93,type:"CITY",name:"Derbi Madrileño"},
{id:"ita_milan",clubAId:"ita_inter",clubBId:"ita_ac_milan",intensity:96,type:"CITY",name:"Derby della Madonnina"},
{id:"ita_derby_italia",clubAId:"ita_juventus",clubBId:"ita_inter",intensity:92,type:"HISTORIC",name:"Derby d'Italia"},
{id:"eng_northwest",clubAId:"eng_liverpool",clubBId:"eng_manchester_united",intensity:98,type:"HISTORIC",name:"North-West Derby"},
{id:"eng_northlondon",clubAId:"eng_arsenal",clubBId:"eng_tottenham_hotspur",intensity:96,type:"CITY",name:"North London Derby"},
{id:"eng_manchester",clubAId:"eng_manchester_city",clubBId:"eng_manchester_united",intensity:94,type:"CITY",name:"Manchester Derby"},
{id:"sco_oldfirm",clubAId:"sco_celtic",clubBId:"sco_rangers",intensity:100,type:"CULTURAL",name:"Old Firm"},
{id:"ger_klassiker",clubAId:"ger_bayern_munchen",clubBId:"ger_borussia_dortmund",intensity:90,type:"TITLE",name:"Der Klassiker"},
{id:"fra_classique",clubAId:"fra_paris_saint_germain",clubBId:"fra_marseille",intensity:96,type:"NATIONAL",name:"Le Classique"},
{id:"ned_klassieker",clubAId:"ned_ajax",clubBId:"ned_feyenoord",intensity:97,type:"HISTORIC",name:"De Klassieker"},
{id:"por_ojogo",clubAId:"por_benfica",clubBId:"por_fc_porto",intensity:96,type:"TITLE",name:"O Clássico"},
{id:"por_lisbon",clubAId:"por_benfica",clubBId:"por_sporting_cp",intensity:95,type:"CITY",name:"Derby de Lisboa"},
{id:"srb_eternal",clubAId:"srb_red_star_belgrade",clubBId:"srb_partizan",intensity:100,type:"CITY",name:"Eternal Derby"}
];})();
