(function(){"use strict";
window.FC_DATA=window.FC_DATA||{};
FC_DATA.youthConfig={
  version:2,
  academy:{min:18,max:94,capPerClub:5,historyCap:30,foreignBase:.035,foreignEliteBonus:.10,foreignAcademyBonus:.05},
  intake:{maxPerClub:3,globalSafetyCap:420,sizeWeights:{zero:.12,one:.60,two:.24,three:.04},ages:{16:.34,17:.42,18:.21,19:.03}},
  promotion:{minAge:17,ageOut:20,maxPromotionsPerClub:2,highPotentialProtect:84},
  scouting:{basicWidth:9,scoutedWidth:5,fullWidth:1,maxActive:6},
  rarity:{wonderkidPot:90,wonderkidMinOvr:58,generationalPot:99,generationalMinOvr:82},
  cleanup:{lowValueMaxPot:69,lowValueMaxOvr:49}
};
var strong={ARG:91,BRA:94,ENG:88,FRA:92,ESP:91,GER:89,ITA:86,POR:87,NED:87,BEL:82,CRO:81,URU:84,COL:82,TUR:74,USA:76,MEX:75,JPN:76,KOR:73,MAR:78,NGA:78,SEN:79,GHA:72,SRB:76,SUI:77,AUT:75,DEN:76,SWE:74,NOR:73,POL:73,CZE:73,ROU:68,GRE:68,UKR:73,RUS:72,SCO:70,IRL:64,WAL:68,GEO:65,SAU:66,QAT:61,AUS:72,CHN:58,IND:49,RSA:66,EGY:74,TUN:70,ALG:76,CMR:76,CAN:73,CRC:67,CHI:75,PER:71};
FC_DATA.countryTalentProfiles={};(FC_DATA.countries||[]).forEach(function(c){var key=String(c.id||"").toUpperCase(),code=String(c.code||"").toUpperCase();FC_DATA.countryTalentProfiles[c.id]={countryId:c.id,youthTalentRating:strong[key]||strong[code]||60};});
})();
