(function(){
  "use strict";
  var outfield=["acceleration","sprintSpeed","positioning","finishing","shotPower","longShots","volleys","penalties","vision","crossing","freeKickAccuracy","shortPassing","longPassing","curve","agility","balance","reactions","ballControl","dribbling","composure","interceptions","headingAccuracy","defensiveAwareness","standingTackle","slidingTackle","jumping","stamina","strength","aggression"];
  var gk=["gkDiving","gkHandling","gkKicking","gkReflexes","gkPositioning"];
  var labels={acceleration:"Hızlanma",sprintSpeed:"Sprint Hızı",positioning:"Pozisyon Alma",finishing:"Bitiricilik",shotPower:"Şut Gücü",longShots:"Uzaktan Şut",volleys:"Vole",penalties:"Penaltı",vision:"Vizyon",crossing:"Orta Açma",freeKickAccuracy:"Serbest Vuruş",shortPassing:"Kısa Pas",longPassing:"Uzun Pas",curve:"Falso",agility:"Çeviklik",balance:"Denge",reactions:"Reaksiyon",ballControl:"Top Kontrolü",dribbling:"Dribbling",composure:"Soğukkanlılık",interceptions:"Araya Girme",headingAccuracy:"Kafa İsabeti",defensiveAwareness:"Savunma Farkındalığı",standingTackle:"Ayakta Müdahale",slidingTackle:"Kayarak Müdahale",jumping:"Sıçrama",stamina:"Dayanıklılık",strength:"Güç",aggression:"Agresiflik",gkDiving:"Kaleci Uçuş",gkHandling:"Kaleci Top Tutma",gkKicking:"Kaleci Vuruş",gkReflexes:"Kaleci Refleks",gkPositioning:"Kaleci Pozisyon Alma"};
  var groups={pace:["acceleration","sprintSpeed"],shooting:["positioning","finishing","shotPower","longShots","volleys","penalties"],passing:["vision","crossing","freeKickAccuracy","shortPassing","longPassing","curve"],dribbling:["agility","balance","reactions","ballControl","dribbling","composure"],defending:["interceptions","headingAccuracy","defensiveAwareness","standingTackle","slidingTackle"],physical:["jumping","stamina","strength","aggression"]};
  var categoryLabels={pace:"HIZ",shooting:"ŞUT",passing:"PAS",dribbling:"DRİBLİNG",defending:"SAVUNMA",physical:"FİZİK"};
  var categoryShort={pace:"PAC",shooting:"SHO",passing:"PAS",dribbling:"DRI",defending:"DEF",physical:"PHY"};
  var positionWeights={
    ST:{finishing:15,positioning:12,shotPower:9,reactions:9,ballControl:8,acceleration:7,sprintSpeed:7,composure:7,dribbling:6,headingAccuracy:5,strength:5,longShots:4,agility:3,stamina:3},
    RW:{acceleration:11,sprintSpeed:10,dribbling:11,ballControl:10,agility:8,finishing:8,positioning:6,crossing:8,vision:5,shortPassing:5,reactions:5,composure:4,longShots:3,curve:3,stamina:3},
    LW:{acceleration:11,sprintSpeed:10,dribbling:11,ballControl:10,agility:8,finishing:8,positioning:6,crossing:8,vision:5,shortPassing:5,reactions:5,composure:4,longShots:3,curve:3,stamina:3},
    CAM:{vision:12,shortPassing:11,ballControl:11,dribbling:9,composure:8,reactions:8,positioning:7,finishing:6,longShots:6,agility:6,longPassing:5,curve:4,acceleration:4,stamina:3},
    CM:{shortPassing:12,longPassing:10,vision:10,reactions:9,stamina:9,ballControl:9,composure:7,interceptions:5,dribbling:5,defensiveAwareness:5,longShots:4,standingTackle:4,agility:4,strength:3,acceleration:3},
    CDM:{interceptions:13,defensiveAwareness:12,standingTackle:11,stamina:9,strength:8,shortPassing:9,longPassing:7,reactions:7,aggression:6,headingAccuracy:4,ballControl:4,slidingTackle:4,composure:3,vision:3},
    CB:{defensiveAwareness:16,standingTackle:14,interceptions:13,strength:11,headingAccuracy:10,jumping:7,reactions:7,slidingTackle:7,aggression:5,shortPassing:4,composure:3,stamina:2,acceleration:1},
    RB:{acceleration:10,sprintSpeed:9,stamina:11,crossing:10,standingTackle:10,interceptions:9,defensiveAwareness:8,ballControl:7,shortPassing:6,dribbling:5,reactions:5,slidingTackle:4,agility:3,strength:2,aggression:1},
    LB:{acceleration:10,sprintSpeed:9,stamina:11,crossing:10,standingTackle:10,interceptions:9,defensiveAwareness:8,ballControl:7,shortPassing:6,dribbling:5,reactions:5,slidingTackle:4,agility:3,strength:2,aggression:1},
    GK:{gkReflexes:24,gkPositioning:21,gkDiving:20,gkHandling:18,gkKicking:8,reactions:5,composure:4}
  };
  var archetypeOffsets={
    ST:{finishing:9,positioning:8,shotPower:5,reactions:4,ballControl:3,acceleration:4,sprintSpeed:4,dribbling:2,composure:2,headingAccuracy:1,strength:1,defensiveAwareness:-24,standingTackle:-25,slidingTackle:-27,interceptions:-22,crossing:-8,longPassing:-7},
    RW:{acceleration:8,sprintSpeed:8,dribbling:7,ballControl:6,agility:7,crossing:4,finishing:3,vision:2,shortPassing:1,strength:-5,defensiveAwareness:-18,standingTackle:-18,slidingTackle:-20,interceptions:-16},
    LW:{acceleration:8,sprintSpeed:8,dribbling:7,ballControl:6,agility:7,crossing:4,finishing:3,vision:2,shortPassing:1,strength:-5,defensiveAwareness:-18,standingTackle:-18,slidingTackle:-20,interceptions:-16},
    CAM:{vision:9,shortPassing:8,ballControl:8,dribbling:6,composure:5,reactions:4,longShots:3,finishing:2,agility:4,standingTackle:-16,slidingTackle:-18,defensiveAwareness:-14,headingAccuracy:-8,strength:-5},
    CM:{shortPassing:6,longPassing:5,vision:5,reactions:4,stamina:5,ballControl:4,composure:3,interceptions:1,standingTackle:0,finishing:-4,headingAccuracy:-3},
    CDM:{interceptions:8,defensiveAwareness:8,standingTackle:8,stamina:6,strength:7,shortPassing:4,longPassing:3,reactions:3,aggression:6,finishing:-16,shotPower:-7,dribbling:-5,volleys:-12},
    CB:{defensiveAwareness:9,standingTackle:9,interceptions:8,strength:10,headingAccuracy:7,jumping:8,reactions:3,slidingTackle:7,aggression:7,shortPassing:0,stamina:2,acceleration:-5,sprintSpeed:-4,finishing:-24,shotPower:-10,longShots:-14,dribbling:-12,crossing:-14,volleys:-20},
    RB:{acceleration:7,sprintSpeed:7,stamina:7,crossing:5,standingTackle:4,interceptions:4,defensiveAwareness:3,ballControl:2,shortPassing:2,dribbling:1,finishing:-15,shotPower:-10,volleys:-10,headingAccuracy:-5},
    LB:{acceleration:7,sprintSpeed:7,stamina:7,crossing:5,standingTackle:4,interceptions:4,defensiveAwareness:3,ballControl:2,shortPassing:2,dribbling:1,finishing:-15,shotPower:-10,volleys:-10,headingAccuracy:-5},
    GK:{gkReflexes:6,gkPositioning:5,gkDiving:5,gkHandling:4,gkKicking:1,reactions:3,composure:1,acceleration:-15,sprintSpeed:-16,finishing:-35,positioning:-28,shotPower:-20,longShots:-30,volleys:-30,crossing:-22,dribbling:-20,standingTackle:-20,slidingTackle:-25}
  };
  var developmentWeights={
    ST:{finishing:10,positioning:9,shotPower:7,ballControl:7,reactions:7,composure:6,acceleration:5,sprintSpeed:5,dribbling:5,headingAccuracy:3,strength:3,stamina:2,shortPassing:2},
    RW:{acceleration:9,sprintSpeed:9,dribbling:9,ballControl:8,agility:8,crossing:6,finishing:5,vision:4,shortPassing:4,composure:3,stamina:3},LW:null,
    CAM:{vision:10,shortPassing:9,ballControl:9,dribbling:8,composure:7,reactions:6,longShots:5,finishing:5,agility:5,longPassing:4,curve:4,stamina:2},
    CM:{shortPassing:10,longPassing:8,vision:8,reactions:7,stamina:8,ballControl:7,composure:5,interceptions:4,dribbling:4,defensiveAwareness:3,longShots:3,standingTackle:3},
    CDM:{interceptions:10,defensiveAwareness:10,standingTackle:9,stamina:8,strength:7,shortPassing:7,longPassing:5,reactions:5,aggression:5,slidingTackle:4,ballControl:3},
    CB:{defensiveAwareness:11,standingTackle:10,interceptions:10,strength:9,headingAccuracy:8,jumping:6,reactions:6,slidingTackle:6,aggression:5,shortPassing:3,acceleration:2,sprintSpeed:2},
    RB:{acceleration:8,sprintSpeed:8,stamina:9,crossing:8,standingTackle:7,interceptions:7,defensiveAwareness:6,ballControl:5,shortPassing:5,dribbling:4,reactions:4},LB:null,
    GK:{gkReflexes:11,gkPositioning:10,gkDiving:10,gkHandling:9,gkKicking:5,reactions:4,composure:3}
  };
  developmentWeights.LW=developmentWeights.RW;developmentWeights.LB=developmentWeights.RB;
  window.FC.AttributeConfig={outfieldAttributes:outfield,gkAttributes:gk,allAttributes:outfield.concat(gk),labels:labels,groups:groups,categoryLabels:categoryLabels,categoryShort:categoryShort,positionWeights:positionWeights,archetypeOffsets:archetypeOffsets,developmentWeights:developmentWeights};
})();
