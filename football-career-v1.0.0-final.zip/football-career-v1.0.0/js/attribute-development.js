(function(){
  "use strict";
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function diminishingMultiplier(value){
    value=Number(value||1);
    if(value>=90){return 0.08;}
    if(value>=80){return 0.24;}
    if(value>=70){return 0.48;}
    if(value>=60){return 0.72;}
    return 1;
  }
  function eligibleKeys(player){
    var map=FC.AttributeConfig.developmentWeights[player.position]||FC.AttributeConfig.developmentWeights.CM;
    var isGK=player.position==="GK";
    var pool=isGK?FC.AttributeConfig.gkAttributes.concat(["reactions","composure","shortPassing","strength"]):FC.AttributeConfig.outfieldAttributes;
    return pool.map(function(k){
      var base=map[k]!=null?Number(map[k]):0.12;
      var value=Number(player.attributes[k]||1);
      return {value:k,weight:Math.max(0.001,base*diminishingMultiplier(value))};
    });
  }
  function eventPointCount(player,context){
    var quality=0;
    context=context||{};
    if(context.club){quality+=((Number(context.club.academyQuality||50)+Number(context.club.trainingQuality||50))/2-50)/250;}
    if(Number(player.age||18)<=16){quality+=0.04;}
    if(Number(player.morale||50)>=75){quality+=0.03;}
    var roll=FC.RNG.random()+clamp(quality,-0.08,0.10);
    if(roll>0.985){return 4;}
    if(roll>0.84){return 3;}
    if(roll>0.43){return 2;}
    return 1;
  }
  function canApplyPoint(player,state,key){
    var before=Number(player.attributes[key]||1);
    if(before>=99){return false;}
    player.attributes[key]=before+1;
    var calculated=FC.OverallCalculator.calculate(player.position,player.attributes);
    var allowed=Math.min(Number(player.potential||99),Number(state.startingOverall||player.overall)+FC.SeasonConfig.maxSeasonGrowth);
    player.attributes[key]=before;
    return calculated<=allowed;
  }
  function applyPoint(player,state,key){
    if(!canApplyPoint(player,state,key)){return false;}
    player.attributes[key]=FC.Attributes.clamp(Number(player.attributes[key]||1)+1);
    state.attributeChanges[key]=(state.attributeChanges[key]||0)+1;
    state.attributePoints=(state.attributePoints||0)+1;
    return true;
  }
  function applyDevelopmentEvent(player,state,context){
    var cfg=FC.SeasonConfig.development;
    var requested=Math.min(cfg.maxAttributePointsPerEvent||4,eventPointCount(player,context));if(player.position==="GK"){requested=1;}
    var applied=0,maxAttempts=requested*(cfg.maxAllocationAttemptsPerPoint||10);
    for(var attempt=0;attempt<maxAttempts&&applied<requested;attempt++){
      var key=FC.RNG.weighted(eligibleKeys(player));
      if(!key){break;}
      if(applyPoint(player,state,key)){applied++;}
    }
    FC.OverallCalculator.recalculate(player);
    state.seasonGrowth=player.overall-state.startingOverall;
    state.developmentEvents=(state.developmentEvents||0)+1;
    return {requestedPoints:requested,appliedPoints:applied,overall:player.overall,overallChange:state.seasonGrowth};
  }
  function topChanges(changes,limit){return Object.keys(changes||{}).filter(function(k){return changes[k]>0;}).sort(function(a,b){return changes[b]-changes[a];}).slice(0,limit||6).map(function(k){return {attribute:k,label:FC.Attributes.label(k),change:changes[k]};});}
  window.FC.AttributeDevelopment={applyDevelopmentEvent:applyDevelopmentEvent,topChanges:topChanges,diminishingMultiplier:diminishingMultiplier};
})();
