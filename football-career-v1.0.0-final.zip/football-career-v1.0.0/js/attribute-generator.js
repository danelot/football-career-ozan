(function(){
  "use strict";
  function clone(o){var r={};Object.keys(o||{}).forEach(function(k){r[k]=o[k];});return r;}
  function generateRaw(position,target){var offsets=FC.AttributeConfig.archetypeOffsets[position]||{},attrs={},isGK=position==="GK";FC.AttributeConfig.allAttributes.forEach(function(k){var gkAttr=FC.AttributeConfig.gkAttributes.indexOf(k)>=0,base;if(gkAttr&&!isGK){base=FC.RNG.int(5,14);}else if(isGK&&gkAttr){base=target+(offsets[k]||0)+FC.RNG.int(-5,5);}else if(isGK){base=Math.max(6,target+(offsets[k]!=null?offsets[k]:-12)+FC.RNG.int(-6,6));}else{base=target+(offsets[k]||0)+FC.RNG.int(-7,7);}attrs[k]=FC.Attributes.clamp(base);});return attrs;}
  function normalize(position,attrs,target){var weights=FC.AttributeConfig.positionWeights[position]||FC.AttributeConfig.positionWeights.CM,keys=Object.keys(weights).sort(function(a,b){return weights[b]-weights[a];}),guard=0,current=FC.OverallCalculator.calculate(position,attrs);while(current!==target&&guard<240){var dir=current<target?1:-1,changed=false;for(var i=0;i<keys.length;i++){var k=keys[(i+guard)%keys.length],before=attrs[k];if((dir>0&&before>=99)||(dir<0&&before<=1)){continue;}attrs[k]=FC.Attributes.clamp(before+dir);var next=FC.OverallCalculator.calculate(position,attrs);if((dir>0&&next<=target)||(dir<0&&next>=target)){current=next;changed=true;break;}attrs[k]=before;}if(!changed){break;}guard++;}return attrs;}
  function generateForPosition(position,target){target=Math.max(1,Math.min(99,Math.round(target)));var attrs=normalize(position,generateRaw(position,target),target);return {attributes:attrs,categories:FC.Attributes.categories(attrs),gkCategories:FC.Attributes.gkCategories(attrs),overall:FC.OverallCalculator.calculate(position,attrs)};}
  function createPlayer(position,target,potential){var g=generateForPosition(position,target);return {position:position,overall:g.overall,potential:potential||Math.max(target,target+10),attributes:g.attributes,attributeCategories:g.categories,gkAttributeCategories:g.gkCategories};}
  function runGenerationTest(count,target){
    count=Number(count)||1000;target=Number(target)||52;
    var positions=["GK","RB","CB","LB","CDM","CM","CAM","RW","LW","ST"],categoryKeys=["pace","shooting","passing","dribbling","defending","physical"];
    var reports=positions.map(function(pos){
      var sum=0,min=999,max=-1,invalid=0,attrMin=99,attrMax=1,cats={};
      categoryKeys.forEach(function(k){cats[k]={sum:0,sumSq:0,min:99,max:1};});
      for(var i=0;i<count;i++){
        var g=generateForPosition(pos,target),o=g.overall;sum+=o;min=Math.min(min,o);max=Math.max(max,o);
        categoryKeys.forEach(function(k){var v=Number(g.categories[k]||1),c=cats[k];c.sum+=v;c.sumSq+=v*v;c.min=Math.min(c.min,v);c.max=Math.max(c.max,v);});
        FC.AttributeConfig.allAttributes.forEach(function(k){var v=g.attributes[k];attrMin=Math.min(attrMin,v);attrMax=Math.max(attrMax,v);if(v<1||v>99||isNaN(v)){invalid++;}});
      }
      function avg(k){return cats[k].sum/count;}
      function sd(k){var a=avg(k);return Math.sqrt(Math.max(0,cats[k].sumSq/count-a*a));}
      return {position:pos,targetOVR:target,averageCalculatedOVR:Math.round(sum/count*100)/100,minimumOVR:min,maximumOVR:max,averagePAC:Math.round(avg("pace")*100)/100,averageSHO:Math.round(avg("shooting")*100)/100,averagePAS:Math.round(avg("passing")*100)/100,averageDRI:Math.round(avg("dribbling")*100)/100,averageDEF:Math.round(avg("defending")*100)/100,averagePHY:Math.round(avg("physical")*100)/100,shootingMin:cats.shooting.min,shootingMax:cats.shooting.max,shootingSD:Math.round(sd("shooting")*100)/100,passingMin:cats.passing.min,passingMax:cats.passing.max,passingSD:Math.round(sd("passing")*100)/100,defendingMin:cats.defending.min,defendingMax:cats.defending.max,defendingSD:Math.round(sd("defending")*100)/100,physicalMin:cats.physical.min,physicalMax:cats.physical.max,physicalSD:Math.round(sd("physical")*100)/100,attributeMin:attrMin,attributeMax:attrMax,invalidAttributeCount:invalid};
    });
    console.table(reports);return reports;
  }
  function positionAwareTest(){var attack=generateForPosition("ST",60).attributes,defense=generateForPosition("CB",60).attributes,r={attackingSet:{ST:FC.OverallCalculator.calculate("ST",attack),CB:FC.OverallCalculator.calculate("CB",attack)},defensiveSet:{ST:FC.OverallCalculator.calculate("ST",defense),CB:FC.OverallCalculator.calculate("CB",defense)}};console.table([r.attackingSet,r.defensiveSet]);return r;}
  window.FC.AttributeGenerator={generateForPosition:generateForPosition,createPlayer:createPlayer,runGenerationTest:runGenerationTest,runPositionAwareTest:positionAwareTest,_normalize:normalize};
})();
