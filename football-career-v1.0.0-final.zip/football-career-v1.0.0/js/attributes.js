(function(){
  "use strict";
  function clamp(v){return Math.max(1,Math.min(99,Math.round(Number(v)||1)));}
  function weighted(attrs,map){var sum=0,w=0;Object.keys(map).forEach(function(k){if(attrs[k]!=null){sum+=Number(attrs[k])*map[k];w+=map[k];}});return w?Math.round(sum/w):1;}
  var categoryWeights={pace:{acceleration:55,sprintSpeed:45},shooting:{positioning:16,finishing:25,shotPower:20,longShots:16,volleys:11,penalties:12},passing:{vision:20,crossing:18,freeKickAccuracy:10,shortPassing:22,longPassing:18,curve:12},dribbling:{agility:15,balance:10,reactions:20,ballControl:22,dribbling:23,composure:10},defending:{interceptions:21,headingAccuracy:13,defensiveAwareness:25,standingTackle:24,slidingTackle:17},physical:{jumping:20,stamina:28,strength:31,aggression:21}};
  function sanitize(attrs){var out={};FC.AttributeConfig.allAttributes.forEach(function(k){out[k]=clamp(attrs&&attrs[k]!=null?attrs[k]:1);});return out;}
  function categories(attrs){attrs=sanitize(attrs);var out={};Object.keys(categoryWeights).forEach(function(k){out[k]=weighted(attrs,categoryWeights[k]);});return out;}
  function gkCategories(attrs){attrs=sanitize(attrs);return {diving:attrs.gkDiving,handling:attrs.gkHandling,kicking:attrs.gkKicking,reflexes:attrs.gkReflexes,positioning:attrs.gkPositioning};}
  function label(k){return FC.AttributeConfig.labels[k]||k;}
  function valueClass(v){v=Number(v)||0;return v>=80?"attr-elite":v>=70?"attr-high":v>=60?"attr-good":v>=50?"attr-mid":v>=40?"attr-low":"attr-very-low";}
  window.FC.Attributes={clamp:clamp,sanitize:sanitize,categories:categories,gkCategories:gkCategories,label:label,valueClass:valueClass};
})();
