(function(){"use strict";
  window.FC.Career={create:function(){var d=FC_DATA.datapack;return {id:FC.Utils.uid("career"),createdAt:new Date().toISOString(),startSeason:d.season,currentSeason:d.season,currentYear:2026,seasonsPlayed:0,status:"active",pendingOffers:[],transferHistory:[],pendingTransferWindow:null,seasons:[],currentSeasonState:{season:d.season,status:"ready"},timeline:[{type:"career_started",date:new Date().toISOString(),season:d.season,title:"Kariyer Başladı",description:"Profesyonel yolculuk için ilk adım atıldı."}]};}};
})();
