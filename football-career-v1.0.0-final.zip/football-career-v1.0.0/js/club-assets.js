(function(){"use strict";
 function club(id){return (FC_DATA.clubs||[]).find(function(c){return c.id===id;});}
 function asset(id){return FC_DATA.clubAssets&&FC_DATA.clubAssets[id]||{};}
 function initials(id){var c=club(id),s=(c&&c.shortName)||((c&&c.name)||"?");var parts=String(s).replace(/[^A-Za-zÀ-ž0-9 ]/g," ").trim().split(/\s+/);return (parts.length>1?(parts[0][0]+parts[1][0]):s.slice(0,3)).toUpperCase();}
 function color(id,which){var a=asset(id);if(which==="primary"&&a.primaryColor)return a.primaryColor;if(which==="secondary"&&a.secondaryColor)return a.secondaryColor;var str=String(id||"club"),h=0;for(var i=0;i<str.length;i++)h=(h*31+str.charCodeAt(i))>>>0;var hue=h%360;return which==="secondary"?"hsl("+((hue+42)%360)+" 45% 18%)":"hsl("+hue+" 58% 38%)";}
 function getLocal(id){return asset(id).localCrest||null;}
 function getRemote(id){return asset(id).remoteCrest||asset(id).logoUrl||null;}
 function getCrest(id){return getLocal(id)||getRemote(id)||null;}
 function fallbackStyle(id){return "background:linear-gradient(145deg,"+color(id,"primary")+","+color(id,"secondary")+");color:#fff";}
 function badgeHtml(id,cls){var a=asset(id),src=getCrest(id),ini=FC.Utils.escapeHtml(initials(id)),c=cls||"club-badge",remote=getRemote(id)||"";if(!src){return "<span class='"+c+" club-badge-fallback' style='"+fallbackStyle(id)+"'>"+ini+"</span>";}return "<span class='"+c+"'><img loading='lazy' referrerpolicy='no-referrer' data-club-id='"+FC.Utils.escapeHtml(id)+"' data-remote-crest='"+FC.Utils.escapeHtml(remote)+"' data-crest-stage='"+(getLocal(id)?"local":"remote")+"' src='"+FC.Utils.escapeHtml(src)+"' alt='' onerror='FC.ClubAssets.handleError(this)'><span class='club-badge-fallback' style='display:none;"+fallbackStyle(id)+"'>"+ini+"</span></span>";}
 function handleError(img){if(!img)return;var stage=img.getAttribute("data-crest-stage"),remote=img.getAttribute("data-remote-crest");if(stage==="local"&&remote&&img.src!==remote){img.setAttribute("data-crest-stage","remote");img.src=remote;return;}img.onerror=null;img.style.display="none";var fb=img.nextElementSibling;if(fb)fb.style.display="grid";}
 function applyImage(img,id){if(!img)return false;var local=getLocal(id),remote=getRemote(id),src=local||remote;if(!src){img.style.display="none";return false;}img.setAttribute("data-club-id",id);img.setAttribute("data-remote-crest",remote||"");img.setAttribute("data-crest-stage",local?"local":"remote");img.onerror=function(){handleError(img);};img.src=src;return true;}
 window.FC.ClubAssets={getCrest:getCrest,getLogoUrl:getRemote,getLocalCrest:getLocal,getRemoteCrest:getRemote,getFallback:initials,getColors:function(id){return {primary:color(id,"primary"),secondary:color(id,"secondary")};},badgeHtml:badgeHtml,applyImage:applyImage,handleError:handleError};
})();
