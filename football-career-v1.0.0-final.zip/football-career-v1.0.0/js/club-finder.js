(function(){"use strict";
  var CONFIG={
    banEliteAtStart:true,
    eliteReputation:90,
    hardReputationCaps:[{maxOvr:50,maxRep:74},{maxOvr:53,maxRep:81},{maxOvr:56,maxRep:89}],
    minOffers:3,maxOffers:6,
    domesticWeight:1.72,
    foreignBaseWeight:0.42,
    minFit:34,
    squadGapHardMax:28,
    lowOvrHighGapPenaltyStart:14
  };
  function leagueById(id){return FC_DATA.leagues.find(function(l){return l.id===id;});}
  function clubById(id){return FC_DATA.clubs.find(function(c){return c.id===id;});}
  function hardEligible(player,club){
    if(!club||!club.active||!club.professional){return false;}
    var league=leagueById(club.leagueId);if(!league||!league.active||!league.professional){return false;}
    if(CONFIG.banEliteAtStart&&club.reputation>=CONFIG.eliteReputation){return false;}
    for(var i=0;i<CONFIG.hardReputationCaps.length;i++){var r=CONFIG.hardReputationCaps[i];if(player.overall<=r.maxOvr&&club.reputation>r.maxRep){return false;}}
    var gap=club.squadStrength-player.overall;
    if(gap>CONFIG.squadGapHardMax){return false;}
    if(gap>23&&player.potential<84){return false;}
    if(gap>20&&player.overall<=48&&player.potential<82){return false;}
    if(club.reputation>=82&&player.potential<82){return false;}
    return true;
  }
  function desiredClubReputation(player){
    return Math.max(34,Math.min(78,40+(player.overall-45)*2.2+Math.max(0,player.potential-68)*0.28+(player.age-16)*1.5));
  }
  function desiredSquadGap(player){
    return Math.max(5,Math.min(11,7+Math.max(0,player.potential-68)*0.07+(player.age-16)*1.2));
  }
  function calculateFit(player,club){
    var league=leagueById(club.leagueId);if(!league||!hardEligible(player,club)){return 0;}
    var gap=club.squadStrength-player.overall;
    var desiredGap=desiredSquadGap(player);
    var gapDistance=Math.abs(gap-desiredGap);
    var squadFit=Math.max(0,100-gapDistance*6.1);
    if(gap>CONFIG.lowOvrHighGapPenaltyStart){squadFit-=Math.max(0,gap-CONFIG.lowOvrHighGapPenaltyStart)*(player.overall<=48?7.5:5.2);}
    if(gap<0){squadFit-=Math.min(22,Math.abs(gap)*2.2);}
    squadFit=Math.max(0,squadFit);

    var targetRep=desiredClubReputation(player);
    var repDelta=club.reputation-targetRep;
    var repFit=Math.max(0,100-Math.abs(repDelta)*(repDelta>0?5.3:2.8));
    var leagueDelta=league.reputation-(targetRep+8);
    var leagueFit=Math.max(0,100-Math.abs(leagueDelta)*(leagueDelta>0?3.9:2.0));
    if(player.overall<=48&&league.level===1&&league.reputation>=70){leagueFit*=0.55;}
    else if(player.overall<=52&&league.level===1&&league.reputation>=78){leagueFit*=0.70;}

    var potentialBoost=Math.max(0,player.potential-68);
    var academyBase=club.academyQuality*0.46+club.youthPolicy*0.54;
    var academyFit=Math.min(100,academyBase+potentialBoost*0.65);
    var ageFit=player.age===15?club.youthPolicy:player.age===16?(club.youthPolicy*0.72+league.youthOpportunity*0.28):(club.youthPolicy*0.52+squadFit*0.48);
    var nationality=player.nationalityId===club.countryId?100:Math.min(74,24+league.youthOpportunity*0.55);
    var levelPreference=100;
    if(player.overall<=48){levelPreference=league.level>=2?100:72;}
    else if(player.overall<=52){levelPreference=league.level>=2?96:88;}
    else if(player.overall<=55){levelPreference=league.level===1?96:92;}

    var fit=squadFit*0.31+repFit*0.20+leagueFit*0.11+academyFit*0.17+ageFit*0.10+nationality*0.07+levelPreference*0.04;
    if(gap>18&&player.potential>=82&&club.youthPolicy>=72){fit+=Math.min(7,(player.potential-81)*0.8);}
    return Math.max(0,Math.min(100,Math.round(fit)));
  }
  function findEligibleClubs(player){return FC_DATA.clubs.filter(function(c){return hardEligible(player,c);}).map(function(c){return {club:c,fitScore:calculateFit(player,c)};}).filter(function(x){return x.fitScore>=CONFIG.minFit;}).sort(function(a,b){return b.fitScore-a.fitScore;});}
  function playingChance(player,club){var gap=club.squadStrength-player.overall;var score=74-gap*2.45+(club.youthPolicy-50)*0.40+(player.age-15)*4;return Math.max(15,Math.min(94,Math.round(score)));}
  function developmentChance(club){return Math.max(25,Math.min(98,Math.round(club.academyQuality*.42+club.trainingQuality*.34+club.youthPolicy*.24)));}
  function roleFor(player,club,play){if(player.age===15){return play>=72&&club.reputation<60?"Prospect":"Academy";}if(player.age===16){return play>=80&&club.reputation<61?"Rotation":play>=52?"Prospect":"Academy";}return play>=84&&club.reputation<57?"First Team":play>=63?"Rotation":"Prospect";}
  function wageFor(player,club,fit){var base=180+(player.overall-45)*85+(player.potential-65)*22;var finance=0.55+club.financialPower/85;var rep=0.7+club.reputation/140;var value=base*finance*rep*(0.9+fit/450);var step=value<1000?50:100;return Math.max(250,Math.round(value/step)*step);}
  function yearsFor(player){var weights=player.age<=16?[{value:3,weight:55},{value:4,weight:30},{value:2,weight:15}]:[{value:3,weight:50},{value:2,weight:25},{value:4,weight:25}];return FC.RNG.weighted(weights);}
  function buildOffer(player,item){var club=item.club,fit=item.fitScore,play=playingChance(player,club),dev=developmentChance(club),years=yearsFor(player),wage=wageFor(player,club,fit);return {id:FC.Utils.uid("offer"),clubId:club.id,contractYears:years,weeklyWage:wage,signingBonus:Math.round((wage*(3+FC.RNG.int(0,5)))/100)*100,squadRole:roleFor(player,club,play),playingTimeChance:play,developmentChance:dev,offerScore:Math.round(fit*.62+play*.18+dev*.20)};}
  function weightedPick(pool,player,usedCountries,usedBands){var opts=pool.map(function(x){var league=leagueById(x.club.leagueId),dom=x.club.countryId===player.nationalityId;var band=Math.floor(x.club.reputation/10);var diversity=(usedCountries[x.club.countryId]?0.68:1.12)*(usedBands[band]?0.76:1.08);var foreign=dom?CONFIG.domesticWeight:CONFIG.foreignBaseWeight*(0.52+league.youthOpportunity/100);var targetRep=desiredClubReputation(player);var overTarget=Math.max(0,x.club.reputation-targetRep);var realismPenalty=1/(1+Math.pow(overTarget/10,2));var gap=x.club.squadStrength-player.overall;var gapPenalty=gap>14?1/(1+Math.pow((gap-14)/6,2)):1;return {value:x,weight:Math.max(0.5,x.fitScore*x.fitScore*foreign*diversity*realismPenalty*gapPenalty)};});return FC.RNG.weighted(opts);}
  function targetCount(){return FC.RNG.weighted([{value:3,weight:28},{value:4,weight:38},{value:5,weight:27},{value:6,weight:7}]);}
  function generateOffers(player){var eligible=findEligibleClubs(player),count=Math.min(targetCount(),eligible.length),chosen=[],usedCountries={},usedBands={};var domestic=eligible.filter(function(x){return x.club.countryId===player.nationalityId;}),foreign=eligible.filter(function(x){return x.club.countryId!==player.nationalityId;});var domesticTarget=Math.min(domestic.length,Math.max(2,Math.ceil(count*0.62)));
    while(chosen.length<domesticTarget&&domestic.length){var dp=weightedPick(domestic,player,usedCountries,usedBands);if(!dp){break;}chosen.push(buildOffer(player,dp));usedCountries[dp.club.countryId]=true;usedBands[Math.floor(dp.club.reputation/10)]=true;domestic=domestic.filter(function(x){return x.club.id!==dp.club.id;});}
    while(chosen.length<count&&(foreign.length||domestic.length)){var pool=foreign.length?foreign:domestic;var pick=weightedPick(pool,player,usedCountries,usedBands);if(!pick){break;}chosen.push(buildOffer(player,pick));usedCountries[pick.club.countryId]=true;usedBands[Math.floor(pick.club.reputation/10)]=true;foreign=foreign.filter(function(x){return x.club.id!==pick.club.id;});domestic=domestic.filter(function(x){return x.club.id!==pick.club.id;});}
    if(chosen.length<CONFIG.minOffers){eligible.forEach(function(x){if(chosen.length<CONFIG.minOffers&&!chosen.some(function(o){return o.clubId===x.club.id;})){chosen.push(buildOffer(player,x));}});}
    return chosen.sort(function(a,b){return b.offerScore-a.offerScore;});
  }
  function summarizeProfile(profile,iterations){var n=Math.max(1,Number(iterations)||1000),reps=[],strengths=[],domestic=0,total=0;for(var i=0;i<n;i++){generateOffers(profile).forEach(function(o){var c=clubById(o.clubId);if(!c){return;}reps.push(c.reputation);strengths.push(c.squadStrength);total++;if(c.countryId===profile.nationalityId){domestic++;}});}function avg(a){return a.length?a.reduce(function(s,v){return s+v;},0)/a.length:0;}function pct(count){return total?Math.round(count/total*10000)/100:0;}var report={profile:{age:profile.age,overall:profile.overall,potential:profile.potential,nationalityId:profile.nationalityId},iterations:n,totalOffers:total,averageClubReputation:Math.round(avg(reps)*100)/100,minReputation:reps.length?Math.min.apply(null,reps):null,maxReputation:reps.length?Math.max.apply(null,reps):null,averageSquadStrength:Math.round(avg(strengths)*100)/100,reputation70PlusPercent:pct(reps.filter(function(v){return v>=70;}).length),reputation80PlusPercent:pct(reps.filter(function(v){return v>=80;}).length),reputation90PlusPercent:pct(reps.filter(function(v){return v>=90;}).length),domesticOfferPercent:pct(domestic),foreignOfferPercent:pct(total-domestic)};return report;}
  function debugGenerateProfiles(iterations){var profiles=[{label:"A",age:16,overall:47,potential:68,nationalityId:"tur"},{label:"B",age:16,overall:50,potential:74,nationalityId:"tur"},{label:"C",age:16,overall:53,potential:80,nationalityId:"tur"},{label:"D",age:17,overall:57,potential:87,nationalityId:"tur"}];var result={};profiles.forEach(function(p){var report=summarizeProfile(p,iterations||1000);result[p.label]=report;console.log("[FC ClubFinder] Profile "+p.label,report);});return result;}
  function runOfferTest(iterations){var n=Math.max(1,Number(iterations)||1000),elite80=0,elite90=0,ineligible=0,total=0,p={age:16,overall:50,potential:74,nationalityId:"tur"};for(var i=0;i<n;i++){generateOffers(p).forEach(function(o){var c=clubById(o.clubId);total++;if(c.reputation>=80){elite80++;}if(c.reputation>=90){elite90++;}if(!hardEligible(p,c)){ineligible++;}});}var report={iterations:n,totalOffers:total,reputation80Plus:elite80,reputation90Plus:elite90,ineligibleOffers:ineligible,profileSummary:summarizeProfile(p,n)};console.log("[FC ClubFinder] Offer test",report);return report;}
  window.FC.ClubFinder={CONFIG:CONFIG,findEligibleClubs:findEligibleClubs,calculateFit:calculateFit,generateOffers:generateOffers,debugGenerateProfiles:debugGenerateProfiles,runOfferTest:runOfferTest};
})();
