(function(){"use strict";
 function seasonStats(){var s=FC.State.get(),a=s.world&&s.world.activeSeason;if(!a||!a.player)return [];return Object.keys(a.player.competitionStats||{}).map(function(id){var c=FC.CompetitionEngine.get(id),l=(FC_DATA.leagues||[]).find(function(x){return x.id===id;}),x=a.player.competitionStats[id];return {competitionId:id,name:c?c.name:l?l.name:id,type:c?c.type:"LEAGUE",stats:x};});}
 window.FC.CompetitionUI={getPlayerSeasonStats:seasonStats};
})();
