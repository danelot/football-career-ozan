(function(){
  "use strict";
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function createState(player){var d=player.development||{};return {xp:Number(d.xp||0),seasonGrowth:0,rolePerformanceScore:0,trainingXP:0,matchXP:0,startingOverall:Number(player.overall||0),attributeChanges:{},attributePoints:0,developmentEvents:0};}
  function potentialGap(player){return Math.max(0,Number(player.potential||player.overall)-Number(player.overall||0));}
  function ageCurve(age){age=Number(age||18);if(age<=17){return 1.75;}if(age<=20){return 1.95;}if(age<=23){return 1.48;}if(age<=26){return 0.92;}if(age<=29){return 0.48;}return 0.22;}
  function developmentPace(player){var gap=potentialGap(player),gapFactor=0.45+Math.min(1.05,gap/28),ovr=Number(player.overall||50),ovrFactor=ovr<60?1.16:ovr<70?1.05:ovr<80?0.90:ovr<85?0.70:0.52,nearPot=gap<=4?0.38:gap<=8?0.62:gap<=14?0.82:1;return ageCurve(player.age)*gapFactor*ovrFactor*nearPot*0.78;}
  function xpForMatch(player,club,match){
    var cfg=FC.SeasonConfig.development,gap=potentialGap(player),potentialFactor=0.70+Math.min(0.65,gap/45),ageFactor=Number(player.age||17)<=16?1.10:1.04,facility=0.76+(Number(club.academyQuality||50)+Number(club.trainingQuality||50)+Number(club.youthPolicy||50))/750,offerDev=player.contract&&player.contract.developmentChance!=null?(0.92+Number(player.contract.developmentChance)/1000):1,performance=match.rating?clamp(0.72+(match.rating-6.0)*0.16,0.55,1.35):1,timeFactor=match.minutes?0.45+0.75*(match.minutes/90):(match.squadStatus==="unused_bench"?cfg.unusedBenchXP/cfg.baseMatchXP:cfg.notInSquadXP/cfg.baseMatchXP),morale=0.90+Number(player.morale||60)/600,form=0.92+Number(player.form||50)/700;
    var pace=developmentPace(player),minutesBoost=match.minutes?0.82+0.35*(match.minutes/90):0.72;
    return cfg.baseMatchXP*potentialFactor*ageFactor*facility*offerDev*performance*timeFactor*morale*form*pace*minutesBoost;
  }
  function xpForTraining(player,club){
    var cfg=FC.SeasonConfig.development,gap=Math.min(cfg.trainingPotentialGapCap,potentialGap(player)),gapFactor=0.62+(gap/cfg.trainingPotentialGapCap)*cfg.trainingPotentialGapWeight,age=Number(player.age||17),ageFactor=age<=16?cfg.trainingAge16Multiplier:(age===17?cfg.trainingAge17Multiplier:1),academy=Number(club.academyQuality||50)/100,training=Number(club.trainingQuality||50)/100,youth=Number(club.youthPolicy||50)/100,facility=cfg.trainingFacilityMin+((academy+training)/2)*cfg.trainingFacilityWeight+youth*cfg.trainingYouthWeight,morale=0.95+((Number(player.morale||60)-50)/50)*cfg.trainingMoraleWeight,form=0.96+((Number(player.form||50)-50)/50)*cfg.trainingFormWeight,randomFactor=FC.RNG.float(cfg.trainingRandomMin,cfg.trainingRandomMax);
    var envGate=clamp(0.35+((academy+training+youth)/3)*0.85,0.42,1.18);
    var physical=window.FC.PhysicalEngine?FC.PhysicalEngine.trainingXpMultiplier(player):1;return Math.max(0,cfg.trainingBaseXP*gapFactor*ageFactor*facility*morale*form*randomFactor*developmentPace(player)*0.68*envGate*physical);
  }
  function eventThreshold(state){var base=Number(FC.SeasonConfig.development.xpPerDevelopmentEvent||45),events=Number(state.developmentEvents||0),growth=Number(state.seasonGrowth||0),eventDecay=1+Math.max(0,events-4)*0.022,growthDecay=growth>=4?1.26:growth>=3?1.12:1;return base*eventDecay*growthDecay;}
  function applyGrowth(player,state,context){
    var threshold=eventThreshold(state),guard=0;
    while(state.xp>=threshold&&guard<24){
      state.xp-=threshold;
      FC.AttributeDevelopment.applyDevelopmentEvent(player,state,context);
      state.seasonGrowth=player.overall-state.startingOverall;
      threshold=eventThreshold(state);
      guard++;
    }
  }
  function applyMatch(player,club,match,state){var trainingXP=xpForTraining(player,club),matchXP=xpForMatch(player,club,match),envAvg=(Number(club.academyQuality||50)+Number(club.trainingQuality||50)+Number(club.youthPolicy||50))/3;if(Number(player.age||18)<=20&&envAvg<48&&Number(match.minutes||0)<35){var stall=FC.RNG.random();if(stall<0.64){trainingXP=0;matchXP*=0.01;}else if(stall<0.86){trainingXP*=0.12;matchXP*=0.35;}}state.trainingXP+=trainingXP;state.matchXP+=matchXP;state.xp+=trainingXP+matchXP;state.rolePerformanceScore+=(match.minutes/90)*(match.rating||6.0);applyGrowth(player,state,{club:club,match:match});return state;}
  function finish(player,club,seasonRecord,state){
    FC.OverallCalculator.recalculate(player);state.seasonGrowth=player.overall-state.startingOverall;player.development={xp:Math.round(state.xp*100)/100,lastSeasonGrowth:state.seasonGrowth,lastTrainingXP:Math.round(state.trainingXP*100)/100,lastMatchXP:Math.round(state.matchXP*100)/100};var role=player.contract&&player.contract.squadRole||"Prospect",roles=FC.SeasonConfig.roleOrder,index=Math.max(0,roles.indexOf(role)),apps=seasonRecord.league.appearances,matches=seasonRecord.league.matchOpportunities,avg=seasonRecord.league.averageRating,minutes=seasonRecord.league.minutes,share=matches?apps/matches:0,newIndex=index;if(share>=0.55&&avg>=6.75&&minutes>=900&&player.overall>=club.squadStrength-5){newIndex=Math.min(roles.length-1,index+1);}else if(share<0.18&&minutes<350&&index>0){newIndex=Math.max(0,index-1);}var newRole=roles[newIndex];if(player.contract){player.contract.squadRole=newRole;}return {overallChange:state.seasonGrowth,potentialChange:0,rolePerformanceScore:Math.round(state.rolePerformanceScore*100)/100,trainingXP:Math.round(state.trainingXP*100)/100,matchXP:Math.round(state.matchXP*100)/100,squadRoleEnd:newRole,attributeChanges:state.attributeChanges,attributePoints:state.attributePoints||0,developmentEvents:state.developmentEvents||0};
  }
  function debugDevelopmentCurve(count){var n=Math.max(100,Number(count||5000)),clubBase={id:"debug",squadStrength:62,academyQuality:65,trainingQuality:65,youthPolicy:65},profiles=[
      {id:"A",age:16,overall:50,potential:70,minutes:1100,rating:6.8,club:{academyQuality:58,trainingQuality:58,youthPolicy:58}},
      {id:"B",age:17,overall:55,potential:85,minutes:1900,rating:7.0,club:{academyQuality:72,trainingQuality:72,youthPolicy:72}},
      {id:"C",age:18,overall:60,potential:90,minutes:2400,rating:7.5,club:{academyQuality:86,trainingQuality:86,youthPolicy:84}},
      {id:"D",age:20,overall:70,potential:88,minutes:2300,rating:7.3,club:{academyQuality:75,trainingQuality:76,youthPolicy:72}},
      {id:"E",age:23,overall:78,potential:88,minutes:2200,rating:7.1,club:{academyQuality:72,trainingQuality:74,youthPolicy:68}},
      {id:"F",age:26,overall:82,potential:88,minutes:2300,rating:7.0,club:{academyQuality:72,trainingQuality:74,youthPolicy:65}},
      {id:"G",age:18,overall:60,potential:90,minutes:300,rating:6.2,club:{academyQuality:38,trainingQuality:40,youthPolicy:35}}
    ];function one(pr,pos){var base=FC.AttributeGenerator.generateForPosition(pos||"ST",pr.overall),p={age:pr.age,overall:pr.overall,potential:pr.potential,position:pos||"ST",attributes:base.attributes,form:50,morale:65,contract:{squadRole:"Rotation"}},club=Object.assign({},clubBase,pr.club),st=createState(p),matches=34,per=Math.round(pr.minutes/matches);for(var i=0;i<matches;i++){var mins=Math.max(0,Math.min(90,per+FC.RNG.int(-15,15))),m={minutes:mins,squadStatus:mins>=55?"starter":mins>0?"substitute":"not_in_squad",rating:mins?Math.max(4.8,Math.min(9.5,pr.rating+FC.RNG.float(-0.35,0.35))):0,goals:0,assists:0};applyMatch(p,club,m,st);}return {growth:p.overall-pr.overall,points:st.attributePoints||0,unique:Object.keys(st.attributeChanges||{}).length};}var out={};profiles.forEach(function(pr){var gs=[],pts=0,uniq=0,dist={0:0,1:0,2:0,3:0,4:0,5:0};for(var i=0;i<n;i++){var r=one(pr,"ST");gs.push(r.growth);pts+=r.points;uniq+=r.unique;dist[Math.max(0,Math.min(5,r.growth))]++;}gs.sort(function(a,b){return a-b;});out[pr.id]={averageOVRGrowth:gs.reduce(function(a,b){return a+b;},0)/n,median:gs[Math.floor(n/2)],min:gs[0],max:gs[gs.length-1],distributionPercent:Object.keys(dist).reduce(function(o,k){o["+"+k]=dist[k]*100/n;return o;},{}),averageAttributePoints:pts/n,averageUniqueAttributesImproved:uniq/n};});
    var sample=profiles[2],st=0,gk=0,cmpN=Math.min(n,1500);for(var z=0;z<cmpN;z++){st+=one(sample,"ST").growth;gk+=one(sample,"GK").growth;}out.GKComparison={iterations:cmpN,outfieldAverage:st/cmpN,gkAverage:gk/cmpN,difference:(gk-st)/cmpN};return out;}
  window.FC.DevelopmentEngine={createState:createState,eventThreshold:eventThreshold,applyMatch:applyMatch,finish:finish,xpForTraining:xpForTraining,xpForMatch:xpForMatch,developmentPace:developmentPace,debugDevelopmentCurve:debugDevelopmentCurve};
})();
