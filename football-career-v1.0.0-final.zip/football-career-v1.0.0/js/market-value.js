(function(){
  "use strict";
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function clubById(id){return (FC_DATA.clubs||[]).find(function(c){return c.id===id;});}
  function leagueById(id){return (FC_DATA.leagues||[]).find(function(l){return l.id===id;});}
  function latestSeason(player,career){var seasons=career&&career.seasons||[];return seasons.length?seasons[seasons.length-1]:null;}
  function ageFactor(age){age=Number(age||18);if(age<=18){return 1.22;}if(age<=21){return 1.16;}if(age<=24){return 1.10;}if(age<=28){return 1.02;}if(age<=31){return 0.88;}return Math.max(0.55,0.86-(age-31)*0.05);}
  function abilityBase(ovr){var value=90000,o=Math.round(clamp(Number(ovr||45),1,99));for(var level=45;level<o;level++){var growth=level<70?1.20:level<80?1.16:level<90?1.13:1.08;value*=growth;}if(o<45){for(var down=44;down>=o;down--){value/=1.20;}}return value;}
  function calculate(player,context){
    context=context||{};var ovr=Number(player.overall||45),pot=Number(player.potential||ovr),age=Number(player.age||18),career=context.career||null,club=context.club||clubById(player.clubId),league=context.league||(club&&leagueById(window.FC.WorldSeason?FC.WorldSeason.getClubLeagueId(club.id):club.leagueId)),season=context.season||latestSeason(player,career),remaining=Number(context.contractRemaining!=null?context.contractRemaining:(player.contract&&player.contract.yearsRemaining)||0);
    var base=abilityBase(ovr),gap=Math.max(0,pot-ovr),potWeight=age<=18?0.034:age<=21?0.026:age<=24?0.015:0.004,potentialFactor=1+Math.min(0.92,gap*potWeight);
    var leagueFactor=league?0.72+Number(league.reputation||50)/180:0.88,clubFactor=club?0.82+Number(club.reputation||50)/260:0.90,performanceFactor=1;
    if(season&&season.league){var rating=Number(season.league.averageRating||0),apps=Number(season.league.appearances||0),opp=Number(season.league.matchOpportunities||34),growth=Number(season.development&&season.development.overallChange||0);performanceFactor=clamp(0.88+(rating?Math.max(-0.12,(rating-6.55)*0.18):0)+(opp?Math.min(0.12,apps/opp*0.10):0)+growth*0.035,0.75,1.35);}
    var contractFactor=remaining>=4?1.13:remaining===3?1.08:remaining===2?1.02:remaining===1?0.84:0.70,positionFactor={ST:1.08,RW:1.05,LW:1.05,CAM:1.04,CM:1.00,CDM:0.98,RB:0.96,LB:0.96,CB:0.97,GK:0.94}[player.position]||1;
    var value=base*potentialFactor*ageFactor(age)*leagueFactor*clubFactor*performanceFactor*contractFactor*positionFactor;return Math.max(25000,Math.round(value/5000)*5000);
  }
  function update(player,context){player.marketValue=calculate(player,context);return player.marketValue;}
  function debugCurve(){var ovrs=[45,50,55,60,65,70,75,80,85,90,95],ages=[18,24,29],gaps=[0,5,10],rows=[];ages.forEach(function(age){gaps.forEach(function(gap){ovrs.forEach(function(ovr){var p={age:age,overall:ovr,potential:Math.min(99,ovr+gap),position:"CM",clubId:null,contract:{yearsRemaining:2}},debugClub={reputation:70},debugLeague={reputation:70},value=calculate(p,{club:debugClub,league:debugLeague,season:null,contractRemaining:2});rows.push({age:age,OVR:ovr,POT:p.potential,potentialGap:p.potential-ovr,value:value,formatted:FC.Utils.formatMoney(value)});});});});console.table(rows);return rows;}
  window.FC.MarketValue={abilityBase:abilityBase,calculate:calculate,update:update,debugCurve:debugCurve};
})();
