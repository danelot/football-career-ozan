(function(){"use strict";
 function unavailable(player){return !!(window.FC.PhysicalEngine&&(FC.PhysicalEngine.isInjured(player)||!FC.PhysicalEngine.isAvailable(player)));}
 function normalizeRole(status,started){if(started===true)return "STARTER";if(status==="substitute"||status==="injured_off"&&started===false)return "SUBSTITUTE";if(status==="unused_bench")return "UNUSED";return "OUT";}
 function fromPlan(player,plan,maxMinute,options){plan=plan||{};options=options||{};maxMinute=Number(maxMinute||90);var s=plan.status||"not_in_squad",mins=Math.max(0,Number(plan.minutes||0)),explicitStarted=typeof plan.started==="boolean"?plan.started:null,started=explicitStarted!=null?explicitStarted:(s==="starter"),role=normalizeRole(s,started),enter=null,exit=null,exitReason=plan.exitReason||null;
  if((!options.ignorePlayerAvailability&&unavailable(player))||plan.unavailable||mins<=0){if(s==="unused_bench")role="UNUSED";else if(s==="substitute")role="SUBSTITUTE";return {role:role,squadStatus:s,started:false,enteredMinute:null,exitedMinute:null,minutesPlayed:0,exitReason:null,activeIntervals:[],available:false};}
  if(started){role="STARTER";enter=0;exit=Math.min(maxMinute,Number(plan.exitMinute!=null?plan.exitMinute:mins));}
  else if(s==="substitute"||role==="SUBSTITUTE"){role="SUBSTITUTE";enter=Number(plan.enteredMinute!=null?plan.enteredMinute:Math.max(1,maxMinute-mins));exit=Math.min(maxMinute,Number(plan.exitMinute!=null?plan.exitMinute:enter+mins));}
  else if(s==="unused_bench")role="UNUSED";
  mins=(enter==null||exit==null)?0:Math.max(0,exit-enter);if(!exitReason&&mins>0&&exit<maxMinute)exitReason="SUBSTITUTED";if(!exitReason&&mins>0&&exit>=maxMinute)exitReason="MATCH_END";
  return {role:role,squadStatus:s,started:started===true,enteredMinute:enter,exitedMinute:exit,minutesPlayed:mins,exitReason:exitReason,activeIntervals:mins>0?[{start:enter,end:exit}]:[],available:mins>0};
 }
 function canReceive(player,context,part){if(!player||unavailable(player)||!part||!part.available||Number(part.minutesPlayed||0)<=0)return false;return part.role==="STARTER"||part.role==="SUBSTITUTE";}
 function contains(part,minute){minute=Number(minute);return !!(part&&part.activeIntervals||[]).some(function(x){return minute>=Number(x.start)&&minute<=Number(x.end);});}
 function absoluteMinute(part,playedOffset){if(!part||!part.activeIntervals||!part.activeIntervals.length)return null;var x=part.activeIntervals[0],off=Math.max(0,Number(playedOffset||0));return Math.max(Number(x.start),Math.min(Number(x.end),Number(x.start)+off));}
 function randomMinute(part){if(!part||!part.activeIntervals||!part.activeIntervals.length)return null;var x=part.activeIntervals[0],lo=Math.max(1,Math.ceil(Number(x.start))),hi=Math.max(lo,Math.floor(Number(x.end)));return FC.RNG.int(lo,hi);}
 function distributedMinutes(count,part){var out=[];count=Math.max(0,Number(count||0));if(!count||!part||!part.activeIntervals||!part.activeIntervals.length)return out;var x=part.activeIntervals[0],lo=Math.max(1,Number(x.start)),hi=Math.max(lo,Number(x.end)),span=Math.max(1,hi-lo);for(var i=0;i<count;i++)out.push(Math.max(Math.ceil(lo),Math.min(Math.floor(hi),Math.round(lo+(i+1)*span/(count+1)))));return out;}
 window.FC.MatchParticipation={fromPlan:fromPlan,canReceiveInteractiveChance:canReceive,containsMinute:contains,toAbsoluteMinute:absoluteMinute,randomEventMinute:randomMinute,distributedEventMinutes:distributedMinutes};
})();
