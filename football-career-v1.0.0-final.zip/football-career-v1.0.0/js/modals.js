(function(){"use strict";
  function close(){var root=document.getElementById("modal-root");if(root){root.innerHTML="";document.body.classList.remove("modal-open");}}
  function show(opts){
    opts=opts||{};var root=document.getElementById("modal-root");if(!root){return;}
    var overlay=document.createElement("div");overlay.className="modal-overlay";
    var box=document.createElement("div");box.className="modal"+(opts.type?" modal-"+opts.type:"");box.setAttribute("role","dialog");box.setAttribute("aria-modal","true");
    box.innerHTML="<div class='modal-head'><h2></h2><button class='icon-btn' aria-label='Kapat'>×</button></div><div class='modal-body'></div><div class='modal-actions'></div>";
    box.querySelector("h2").textContent=opts.title||"Bildirim";if(opts.html){box.querySelector(".modal-body").innerHTML=opts.message||"";}else{box.querySelector(".modal-body").textContent=opts.message||"";}
    box.querySelector(".icon-btn").onclick=close;
    (opts.buttons&&opts.buttons.length?opts.buttons:[{label:"TAMAM"}]).forEach(function(b){var btn=document.createElement("button");btn.className="btn "+(b.className||"btn-secondary");btn.textContent=b.label||"TAMAM";btn.onclick=function(){if(b.callback){b.callback();}if(b.close!==false){close();}};box.querySelector(".modal-actions").appendChild(btn);});
    overlay.onclick=function(e){if(e.target===overlay){close();}};overlay.appendChild(box);root.innerHTML="";root.appendChild(overlay);document.body.classList.add("modal-open");setTimeout(function(){var b=box.querySelector("button");if(b){b.focus();}},0);
  }
  document.addEventListener("keydown",function(e){if(e.key==="Escape"){close();}});
  window.FC.Modals={show:show,close:close};
})();
