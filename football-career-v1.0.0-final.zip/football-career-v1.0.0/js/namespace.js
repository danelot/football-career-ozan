(function () {
  "use strict";
  window.FC = window.FC || {};
  window.FC_DATA = window.FC_DATA || {};
})();
