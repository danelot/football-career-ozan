(function(){"use strict";
  window.FC.Navigation={go:function(screen){FC.State.update({screen:screen});FC.Game.render();}};
})();
