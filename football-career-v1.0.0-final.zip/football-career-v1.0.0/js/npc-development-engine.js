(function(){"use strict";
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function roleFactor(r){return {STAR:1.12,STARTER:1,ROTATION:.82,SQUAD:.62,RESERVE:.42}[r]||.65;}
function expected(p,club){var a=p.age,gap=Math.max(0,p.potential-p.overall),base=a<=18?.95:a<=21?.72:a<=24?.38:a<=27?.14:a<=30?.01:a<=33?-.38:-.72;if(p.position==="GK"&&a>=29)base+=.28;var env=((Number(club.trainingQuality||50)+Number(club.academyQuality||50))/2-50)/100*.35;var out=base*(.45+.55*gap/20)*roleFactor(p.role)+env;if(p.generationType==="ROSTER_REPLACEMENT"&&out>0)out=0;if(p.generationType==="YOUTH_INTAKE"&&out>0){var mult=1;if(a<=24&&gap>=10){mult=3.00;if(p.potential>=95)mult=4.90;else if(p.potential>=90)mult=4.50;else if(p.potential>=85)mult=3.90;}else if(a<=27&&gap>=6&&p.potential>=85){mult=p.potential>=95?3.60:p.potential>=90?3.25:2.65;}out*=mult;}return out;}
function positiveGrowthCancelChance(p){var o=Number(p.overall||0),a=Number(p.age||0),gap=Math.max(0,Number(p.potential||0)-o);if(o<80)return 0;
  /* ADIM 11.2.1: upper-tail resistance is now age + POT-gap aware. A young player
     with substantial unused potential must not be treated like a prime player at
     his ceiling. This only changes the chance to cancel an already-positive gain. */
  var young=a<=23,developing=a<=26;
  if(o>=88){
    if(young&&gap>=7)return .18;
    if(developing&&gap>=6)return .42;
    if(gap>=4)return .68;
    return .90;
  }
  if(young&&gap>=8)return .04;
  if(young&&gap>=5)return .10;
  if(developing&&gap>=6)return .18;
  if(gap>=4)return .34;
  return .62;
}
function update(p,club){var e=expected(p,club),noise=(FC.RNG.random()+FC.RNG.random()+FC.RNG.random()-1.5)*1.0,g=Math.round(e+noise);if(p.generationType==="ROSTER_REPLACEMENT"&&g>0)g=0;var cancel=positiveGrowthCancelChance(p);if(g>0&&cancel>0&&FC.RNG.random()<cancel)g=0;g=clamp(g,-3,3);p.overall=clamp(p.overall+g,35,96);p.potential=Math.max(p.overall,clamp(p.potential+(p.age>27&&FC.RNG.random()<.25?-1:0),p.overall,96));p.peakOVR=Math.max(Number(p.peakOVR||0),p.overall);return g;}
window.FC.NPCDevelopmentEngine={expectedGrowth:expected,update:update,positiveGrowthCancelChance:positiveGrowthCancelChance};
})();
