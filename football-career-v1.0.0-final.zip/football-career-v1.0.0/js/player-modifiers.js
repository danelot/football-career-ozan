(function(){"use strict";
 function byId(a,id){return (a||[]).find(function(x){return x.id===id;});}
 function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
 function activeStaff(fin,key){var s=fin&&fin.staff&&fin.staff[key];return s&&s.id&&s.status!=="suspended"?s:null;}
 function get(player){var fin=player&&player.finances||{},caps=FC_DATA.economyConfig.modifierCaps,out={trainingXp:1,recovery:1,fatigueRecovery:1,sharpness:1,injuryRisk:1,injuryDuration:1,reinjuryRisk:1,transferReach:1,negotiation:1};
  var ag=fin.currentAgentId&&byId(FC_DATA.agents,fin.currentAgentId);if(ag){out.transferReach*=Number(ag.transferReach||1);out.negotiation*=Number(ag.negotiationModifier||1);}
  var tr=activeStaff(fin,"personalTrainer"),td=tr&&byId(FC_DATA.personalTrainers,tr.id);if(td){out.trainingXp*=td.trainingXpModifier;out.fatigueRecovery*=1/td.fatigueModifier;out.sharpness*=td.sharpnessModifier;}
  var ph=activeStaff(fin,"privatePhysio"),pd=ph&&byId(FC_DATA.privatePhysios,ph.id);if(pd){out.recovery*=pd.recoveryModifier;out.fatigueRecovery*=pd.recoveryModifier;out.injuryDuration*=pd.injuryDurationModifier;out.reinjuryRisk*=pd.reinjuryRiskModifier;}
  var fac=fin.facilities||{},ec=FC_DATA.economyConfig.facilities,h=ec.homeGym[Math.max(0,Math.min(3,Number(fac.homeGymLevel||0)))],r=ec.recoverySetup[Math.max(0,Math.min(3,Number(fac.recoverySetupLevel||0)))],l=ec.performanceLab[Math.max(0,Math.min(3,Number(fac.performanceLabLevel||0)))];
  out.trainingXp*=h.trainingXp*l.trainingXp;out.recovery*=h.recovery*r.recovery;out.fatigueRecovery*=r.fatigueRecovery;out.sharpness*=l.sharpness;out.injuryRisk*=l.injuryRisk;
  out.trainingXp=clamp(out.trainingXp,1,caps.trainingXpMax);out.recovery=clamp(out.recovery,1,caps.recoveryMax);out.fatigueRecovery=clamp(out.fatigueRecovery,1,caps.recoveryMax);out.injuryRisk=clamp(out.injuryRisk,caps.injuryRiskMin,1.1);out.injuryDuration=clamp(out.injuryDuration,caps.injuryDurationMin,1);out.reinjuryRisk=clamp(out.reinjuryRisk,caps.reinjuryRiskMin,1);out.transferReach=clamp(out.transferReach,1,caps.transferReachMax);out.negotiation=clamp(out.negotiation,1,caps.negotiationMax);return out;}
 window.FC.PlayerModifiers={get:get};
})();