(function(){"use strict";
 function all(){return FC_DATA.rivalries||[];}
 function get(a,b){if(!a||!b||a===b)return null;return all().find(function(r){return (r.clubAId===a&&r.clubBId===b)||(r.clubAId===b&&r.clubBId===a);})||null;}
 function validate(){var ids={};(FC_DATA.clubs||[]).forEach(function(c){ids[c.id]=1;});var errors=[],pairs={};all().forEach(function(r){if(!ids[r.clubAId]||!ids[r.clubBId])errors.push("Rivalry missing club: "+r.id);if(r.clubAId===r.clubBId)errors.push("Self rivalry: "+r.id);var k=[r.clubAId,r.clubBId].sort().join("|");if(pairs[k])errors.push("Duplicate rivalry pair: "+r.id+" / "+pairs[k]);pairs[k]=r.id;});return {ok:!errors.length,errors:errors,count:all().length};}
 function playerContext(player,currentClubId,otherClubId){var r=get(currentClubId,otherClubId),id=player&&player.careerIdentity,rel=id&&id.clubRelationships&&id.clubRelationships[otherClubId];return {rivalry:r,isRival:!!r,intensity:r?Number(r.intensity||0):0,name:r&&r.name||null,isFormerClub:!!rel};}
 window.FC.RivalryEngine={getRivalry:get,areRivals:function(a,b){return !!get(a,b);},getIntensity:function(a,b){var r=get(a,b);return r?Number(r.intensity||0):0;},getPlayerContext:playerContext,validate:validate};
})();
