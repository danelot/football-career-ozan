(function(){"use strict";
  var ALGORITHM="mulberry32-v1",state=initialSeed();
  function initialSeed(){var a=Math.floor(Math.random()*4294967296)>>>0,b=(Date.now()>>>0);return (a^b^0x9e3779b9)>>>0;}
  function random(){state=(state+0x6D2B79F5)>>>0;var t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;}
  function int(min,max){return Math.floor(random()*(max-min+1))+min;}
  function float(min,max){return random()*(max-min)+min;}
  function item(arr){return arr&&arr.length?arr[int(0,arr.length-1)]:null;}
  function weighted(options){if(!options||!options.length){return null;}var total=options.reduce(function(s,o){return s+(Number(o.weight)||0);},0),r=random()*total;for(var i=0;i<options.length;i++){r-=Number(options[i].weight)||0;if(r<=0){return options[i].value;}}return options[options.length-1].value;}
  function getState(){return {algorithm:ALGORITHM,state:state>>>0};}
  function setState(value){var next=value&&typeof value==="object"?value.state:value;if(value&&typeof value==="object"&&value.algorithm&&value.algorithm!==ALGORITHM)return false;if(!Number.isFinite(Number(next)))return false;state=(Number(next)>>>0);return true;}
  window.FC.RNG={random:random,int:int,float:float,item:item,weighted:weighted,getState:getState,setState:setState,algorithm:ALGORITHM};
})();
