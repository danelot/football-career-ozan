(function(){"use strict";
 function fixtureDate(f){return Number(f.dateIndex||f.round*7||9999);}
 function allPlayerFixtures(state,active){var pc=state.player&&state.player.clubId,out=[];Object.keys(active.leagues||{}).forEach(function(lid){(active.leagues[lid].fixtures||[]).forEach(function(f){if(!f.played&&(f.homeClubId===pc||f.awayClubId===pc)){out.push(f);}});});Object.keys(active.competitions||{}).forEach(function(cid){(active.competitions[cid].fixtures||[]).forEach(function(f){if(!f.played&&(f.homeClubId===pc||f.awayClubId===pc)){out.push(f);}});});return out.sort(function(a,b){return fixtureDate(a)-fixtureDate(b)||String(a.id).localeCompare(String(b.id));});}
 window.FC.ScheduleEngine={fixtureDate:fixtureDate,getPlayerFixtures:allPlayerFixtures,getClubFixtures:allPlayerFixtures,next:function(s,a){return allPlayerFixtures(s,a)[0]||null;}};
})();
