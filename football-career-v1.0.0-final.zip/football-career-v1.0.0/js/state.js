(function(){"use strict";
  var initial={screen:"main-menu",player:null,career:null,world:{season:"2026-27",year:2026},settings:{autosave:true,animations:true}};
  var state=FC.Utils.clone(initial);
  window.FC.State={
    get:function(){return FC.Utils.clone(state);},
    // Internal read-only reference for verified hot paths. Do not mutate the returned object.
    peek:function(){return state;},
    // Internal commit path: clone once, preserving State.get()/State.set() public semantics.
    commit:function(next){state=FC.Utils.clone(next);return true;},
    set:function(next){state=FC.Utils.clone(next);return this.get();},
    update:function(patch){Object.keys(patch||{}).forEach(function(k){state[k]=FC.Utils.clone(patch[k]);});return this.get();},
    reset:function(){state=FC.Utils.clone(initial);if(window.FC.WorldSeason&&FC.WorldSeason.resetRuntime){FC.WorldSeason.resetRuntime();}return this.get();}
  };
})();
