(function(){
  "use strict";
  var map={"ı":"i","İ":"i","ş":"s","Ş":"s","ğ":"g","Ğ":"g","ü":"u","Ü":"u","ö":"o","Ö":"o","ç":"c","Ç":"c"};
  function normalizeSearchText(value){var s=String(value||"").replace(/[ıİşŞğĞüÜöÖçÇ]/g,function(ch){return map[ch]||ch;}).toLowerCase();if(s.normalize){s=s.normalize("NFD").replace(/[\u0300-\u036f]/g,"");}return s.trim();}
  function escapeHtml(v){return String(v==null?"":v).replace(/[&<>"']/g,function(ch){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[ch]||ch;});}
  function clone(obj){return obj==null?obj:JSON.parse(JSON.stringify(obj));}
  var uidCounter=0;function uid(prefix){uidCounter+=1;return (prefix||"id")+"_"+Date.now().toString(36)+"_"+uidCounter.toString(36);}
  function flagEmoji(code){if(!code||code.length!==2){return code||"⚽";}return code.toUpperCase().replace(/./g,function(c){return String.fromCodePoint(127397+c.charCodeAt(0));});}
  function nextSeason(season){var m=/^(\d{4})-(\d{2})$/.exec(String(season||""));if(!m){throw new Error("Invalid season format: "+season);}var start=Number(m[1])+1,end=(Number(m[2])+1)%100;return String(start)+"-"+String(end).padStart(2,"0");}
  function addSeasons(season,count){var out=season,n=Math.max(0,Number(count||0));for(var i=0;i<n;i++){out=nextSeason(out);}return out;}
  function formatMoney(value){var n=Math.max(0,Number(value||0));if(n>=1000000000){return "€"+(n/1000000000).toFixed(n>=10000000000?1:2).replace(/\.0+$/g,"")+"B";}if(n>=1000000){return "€"+(n/1000000).toFixed(n>=10000000?1:2).replace(/\.0+$/g,"")+"M";}if(n>=1000){return "€"+(n/1000).toFixed(n>=100000?0:1).replace(/\.0+$/g,"")+"K";}return "€"+Math.round(n).toLocaleString("tr-TR");}
  window.FC.Utils={normalizeSearchText:normalizeSearchText,escapeHtml:escapeHtml,clone:clone,uid:uid,flagEmoji:flagEmoji,nextSeason:nextSeason,addSeasons:addSeasons,formatMoney:formatMoney};
  window.FC.DataValidator={
    validate:function(){
      var errors=[],warnings=[],countryIds={},leagueIds={},clubIds={},clubCounts={};
      function range(value,label,id){if(typeof value!=="number"||value<0||value>100){errors.push(label+" 0-100 dışında: "+id+" ("+value+")");}}
      if(!window.FC_DATA.datapack){errors.push("Missing datapack");}
      else{if(!FC_DATA.datapack.gameVersion){errors.push("Missing gameVersion");}if(!FC_DATA.datapack.season){errors.push("Missing season");}if(FC_DATA.datapack.isComplete===false){warnings.push("Development datapack aktif; lig kadroları eksik olabilir.");}}
      if(!Array.isArray(window.FC_DATA.countries)){errors.push("Countries is not an array");}
      else{FC_DATA.countries.forEach(function(c){if(!c.id||!c.name||!c.code){errors.push("Invalid country record: "+JSON.stringify(c));}if(countryIds[c.id]){errors.push("Duplicate country ID: "+c.id);}countryIds[c.id]=true;});}
      if(!Array.isArray(window.FC_DATA.leagues)){errors.push("Leagues is not an array");}
      else{FC_DATA.leagues.forEach(function(l){if(!l.id||!l.name||!l.countryId){errors.push("Invalid league record: "+JSON.stringify(l));}if(leagueIds[l.id]){errors.push("Duplicate league ID: "+l.id);}leagueIds[l.id]=l;if(!countryIds[l.countryId]){errors.push("League countryId bulunamadı: "+l.id+" -> "+l.countryId);}if(Number(l.level)<=0){errors.push("League level <= 0: "+l.id);}range(l.reputation,"League reputation",l.id);if(l.expectedTeamCount!=null&&(!Number.isInteger(l.expectedTeamCount)||l.expectedTeamCount<=0)){errors.push("League expectedTeamCount geçersiz: "+l.id+" ("+l.expectedTeamCount+")");}});}
      if(!Array.isArray(window.FC_DATA.clubs)){errors.push("Clubs is not an array");}
      else{FC_DATA.clubs.forEach(function(c){if(!c.id||!c.name||!c.countryId||!c.leagueId){errors.push("Invalid club record: "+JSON.stringify(c));}if(clubIds[c.id]){errors.push("Duplicate club ID: "+c.id);}clubIds[c.id]=true;if(!countryIds[c.countryId]){errors.push("Club countryId bulunamadı: "+c.id+" -> "+c.countryId);}var l=leagueIds[c.leagueId];if(!l){errors.push("Club leagueId bulunamadı: "+c.id+" -> "+c.leagueId);}else if(l.countryId!==c.countryId){errors.push("Club/league country uyuşmuyor: "+c.id);}clubCounts[c.leagueId]=(clubCounts[c.leagueId]||0)+1;range(c.reputation,"Club reputation",c.id);range(c.academyQuality,"Academy quality",c.id);range(c.squadStrength,"Squad strength",c.id);});}
      Object.keys(leagueIds).forEach(function(id){var l=leagueIds[id],loaded=clubCounts[id]||0;if(l.expectedTeamCount&&loaded!==l.expectedTeamCount){warnings.push("League dataset incomplete: "+l.name+" expected "+l.expectedTeamCount+", loaded "+loaded);}});if(window.FC.RivalryEngine){var rv=FC.RivalryEngine.validate();errors=errors.concat(rv.errors||[]);}if(window.FC.NationalTeamEngine){var nv=FC.NationalTeamEngine.validateData();errors=errors.concat(nv.errors||[]);}
      errors.forEach(function(e){console.error("[FC Data] "+e);});warnings.forEach(function(w){console.warn("[FC Data] "+w);});
      return {ok:errors.length===0,errors:errors,warnings:warnings};
    }
  };
  window.FC.DataValidator.validateTransferState=function(transferWindow){var errors=[];if(!transferWindow){return {ok:true,errors:[],warnings:[]};}(transferWindow.offers||[]).forEach(function(o){if(window.FC.TransferEngine){errors=errors.concat(FC.TransferEngine.validateOffer(o));}});errors.forEach(function(e){console.error("[FC Transfer Data] "+e);});return {ok:errors.length===0,errors:errors,warnings:[]};};
})();
